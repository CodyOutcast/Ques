# Ques Pivot 前端实施清单 ✅
## 从"AI人才匹配"到"校园任务平台" - 逐步实施指南（v3.0 - 极简版）

**✅ 用户确认的极简设计原则**：
- ✅ 删除matchScore和whyMatch相关功能
- ✅ AI任务表单在聊天区显示（非跳转页面）
- ✅ 右滑卡片直接申请，无需填写表单
- ✅ 订单验收极简化：只有"验收通过"和"举报"按钮
- ✅ 评价系统：仅5星评分，无文字评价
- ✅ 钱包Minimalist设计：可展开板块
- ✅ 订单详情：简化为Card板块，参考NotificationPanel设计
- ✅ 组件精简：从15个减少到10个核心组件

---

## 📋 Phase 1: 核心组件调整（预计2-3天）

### 1.1 ChatInterface - 添加角色切换器 + 文件上传（用户决策 2.1 - 修正版）

**文件**：`src/components/ChatInterface.tsx`

**🎨 设计要求（重要）**：
- ✅ **使用Switch开关插件**，不用emoji+文字按钮
- ✅ **位置**：输入框上方（而非页面顶部），左侧对齐
- ✅ **标签**：接单 / 发单（纯文字，无emoji）
- ✅ **新增文件上传按钮**：放在开关旁边

```typescript
[x] ✅ 添加角色切换Switch（输入框上方）

import { Switch } from '@/components/ui/switch'
import { Label } from '@/components/ui/label'
import { Paperclip, X, Trash2 } from 'lucide-react'

// 在ChatInterface组件中添加state
const [currentRole, setCurrentRole] = useState<'freelancer' | 'poster'>('freelancer')
const [uploadedFiles, setUploadedFiles] = useState<File[]>([])
const fileInputRef = useRef<HTMLInputElement>(null)

// ✅ 角色切换 + 文件上传控件（输入框上方）
<div className="px-4 py-2 bg-gray-50 border-t border-gray-200 flex items-center justify-between">
  {/* 左侧：角色切换开关 + 文件上传 */}
  <div className="flex items-center gap-3">
    <Label className="text-sm text-gray-600">模式</Label>
    <div className="flex items-center gap-2">
      <span className={`text-xs ${currentRole === 'freelancer' ? 'font-medium text-blue-600' : 'text-gray-400'}`}>
        接单
      </span>
      <Switch
        checked={currentRole === 'poster'}
        onCheckedChange={(checked) => {
          setCurrentRole(checked ? 'poster' : 'freelancer')
          handleRoleChange(checked ? 'poster' : 'freelancer')
        }}
      />
      <span className={`text-xs ${currentRole === 'poster' ? 'font-medium text-blue-600' : 'text-gray-400'}`}>
        发单
      </span>
    </div>
    
    {/* 文件上传按钮 */}
    <Button
      variant="outline"
      size="sm"
      className="h-8 gap-1.5"
      onClick={() => fileInputRef.current?.click()}
    >
      <Paperclip size={14} />
      <span className="text-xs">上传文件</span>
    </Button>
    <input
      ref={fileInputRef}
      type="file"
      multiple
      accept="image/*,.pdf,.doc,.docx"
      className="hidden"
      onChange={handleFileUpload}
    />
    
    {/* 已上传文件预览 */}
    {uploadedFiles.length > 0 && (
      <div className="flex gap-1">
        {uploadedFiles.map((file, idx) => (
          <Badge key={idx} variant="secondary" className="text-xs">
            📎 {file.name.slice(0, 10)}...
            <X size={12} className="ml-1 cursor-pointer" onClick={() => removeFile(idx)} />
          </Badge>
        ))}
      </div>
    )}
  </div>
  
  {/* 右侧：清空对话按钮 */}
  <Button variant="ghost" size="sm">
    <Trash2 size={14} />
  </Button>
</div>

[x] 实现角色切换逻辑

const handleRoleChange = (newRole: 'freelancer' | 'poster') => {
  setCurrentRole(newRole)
  
  // ✅ 显示Toast提示
  showToast({
    message: newRole === 'freelancer' 
      ? '已切换到接单模式' 
      : '已切换到发单模式',
    icon: '✅',
    duration: 2000
  })
}

[x] 实现文件上传逻辑

const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
  const files = Array.from(e.target.files || [])
  
  // 验证文件大小（10MB限制）
  const validFiles = files.filter(file => {
    if (file.size > 10 * 1024 * 1024) {
      showToast({ message: `${file.name} 超过10MB`, type: 'error' })
      return false
    }
    return true
  })
  
  setUploadedFiles(prev => [...prev, ...validFiles])
  if (validFiles.length > 0) {
    showToast({ message: `已添加 ${validFiles.length} 个文件`, icon: '📎' })
  }
}

const removeFile = (index: number) => {
  setUploadedFiles(prev => prev.filter((_, idx) => idx !== index))
}

[x] 修改AI欢迎语（根据角色动态生成）

const getWelcomeMessage = (role: 'freelancer' | 'poster') => {
  if (role === 'freelancer') {
    return `你好！我是你的接单助手 🤖

我可以帮你：
• 搜索适合你的任务
• 智能推荐高匹配度任务
• 管理订单和收益

试试说"找个设计的活儿"或"我想接PPT制作的单"`
  } else {
    return `你好！我是你的任务助手 🤖

我可以帮你：
• 发布任务找人帮忙
• 完善任务需求
• 管理发布的任务

试试说"我想找人做海报"或"需要一个视频剪辑"`
  }
}

useEffect(() => {
  // 角色切换时更新欢迎语
  setMessages([{
    role: 'assistant',
    content: getWelcomeMessage(currentRole),
    timestamp: new Date().toISOString()
  }])
}, [currentRole])

[x] 传递currentRole给ChatCards组件

{msg.hasRecommendations && (
  <ChatCards 
    currentRole={currentRole}  // ✅ 传递当前角色
    aiGeneratedProfiles={msg.recommendations}
  />
)}
```

---

### 1.1.5 AI引导式发单流程（2024-10-23完成）

**文件**：`src/components/ChatInterface.tsx`

**状态**：✅ 已完成 - 包含卡片交互和支付流程

**功能描述**：在发单模式下，AI通过对话引导用户完善任务信息，生成任务卡片预览，用户在卡片上直接点击确认并支付，最后推荐接单者卡片。

**核心改动**：

```typescript
[x] 扩展Message类型支持特殊消息（Lines 18-50）
    interface Message {
      specialType?: 'task-preview' | 'task-payment';
      taskData?: TaskDraft;
      paymentData?: PaymentInfo;
    }
    
    interface TaskDraft {
      title?: string;
      description?: string;
      budget?: { min: number; max: number };
      deadline?: string;
      skills?: string[];
      category?: string;
      isComplete: boolean;
    }
    
    interface PaymentInfo {
      taskTitle: string;
      amount: number;
      status: 'pending' | 'processing' | 'completed' | 'failed';
    }

[x] 任务发布流程状态机（Lines 415-428）
    const [taskPostingFlow, setTaskPostingFlow] = useState({
      isActive: boolean,  // 是否在发单流程中
      step: 'collecting-info' | 'confirm-task' | 'payment' | 'finding-freelancers' | 'completed',
      currentDraft: TaskDraft,
      fieldsCollected: Set<string>  // 跟踪已收集字段：'budget', 'deadline', 'skills'
    });

[x] Mock设计任务数据（Lines 258-330）
    添加3个设计类任务：
    - task-design-1: 社团招新海报设计（¥150-200）
    - task-design-2: PPT模板美化（¥100-150）
    - task-design-3: 公众号封面图设计（¥80-120）
```

**简化的3步收集流程**（Lines 918-960）：

```typescript
[x] 第1步：收集预算
    用户输入任何包含数字的内容
    AI: "好的，预算已记录 ✓ 请告诉我：任务的截止时间是什么时候？"

[x] 第2步：收集截止时间
    用户输入任何内容（自动默认7天）
    AI: "好的，截止时间已记录 ✓ 最后，这个任务需要什么技能？"

[x] 第3步：收集技能
    用户输入任何内容作为技能
    AI: "太好了！任务信息已经完整 ✅ 让我为你生成任务预览..."
    → 1秒后显示任务预览卡片
```

**任务预览卡片UI**（Lines 1408-1519）：

```typescript
[x] 卡片内容
    - 📋 任务预览标题 + "待确认" Badge
    - 任务标题、详细描述
    - 预算范围、截止时间（Grid布局）
    - 技能标签（Badge数组）

[x] 卡片交互按钮
    <Button onClick={修改}>修改</Button>  // 显示开发中提示
    <Button onClick={确认发布}>确认发布</Button>
    
    确认发布逻辑（Lines 1495-1518）：
    1. 更新状态：step → 'payment'
    2. 显示AI确认消息："任务信息已确认 ✅"
    3. 1秒后自动显示支付界面消息
```

**支付界面UI**（Lines 1553-1693）：

```typescript
[x] 界面设计
    - 渐变背景：from-green-50 to-blue-50
    - 💳 支付任务预算标题
    - 白色卡片显示：任务名称 + 托管金额（¥XXX大字）
    - 安全提示："🔒 支付安全由平台保障"

[x] 支付按钮交互
    微信支付按钮（Lines 1582-1638）：
    onClick() {
      toast.success('支付成功！✅')
      → 更新状态：step → 'finding-freelancers'
      → 0.5秒后显示："支付成功！资金已托管..."
      → 1.5秒后显示："找到了3位高匹配度的接单者！"
      → 1.5秒后显示接单者卡片（ChatCards组件）
      → 重置流程状态为completed
    }
    
    支付宝按钮（Lines 1639-1693）：
    同微信支付逻辑
```

**接单者推荐卡片**（Lines 1603-1633）：

```typescript
[x] 推荐逻辑
    - 使用MOCK_RECOMMENDATIONS前3位
    - 生成whyMatch: "完成率XX%，擅长相关技能，平均响应时间2小时"
    - 设置cardsTriggerIndex定位卡片显示位置
    - 触发ChatCards组件显示卡片
    - 支持左滑忽略/右滑邀请交互
```

**用户体验流程**：
```
发单模式：
1. 用户："我想找人做海报"
   AI："请告诉我：任务的预算范围是多少？"

2. 用户："100元"
   AI："好的，预算已记录 ✓ 请告诉我：截止时间是什么时候？"

3. 用户："3天"
   AI："好的，截止时间已记录 ✓ 最后，这个任务需要什么技能？"

4. 用户："设计"
   AI："太好了！任务信息已经完整 ✅"
   → [显示任务预览卡片]

5. 点击卡片上"确认发布"按钮
   AI："任务信息已确认 ✅ 接下来需要支付..."
   → [显示支付界面]

6. 点击"微信支付"或"支付宝"按钮
   Toast："支付成功！✅"
   AI："支付成功！资金已托管...正在匹配接单者..."
   → [显示3位接单者卡片]

7. 右滑卡片邀请接单者
   Toast："邀请已发送！"
```

**接单模式流程**：
```
1. 点击"找设计任务"按钮
   AI："找到了一些适合你的设计任务！"
   → [显示3个设计任务卡片]

2. 右滑任务卡片
   Toast："申请已提交！等待发单者回复"
```

**技术细节**：
- beforeCards和afterCards都支持specialType渲染（Lines 1408-1693）
- 按钮交互直接操作状态，无需聊天输入
- 使用setTimeout实现流畅的消息和卡片显示时序
- Toast提供即时反馈，AI消息提供流程说明

**待完成集成**：
- ⏳ 后端API：POST /api/tasks/create-with-payment
- ⏳ 实际支付SDK集成（微信/支付宝）
- ⏳ 任务编辑功能实现
- ⏳ 接单者邀请API调用
- ⏳ 实时通知更新机制
    "帮忙代课签到"
    
    // AI自动提取信息
    title: "做海报"
    skills: ["平面设计"]
    category: "创意设计"
    
    // AI引导补全
    "好的，已记录 ✓\n\n还需要：预算范围是什么？"
```

**用户体验流程**：
```
用户："我想找人做海报"
  ↓
AI："好的！我来帮你发布这个任务 📝
     我已经理解了你的基本需求："做海报"。
     为了帮你找到最合适的人，我还需要了解：
     • 详细描述是什么？"
  ↓
用户："需要设计一个宣传海报，A3大小"
  ↓
AI："好的，已记录 ✓
     还需要：预算范围是什么？"
  ↓
用户："100-200元"
  ↓
AI："太好了！任务信息已经完整 ✅
     让我为你生成任务预览，请查看并确认..."
  ↓
[显示任务预览卡片]
  ↓
用户：点击"确认发布"
  ↓
AI："太好了！任务信息已确认 ✅
     接下来需要支付任务预算以托管资金..."
  ↓
[显示支付界面]
  ↓
用户：选择微信支付
  ↓
AI："支付成功！✅ 资金已托管到平台
     正在为你匹配最合适的接单者..."
  ↓
[显示3位接单者卡片供浏览和邀请]
```

**待完成集成**：
- ⏳ 后端API：POST /api/tasks/create-with-payment
- ⏳ 实际支付SDK集成（微信/支付宝）
- ⏳ 任务编辑功能（用户点击"修改"后）
- ⏳ 接单者邀请API调用

---

### 1.2 ChatCards - 双模式实现（用户决策 2.1 - 删除matchScore/whyMatch）

**文件**：`src/components/ChatCards.tsx` (713行)

```typescript
[ ] 删除matchScore/whyMatch字段

// ❌ 删除这些字段
interface Profile {
  // matchScore: number  // 删除
  // whyMatch: string[]  // 删除
}

[ ] 实现双模式显示逻辑

export function ChatCards({ 
  currentRole, 
  aiGeneratedProfiles 
}: ChatCardsProps) {
  
  const renderCard = (profile: Profile, isExpanded: boolean) => {
    if (currentRole === 'freelancer') {
      // 接单者模式：显示任务卡片
      return (
        <Card>
          {/* ✅ 折叠态：发单者头像 + 名字 + 任务标题 */}
          <div className="p-4">
            {/* 顶部：头像 + 发单者名字 + 任务标题 */}
            <div className="flex items-start gap-3 mb-3">
              <Avatar 
                src={profile.poster.avatar} 
                size="lg" 
                fallback={profile.poster.name[0]}
                className="flex-shrink-0"
              />
              
              <div className="flex-1 min-w-0">
                {/* ✅ 发单者名字 */}
                <p className="text-sm text-gray-500 mb-1">{profile.poster.name}</p>
                
                {/* ✅ 任务标题 */}
                <h3 className="font-semibold text-lg line-clamp-2">{profile.taskTitle}</h3>
              </div>
              
              {/* 预算（右上角） */}
              <span className="text-xl font-bold text-green-600 flex-shrink-0">
                ¥{profile.budgetMax}
              </span>
            </div>
            
            {/* 简略内容详情 */}
            <p className="text-sm text-gray-500 line-clamp-2 mb-2">
              {profile.description}
            </p>
            
            {/* 类别Tag + 截止日期 */}
            <div className="flex items-center gap-2 mb-2">
              <Badge>{profile.category}</Badge>
              <Badge variant="outline">{profile.skillsRequired[0]}</Badge>
              <span className="text-sm text-gray-600 ml-auto">
                📅 {formatDate(profile.deadline)}
              </span>
            </div>
          </div>
          
          {/* ✅ 展开态：完整描述 + 附件 */}
          {isExpanded && (
            <div className="px-4 pb-4 border-t pt-4">
              <h4 className="font-medium mb-2">任务详情</h4>
              <p className="text-sm text-gray-700 whitespace-pre-wrap">
                {profile.description}
              </p>
              
              {profile.attachments && (
                <div className="mt-3">
                  <p className="text-sm font-medium mb-2">附件</p>
                  {profile.attachments.map(file => (
                    <div key={file.id} className="text-sm text-blue-600">
                      📎 {file.name}
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}
        </Card>
      )
    } else {
      // 发单者模式：显示接单者卡片
      return (
        <Card>
          {/* ✅ 折叠态：接单者头像 + 姓名 + 学校 + stat */}
          <div className="p-4">
            {/* 顶部：头像 + 名字 + 学校 */}
            <div className="flex items-start gap-3 mb-3">
              <Avatar 
                src={profile.avatar} 
                size="lg" 
                fallback={profile.name[0]}
                className="flex-shrink-0"
              />
              
              <div className="flex-1 min-w-0">
                {/* ✅ 接单者名字 */}
                <h3 className="font-semibold text-lg mb-1">{profile.name}</h3>
                
                {/* 学校信息 */}
                <p className="text-sm text-gray-500">{profile.university?.name || '未填写学校'}</p>
              </div>
            </div>
            
            {/* 技能标签 */}
            <div className="flex gap-2 mb-3">
              {profile.topSkills.slice(0, 3).map(skill => (
                <Badge key={skill} size="sm">{skill}</Badge>
              ))}
            </div>
            
            {/* ✅ 用户要求简化：只保留评分和完成任务数 */}
            <div className="flex gap-4 text-sm text-gray-600">
              <span>⭐ {profile.rating.toFixed(1)}</span>
              <span>📋 {profile.completedTasks}个任务</span>
            </div>
          </div>
          
          {/* ✅ 展开态：显示Profile所有内容 */}
          {isExpanded && (
            <div className="px-4 pb-4 border-t pt-4">
              <ProfileView 
                userId={profile.userId} 
                compact={true}  // 紧凑模式
              />
            </div>
          )}
        </Card>
      )
    }
  }
  
  return (
    <div className="px-4 mb-4">
      <Swiper {...swiperConfig}>
        {aiGeneratedProfiles.map(profile => (
          <SwiperSlide key={profile.id}>
            {renderCard(profile, expandedCardId === profile.id)}
          </SwiperSlide>
        ))}
      </Swiper>
    </div>
  )
}

[ ] 修改右滑行为：直接申请（用户决策 5.1 - 极简申请流程）

const handleSwipeRight = async (profile: Profile) => {
  if (currentRole === 'freelancer') {
    // ✅ 接单者右滑任务卡片 → 直接申请（无表单）
    try {
      const application = await applyForTask({
        taskId: profile.id,
        message: generateApplicationMessage(userProfile, profile),  // AI生成
        quotedPrice: profile.budgetMax,
        estimatedDays: estimateDays(profile)
      })
      
      toast.success('申请已提交！等待发单者回复')
      navigate('/messages')
      
    } catch (error) {
      toast.error('申请失败，请重试')
    }
  } else {
    // 发单者右滑接单者 → 邀请合作
    sendInvitation(profile.id)
  }
}

// ❌ 删除原有的WhisperMessageDialog
```

---

### 1.3 BottomNavigation - 4个Tab（用户决策 1.1 - 方案A）

**文件**：`src/components/BottomNavigation.tsx`

```typescript
[ ] 修改导航配置为4个Tab

const navItems = [
  { 
    path: '/home',  // ✅ ChatInterface（AI对话 + ChatCards）
    label: 'AI助手', 
    icon: <Bot />, 
    activeIcon: <BotFilled /> 
  },
---

### 1.4 ProfileView - 保留原版风格 + 合并档案/设置/交易（用户决策 4.2 - 修正版）

**文件**：`src/components/ProfileView.tsx` + `src/types/user.ts`

**🎨 重要设计原则（用户强调）**：
- ✅ **保留原版ProfileView.tsx的Card-based sections设计风格**
- ✅ **不重新设计UI**，只是在原sections基础上添加功能
- ✅ 保留原有sections：基本信息、技能、作品集、学校等
- ✅ 删除sections：goals、demands、resources（pivot简化）
- ✅ 新增sections：钱包、设置
- ✅ 保留原有特色功能：可编辑、AI建议、完成度显示

```typescript
[x] 删除UserProfile接口中的匹配平台字段

// src/types/user.ts 或 App.tsx
interface UserProfile {
  // ❌ 删除这些字段
  // goals: string[]
  // demands: string[]
  // resources: string[]
  
  // ✅ 保留原有字段
  id: string
  name: string
  profilePhoto?: string
  birthday: string
  gender: string
  location: string
  hobbies: string[]
  languages: string[]
  oneSentenceIntro?: string
  skills: string[]
  projects: { title: string; role: string; description: string; referenceLinks: string[] }[]
  institutions: { name: string; role: string; description: string; verified: boolean }[]
  university?: { name: string; verified: boolean }
  
  // ✅ 新增pivot字段
  rating: number  // 综合评分
  completedTasks: number  // 完成任务数
  postedTasks: number  // 发布任务数
  
  // ✅ 新增钱包字段
  wallet?: {
    balance: number
    frozenAmount: number
    recentTransactions: {
      type: 'income' | 'expense'
      amount: number
      description: string
      date: string
    }[]
  }
}

[x] 在ProfileView.tsx的profileSections数组中添加新sections

// src/components/ProfileView.tsx
// 在原有sections（skills, projects, resources, institutions, university）之后添加

const profileSections = [
  // ... 原有sections保持不变 ...
  
  // ✅ 新增：钱包section
  {
    id: 'wallet',
    title: '钱包',
    icon: Wallet,
    content: (
      <div className="space-y-3">
        <div className="grid grid-cols-2 gap-3">
          <div className="bg-gradient-to-br from-green-50 to-green-100 p-3 rounded-lg border border-green-200">
            <div className="text-xs text-green-600 mb-1">余额</div>
            <div className="text-xl font-bold text-green-700">¥{userProfile.wallet?.balance || 0}</div>
          </div>
          <div className="bg-gradient-to-br from-blue-50 to-blue-100 p-3 rounded-lg border border-blue-200">
            <div className="text-xs text-blue-600 mb-1">冻结金额</div>
            <div className="text-xl font-bold text-blue-700">¥{userProfile.wallet?.frozenAmount || 0}</div>
          </div>
        </div>
        
        {/* 最近交易 */}
        <div className="space-y-2">
          <div className="text-sm font-medium text-gray-700">最近交易</div>
          {userProfile.wallet?.recentTransactions?.slice(0, 3).map((tx, idx) => (
            <div key={idx} className="flex items-center justify-between p-2 bg-gray-50 rounded-lg">
              <div className="flex items-center gap-2">
                {tx.type === 'income' ? <ArrowDownLeft size={16} className="text-green-600" /> : <ArrowUpRight size={16} className="text-red-600" />}
                <div>
                  <div className="text-sm">{tx.description}</div>
                  <div className="text-xs text-gray-500">{tx.date}</div>
                </div>
              </div>
              <div className={`text-sm font-medium ${tx.type === 'income' ? 'text-green-600' : 'text-red-600'}`}>
                {tx.type === 'income' ? '+' : '-'}¥{tx.amount}
              </div>
            </div>
          )) || <p className="text-sm text-gray-400 italic">暂无交易记录</p>}
        </div>
      </div>
    )
  },
  
  // ✅ 新增：设置section
  {
    id: 'settings',
    title: '设置',
    icon: Settings,
    content: (
      <div className="space-y-2">
        <button className="w-full flex items-center justify-between p-3 bg-gray-50 hover:bg-gray-100 rounded-lg transition-colors">
          <div className="flex items-center gap-3">
            <Bell size={18} className="text-gray-600" />
            <span className="text-sm">通知设置</span>
          </div>
          <ArrowUpRight size={16} className="text-gray-400" />
        </button>
        
        <button className="w-full flex items-center justify-between p-3 bg-gray-50 hover:bg-gray-100 rounded-lg transition-colors">
          <div className="flex items-center gap-3">
            <Shield size={18} className="text-gray-600" />
            <span className="text-sm">隐私设置</span>
          </div>
          <ArrowUpRight size={16} className="text-gray-400" />
        </button>
        
        <button className="w-full flex items-center justify-between p-3 bg-gray-50 hover:bg-gray-100 rounded-lg transition-colors">
          <div className="flex items-center gap-3">
            <User size={18} className="text-gray-600" />
            <span className="text-sm">账号管理</span>
          </div>
          <ArrowUpRight size={16} className="text-gray-400" />
        </button>
        
        <button className="w-full flex items-center justify-between p-3 bg-gray-50 hover:bg-gray-100 rounded-lg transition-colors">
          <div className="flex items-center gap-3">
            <Languages size={18} className="text-gray-600" />
            <span className="text-sm">语言设置</span>
          </div>
          <ArrowUpRight size={16} className="text-gray-400" />
        </button>
      </div>
    )
  }
]

[x] 在Profile Summary Card中更新stats显示

// ProfileView.tsx - Profile Summary Card中的stats
<div className="mt-4 grid grid-cols-2 gap-3">
  <div className="bg-gradient-to-br from-green-50 to-green-100 p-3 rounded-lg border border-green-200">
    <div className="flex items-center gap-2 mb-1">
      <CheckCircle size={14} className="text-green-600" />
      <span className="text-xs text-gray-600">完成任务</span>
    </div>
    <div className="text-lg font-bold text-green-700">{userProfile.completedTasks}单</div>
  </div>
  
  <div className="bg-gradient-to-br from-blue-50 to-blue-100 p-3 rounded-lg border border-blue-200">
    <div className="flex items-center gap-2 mb-1">
      <Star size={14} className="text-blue-600" />
      <span className="text-xs text-gray-600">综合评分</span>
    </div>
    <div className="text-lg font-bold text-blue-700">{userProfile.rating.toFixed(1)}★</div>
  </div>
</div>

[x] 删除goals/demands相关代码

// 移除以下内容：
// - renderGoalsEdit() 函数
// - renderDemandsEdit() 函数
// - profileSections中的goals和demands sections
// - getSectionKeys中的'goals'和'demands' cases
// - startEditing中的goals/demands初始化
// - generateSuggestion中的goals/demands cases
// - handleAcceptSuggestion中的goals/demands cases
          <div className="grid grid-cols-2 gap-3">
            {profile.portfolio.map(work => (
              <div key={work.id} className="relative">
                <img src={work.thumbnail} className="rounded w-full aspect-square object-cover" />
                <p className="text-xs text-gray-600 mt-1 line-clamp-1">{work.title}</p>
              </div>
            ))}
          </div>
        </Card>
      )}
    </div>
  )
}
```

---

### 1.5 App.tsx - 删除Whisper/Receives相关类型

**文件**：`src/App.tsx` (636行)

```typescript
[ ] 删除Whisper相关接口定义

// ❌ 删除这些接口
// interface WhisperMessage { ... }
// interface ReceivesTransaction { ... }

[ ] 删除UserProfile中的相关字段

interface UserProfile {
  // ❌ 删除
  // whispersSent: number
  // whispersReceived: number
  // receivesBalance: number
  
  // ✅ 新增：钱包相关
  walletBalance: number  // 可用余额
  frozenAmount: number  // 冻结金额（订单中）
}
```

---
  { 
    path: '/messages',  // ✅ 新：用户间聊天（NEW核心功能）
    label: '消息', 
    icon: <MessageCircle />, 
    activeIcon: <MessageCircleFilled /> 
  },
  { 
    path: '/profile', 
    label: '我的', 
    icon: <User />, 
    activeIcon: <UserFilled /> 
  }
]

// ❌ 删除第4个Tab的原Whisper/Receives逻辑
```

---

### 1.4 ProfileView - 删除goals/demands/resources + 极简stat（用户决策 4.2）

**文件**：`src/components/ProfileView.tsx` + `src/types/user.ts`
        <Badge variant="warning">待发布</Badge>
      </div>
      
      <div className="space-y-3">
        <div>
          <p className="text-sm text-gray-600">标题</p>
          <p className="font-medium">{task.title}</p>
        </div>
        
        <div>
          <p className="text-sm text-gray-600">预算</p>
          <p className="text-orange-500 font-bold">¥{task.budgetMin}-{task.budgetMax}</p>
        </div>
        
        <div>
          <p className="text-sm text-gray-600">截止时间</p>
          <p>{formatDate(task.deadline)}</p>
        </div>
        
        <div>
          <p className="text-sm text-gray-600">所需技能</p>
          <div className="flex flex-wrap gap-2">
            {task.skills.map(skill => (
              <Badge key={skill}>{skill}</Badge>
            ))}
          </div>
        </div>
        
        <div>
          <p className="text-sm text-gray-600">任务描述</p>
          <p className="text-gray-700">{task.description}</p>
        </div>
        
        {task.attachments?.length > 0 && (
          <div>
            <p className="text-sm text-gray-600">参考图片</p>
            <div className="grid grid-cols-3 gap-2">
              {task.attachments.map(file => (
                <img key={file.id} src={file.url} className="rounded" />
              ))}
            </div>
          </div>
        )}
      </div>
      
      <div className="flex gap-2 mt-4">
        <Button
          variant="primary"
          onClick={handlePublish}
          className="flex-1"
        >
          ✅ 发布任务
        </Button>
        <Button
          variant="outline"
          onClick={() => setIsEditing(true)}
        >
          ✏️ 编辑
        </Button>
        <Button
          variant="ghost"
          onClick={handleRegenerate}
        >
          🔄 重新生成
        </Button>
      </div>
    </Card>
  )
}

[ ] 实现发布任务API调用

const handlePublish = async () => {
  try {
    const response = await fetch(`/api/tasks/${task.id}/publish`, {
      method: 'POST'
    })
    
    if (response.ok) {
      showToast({ message: '任务已发布！等待接单者申请', icon: '✅' })
      // 更新消息状态为"已发布"
      updateMessageComponent(<PublishedTaskCard task={task} />)
    }
  } catch (error) {
    showToast({ message: '发布失败，请重试', icon: '❌' })
  }
}
```

---

### 1.3 ChatCards - 双模式卡片实现

**文件**：`src/components/ChatCards.tsx`

```typescript
[ ] 删除matchScore和whyMatch相关代码

// ❌ 删除
<Badge variant="gradient">匹配度 {profile.matchScore}分</Badge>

// ❌ 删除
<section className="bg-blue-50 p-3 rounded">
  <h4>为什么推荐</h4>
  <p>{profile.whyMatch}</p>
</section>

[ ] 根据角色渲染不同卡片内容

interface ChatCardsProps {
  profiles: Profile[]
  currentRole: 'freelancer' | 'poster'
  onSwipe: (direction: 'left' | 'right') => void
}

export function ChatCards({ profiles, currentRole, onSwipe }: ChatCardsProps) {
  const currentProfile = profiles[currentIndex]
  
  return (
    <div className="card-container">
      {currentRole === 'freelancer' ? (
        <TaskCard task={currentProfile} onSwipe={onSwipe} />
      ) : (
        <FreelancerCard freelancer={currentProfile} onSwipe={onSwipe} />
      )}
    </div>
  )
}

[ ] 实现TaskCard组件（接单者视角）

function TaskCard({ task, onSwipe }) {
  return (
    <Card>
      {/* 头像：发单者头像 */}
      <Avatar src={task.poster.avatar} size="large" />
      
      {/* 任务标题 + 发单者昵称 */}
      <h3 className="text-lg font-semibold">
        {task.title}
        <span className="text-sm text-gray-500 ml-2">by {task.poster.name}</span>
      </h3>
      
      {/* 预算（删除匹配度） */}
      <div className="flex items-center justify-between">
        <span className="text-orange-500 font-bold text-xl">
          ¥{task.budgetMin}-{task.budgetMax}
        </span>
      </div>
      
      {/* 所需技能 */}
      <div className="flex flex-wrap gap-2">
        {task.skills.map(skill => (
          <Badge key={skill}>{skill}</Badge>
        ))}
      </div>
      
      {/* 截止时间 */}
      <div className="flex items-center text-red-500">
        <Clock className="w-4 h-4 mr-1" />
        还剩 {formatDeadline(task.deadline)}
      </div>
      
      {/* 申请人数 */}
      <div className="text-sm text-gray-600">
        已有 {task.applicationCount} 人申请
      </div>
      
      {/* 展开态：任务详情 */}
      {isExpanded && (
        <>
          <section>
            <h4>任务描述</h4>
            <p>{task.description}</p>
          </section>
          
          <section>
            <h4>交付要求</h4>
            <ul>
              {task.deliverables.map(item => (
                <li key={item}>{item}</li>
              ))}
            </ul>
          </section>
          
          {task.attachments.length > 0 && (
            <section>
              <h4>参考图片</h4>
              <div className="grid grid-cols-2 gap-2">
                {task.attachments.map(file => (
                  <img key={file.id} src={file.url} />
                ))}
              </div>
            </section>
          )}
          
          {/* 发单者信息（精简） */}
          <section className="bg-gray-50 p-3 rounded">
            <h4>发单者信息</h4>
            <div className="flex items-center gap-3">
              <Avatar src={task.poster.avatar} />
              <div>
                <p className="font-medium">{task.poster.name}</p>
                <p className="text-sm text-gray-500">{task.poster.university.name}</p>
                <div className="flex gap-2 mt-1">
                  <Badge variant="outline" size="sm">
                    ★ {task.poster.posterRating.toFixed(1)}
                  </Badge>
                  <Badge variant="outline" size="sm">
                    发单 {task.poster.postedTasksCount}次
                  </Badge>
                  <Badge variant="outline" size="sm">
                    按时付款 {task.poster.onTimePaymentRate}%
                  </Badge>
                </div>
              </div>
            </div>
          </section>
          
          {/* ❌ 删除AI匹配理由section */}
        </>
      )}
    </Card>
  )
}

[ ] 实现FreelancerCard组件（发单者视角）

function FreelancerCard({ freelancer, onSwipe }) {
  return (
    <Card>
      {/* 头像 */}
      <Avatar src={freelancer.avatar} size="large" />
      
      {/* 昵称 + 学校 */}
      <h3 className="text-lg font-semibold">{freelancer.name}</h3>
      <p className="text-sm text-gray-500">{freelancer.university.name}</p>
      
      {/* ❌ 删除匹配度Badge */}
      
      {/* 技能标签 */}
      <div className="flex flex-wrap gap-2">
        {freelancer.skills.map(skill => (
          <Badge key={skill}>{skill}</Badge>
        ))}
      </div>
      
      {/* 核心stat */}
      <div className="flex justify-between text-sm mt-2">
        <div className="text-center">
          <p className="font-semibold text-orange-500">
            {freelancer.averageRating.toFixed(1)}
          </p>
          <p className="text-gray-500">评分</p>
        </div>
        <div className="text-center">
          <p className="font-semibold text-orange-500">
            {freelancer.completionRate}%
          </p>
          <p className="text-gray-500">完成率</p>
        </div>
        <div className="text-center">
          <p className="font-semibold text-orange-500">
            {freelancer.completedTasksCount}
          </p>
          <p className="text-gray-500">已完成</p>
        </div>
      </div>
      
      {/* 展开态：完整档案 */}
      {isExpanded && (
        <>
          <section>
            <h4>个人简介</h4>
            <p>{freelancer.bio}</p>
          </section>
          
          <section>
            <h4>作品集</h4>
            <div className="grid grid-cols-2 gap-3">
              {freelancer.portfolios.map(work => (
                <div key={work.id} onClick={() => openPortfolio(work)}>
                  <img src={work.referenceLinks[0]} />
                  <p className="text-sm mt-1">{work.title}</p>
                </div>
              ))}
            </div>
          </section>
          
          <section className="bg-gray-50 p-3 rounded">
            <h4>接单数据</h4>
            <div className="grid grid-cols-2 gap-3 text-sm">
              <div>
                <span className="text-gray-600">平均评分：</span>
                <span className="font-semibold ml-1">
                  {freelancer.averageRating.toFixed(2)} ★
                </span>
              </div>
              <div>
                <span className="text-gray-600">完成率：</span>
                <span className="font-semibold ml-1">
                  {freelancer.completionRate}%
                </span>
              </div>
              <div>
                <span className="text-gray-600">已完成任务：</span>
                <span className="font-semibold ml-1">
                  {freelancer.completedTasksCount}个
                </span>
              </div>
              <div>
                <span className="text-gray-600">平均响应：</span>
                <span className="font-semibold ml-1">
                  {Math.floor(freelancer.responseTimeMinutes / 60)}小时
                </span>
              </div>
            </div>
          </section>
          
          <section>
            <h4>最近评价</h4>
            {freelancer.recentReviews.slice(0, 3).map(review => (
              <div key={review.id} className="border-l-2 border-blue-400 pl-3 mb-3">
                <div className="flex items-center gap-2 mb-1">
                  <span className="text-orange-500">
                    ★ {review.overallRating.toFixed(1)}
                  </span>
                  <span className="text-sm text-gray-500">
                    {formatDate(review.createdAt)}
                  </span>
                </div>
                <p className="text-sm text-gray-700">{review.comment}</p>
              </div>
            ))}
          </section>
          
          {/* ❌ 删除AI匹配理由section */}
        </>
      )}
    </Card>
  )
}
```

---

### 1.5 NotificationPanel - 适配任务申请通知（✅ 已完成 - 2025-10-23）

**文件**：`src/components/NotificationPanel.tsx`

**状态**：✅ 已完成

**改动总结**：
- ✅ 更新类型定义：`FriendRequest` → `TaskApplicationNotification`
- ✅ 新增字段：
  - `applicationType`: 'poster_receives_application' | 'freelancer_receives_invitation' | 'freelancer_accepted'
  - `taskId`, `taskTitle`, `taskDescription`, `taskBudget`
  - `applicationMessage` (替代whisper message)
  - `completionRate`, `rating`, `completedTasks` (用户统计)
- ✅ 删除字段：`matchScore`, `mutualInterest`, `goals`, `demands`, `receivesLeft`, `giftedReceives`
- ✅ 删除功能：WeChat号显示、Gift赠送功能

**UI改动**：
```typescript
[x] 通知卡片内容（Lines 360-410）
    - 显示任务标题和申请类型Badge
      * 🔔 待处理（黄色）- poster_receives_application
      * 📨 收到邀请（红色）- freelancer_receives_invitation  
      * ✅ 已接受（蓝色）- freelancer_accepted
    - 显示申请留言（applicationMessage）
    - 显示任务预算（如有）
    - 显示用户统计信息（完成率、评分、已完成任务数）
    - 删除WeChat号、Gift相关UI

[x] 操作按钮（Lines 440-510）- 三种场景
    - 发单者收到申请：显示"接受"和"拒绝"按钮
    - 接单者收到邀请：显示"接受邀请"和"拒绝"按钮
    - 接单者已接受：显示"联系对方"按钮（跳转至消息页面）
    - 删除"Whisper Back"按钮
    - 保留Quote按钮（MessageCircle图标）用于查看原始信息

[x] 用户档案弹窗
    - 替换"Receives Left"为用户统计（完成率、评分）
    - 删除"Goals & Demands"板块
    - 新增"接单统计"板块（completedTasks/completionRate/rating）

[x] 文案更新
    - 面板标题："任务申请通知"
    - 空状态："当有人申请你的任务或接受你的申请时，会在这里显示"
```

**Handler函数**：
```typescript
[x] handleAcceptApplication() - Lines 148-182
    - 接受申请/邀请（发单者或接单者）
    - 集成API调用模式：POST /api/tasks/{taskId}/applications/{applicationId}/accept
    - 动画效果：卡片淡出并从列表移除
    - Toast提示成功或失败

[x] handleViewTask() - Lines 184-197
    - 查看任务详情（接单者）
    - 导航逻辑：优先使用navigate函数，降级为console.log
    
[x] 保留handleWhisperBack()用于兼容性（将来可删除）
```

**Mock数据**：
```typescript
[x] mockNotifications数组（Lines 1000-1227）
    - 5个示例通知覆盖所有场景：
      * 2个发单者收到的申请（poster_receives_application）
      * 2个接单者收到的邀请（freelancer_receives_invitation）
      * 1个接单者已接受的通知（freelancer_accepted）
    - 包含完整的用户信息、任务信息、统计数据
```

**App.tsx集成**（2024-10-23完成）：
```typescript
[x] 导入mockNotifications（Line 12）
[x] 初始化friendRequests状态（Lines 379-381）
    - setFriendRequests(mockNotifications)
    
[x] NotificationPanel集成（Lines 560-585）
    - onAcceptApplication回调：console.log + 未来API调用占位
    - onViewTaskDetail回调：console.log + 导航逻辑占位
    - onQuoteContact回调：导航至消息页面（screenName: 'messages'）
    
[x] 修复handleAddWhisperToHistory（Lines 290-315）
    - 适配TaskApplicationNotification类型
    - 为旧字段提供默认值（goals: [], demands: [], matchScore: 85）
    
[x] 修复handleViewOriginalCard（Lines 325-350）
    - 条件性添加任务相关字段（applicationType, taskId等）
    - 保持向后兼容
```

**TypeScript修复**：
- ✅ 所有类型错误已解决（2024-10-23验证：get_errors返回无错误）
- ✅ 创建FriendRequest类型别名保持向后兼容
- ✅ 使用条件类型检查避免字段缺失错误

**向后兼容**：
- ✅ 保留`FriendRequest`作为`TaskApplicationNotification`的类型别名
- ✅ 保留原有props接口（`friendRequests`数组等）
- ✅ 保留WhisperMessageDialog组件（将来可移除）

**待完成集成**：
- ⏳ 后端API实现：POST /api/tasks/{taskId}/applications/{applicationId}/accept
- ⏳ 真实导航实现：替换console.log为React Router navigate
- ⏳ 任务详情页面实现
- ⏳ 实时通知更新机制

---

## 📋 Phase 2: ProfileSetupWizard简化（预计1天）

**文件**：`src/components/ProfileSetupWizard.tsx`

```typescript
[ ] 删除Goals步骤（Step 4）

// ❌ 删除整个GoalsStep组件
// ❌ 删除goalsStep相关逻辑

[ ] 删除Demands步骤（Step 5）

// ❌ 删除整个DemandsStep组件
// ❌ 删除demandsStep相关逻辑

[ ] 删除Resources步骤（Step 6）

// ❌ 删除整个ResourcesStep组件
// ❌ 删除resourcesStep相关逻辑

[ ] 调整步骤顺序

const steps = [
  { id: 1, name: 'Demographics', component: DemographicsStep },
  { id: 2, name: 'Skills', component: SkillsStep },
  { id: 3, name: 'Portfolio', component: PortfolioStep }, // 改名
  { id: 4, name: 'Bio', component: BioStep },
  { id: 5, name: 'University', component: UniversityStep },
  { id: 6, name: 'Authentication', component: AuthenticationStep },
]

// 从9步减少为6步

[ ] 修改PortfolioStep文案

<h3>展示你的作品</h3>
<p>上传你最满意的作品，提升接单成功率</p>

<Input
  label="作品标题"
  placeholder="例如：某品牌Logo设计"
/>
<Textarea
  label="作品描述"
  placeholder="简述作品背景和成果..."
/>
<FileUpload
  label="作品图片（最多5张）"
  accept="image/*"
  maxFiles={5}
/>
```

## 📋 Phase 3: ProfileView调整（预计半天）

**✅ 已在Phase 1.4完成**

用户决策 4.2 要求的极简stat设计已整合到Phase 1.4中实施：
- 删除goals/demands/resources字段
- 无Tab切换，3个stat横向排列（评分、完成任务、发布任务）
- 保留技能标签和作品集展示

---

## 📋 Phase 4: 设置页调整（预计半天）

**文件**：`src/screens/SettingsScreen.tsx`

```typescript
[ ] 删除Receives/Pro会员相关菜单

// ❌ 删除这些菜单项
{
  icon: CreditCard,
  label: '充值Receives',
  route: '/settings/topup'
},
{
  icon: Crown,
  label: 'Pro会员升级',
  route: '/settings/membership'
},

[ ] 新增钱包相关菜单（用户决策 4.1 - Minimalist设计）

// ✅ 新增钱包菜单
{
  icon: Wallet,
  label: '我的钱包',
  description: '查看余额和提现',
  route: '/wallet',  // 直接跳转到WalletView
},
{
  icon: TrendingUp,
  label: '收益明细',
  description: '查看历史收入',
  route: '/wallet?tab=income'  // WalletView的展开板块
},
{
  icon: Receipt,
  label: '支出记录',
  description: '发单支付历史',
  route: '/wallet?tab=expenses'
},
```

---

## 📋 Phase 5: API集成（预计2-3天）

### 5.1 创建API客户端函数

**文件**：`src/services/api.ts`

```typescript
[ ] 新增任务相关API

// 创建任务草稿（AI生成）
export async function createTaskFromConversation(data: {
  conversationHistory: Message[]
  userProfile: UserProfile
}): Promise<TaskDraft> {
  const response = await fetch('/api/tasks/create-from-conversation', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(data)
  })
  return response.json()
}

// 发布任务
export async function publishTask(taskId: number): Promise<Task> {
  const response = await fetch(`/api/tasks/${taskId}/publish`, {
    method: 'POST'
  })
  return response.json()
}

// 搜索任务（接单者视角）
export async function searchTasks(params: {
  query: string
  skills?: string[]
  budgetMin?: number
  budgetMax?: number
  location?: string
}): Promise<Task[]> {
  const queryString = new URLSearchParams(params as any).toString()
  const response = await fetch(`/api/tasks/search?${queryString}`)
  return response.json()
}

// 搜索接单者（发单者视角）
export async function searchFreelancers(params: {
  query: string
  skills?: string[]
  minRating?: number
  minCompletionRate?: number
}): Promise<UserProfile[]> {
  const queryString = new URLSearchParams(params as any).toString()
  const response = await fetch(`/api/freelancers/search?${queryString}`)
  return response.json()
}

// 申请任务
export async function applyForTask(data: {
  taskId: number
  message: string
  quotedPrice?: number
  estimatedDays?: number
}): Promise<TaskApplication> {
  const response = await fetch(`/api/tasks/${data.taskId}/apply`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(data)
  })
  return response.json()
}

// 获取我的订单
export async function getMyOrders(role?: 'freelancer' | 'poster' | 'all'): Promise<Order[]> {
  const response = await fetch(`/api/orders/my-orders?role=${role || 'all'}`)
  return response.json()
}

// 支付订单
export async function payOrder(orderId: number, paymentMethod: string): Promise<{
  paymentUrl: string
  transactionId: string
}> {
  const response = await fetch(`/api/orders/${orderId}/pay`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ paymentMethod })
  })
  return response.json()
}

// 提交交付物
export async function submitDeliverables(orderId: number, data: {
  files: File[]
  message: string
}): Promise<Order> {
  const formData = new FormData()
  data.files.forEach(file => formData.append('files', file))
  formData.append('message', data.message)
  
  const response = await fetch(`/api/orders/${orderId}/submit`, {
    method: 'POST',
    body: formData
  })
  return response.json()
}

// 验收订单
export async function approveOrder(orderId: number): Promise<Order> {
  const response = await fetch(`/api/orders/${orderId}/approve`, {
    method: 'POST'
  })
  return response.json()
}

// 提交评价
export async function submitReview(data: {
  orderId: number
  qualityRating: number
  speedRating: number
  communicationRating: number
  comment: string
}): Promise<Review> {
  const response = await fetch('/api/reviews/create', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(data)
  })
  return response.json()
}

[ ] 删除废弃API

// ❌ 删除
export async function topupReceives(amount: number) { ... }
export async function upgradeToPro() { ... }
export async function sendWhisper(targetUserId: number, message: string) { ... }
```

---

## 📋 Phase 5.10: 新组件开发（预计2天 - 极简版）

### 必须新增的组件（10个核心组件 - 用户确认）

**1. WalletView.tsx** - Minimalist钱包页面（用户决策 4.1）
```typescript
// ✅ 已在Phase 5.8详细设计
// 核心：Collapsible组件实现可展开板块
// 包含：余额卡片、冻结金额、交易明细、提现/充值
```

**2. OrderDetailView.tsx** - 简化订单详情（用户决策 3.2）
```typescript
// ✅ 已在Phase 5.9详细设计
// 核心：Card板块设计（参考NotificationPanel）
// 包含：任务信息Card、对方信息Card、交付物Card
```

**3. MessageListView.tsx** - 用户间聊天列表（NEW功能）✅ 已完成
```typescript
// ✅ 显示所有对话列表（mockConversations）
// ✅ 区分任务申请消息 vs 普通聊天（taskTitle badge）
// ✅ 支持未读消息提示（Avatar右上角红色badge）
// ✅ 点击对话进入对话详情视图
// ✅ 对话界面包含：返回按钮、头像、姓名、任务标题、消息气泡、输入框
// ✅ 消息气泡区分左右（对方消息左边灰色，我的消息右边蓝色）
// ✅ 时间戳格式化（分钟前、小时前、天前）
// ✅ 输入框支持Enter发送
// ✅ Paperclip附件上传按钮（预留接口）
// ✅ Send发送按钮（输入为空时禁用）
```

**4. ChatConversation.tsx** - 单个对话页面（NEW功能）
```typescript
// ✅ 已集成在MessageListView.tsx内部（条件渲染）
// ✅ 1对1聊天界面（selectedConversation !== null时显示）
// ✅ 支持发送图片、文件（Paperclip按钮预留）
// ⏳ 显示对方在线状态（TODO：需要WebSocket）
```

**5. TaskCreationWizard.tsx** - AI任务发布向导（已存在，需调整）
```typescript
// 简化步骤：标题 → 描述 → 预算 → 截止时间
// 集成AI生成建议
// 嵌入在ChatInterface消息流中
```

**6. OrderManagementView.tsx** - 订单/任务管理页（对应Tab 2）✅ 已完成
```typescript
// ✅ 顶部Tab切换：我接的单 | 我发的单（activeTab state）
// ✅ 列表显示订单状态（5种状态：pending/in_progress/submitted/completed/cancelled）
// ✅ 快速筛选：进行中、已完成（通过status字段筛选）
// ✅ 订单卡片设计：
//    - 标题 + 状态badge（颜色区分：黄色pending、蓝色进行中、紫色待验收、绿色完成、灰色取消）
//    - 描述（line-clamp-2截断）
//    - 对方信息（头像、姓名、评分）
//    - 技能标签（skills数组映射为Badge）
//    - 金额 + 截止时间
//    - 操作按钮：查看详情（所有状态）、联系对方（MessageCircle）、验收（submitted状态）、评价（completed状态）
// ✅ 点击"查看详情"打开OrderDetailView弹窗
// ✅ 点击"评价"打开ReviewDialog弹窗
// ✅ Motion动画：卡片渐入、悬停放大
// ✅ Mock数据包含：订单ID、标题、描述、状态、金额、截止时间、对方信息、技能、创建/提交/完成时间
```

**7. FileUploadZone.tsx** - 文件上传组件（已存在）
```typescript
// 作品集上传
// 任务附件上传
// 交付物上传
// 支持拖拽上传
```

**8. ReviewDialog.tsx** - 极简评价对话框（用户决策 5.3）
```typescript
// ✅ 已在Phase 5.7详细设计
// 核心：仅5星评分，无文字评价
```

**9. TaskFilterPanel.tsx** - 任务筛选面板（保留）
```typescript
// 预算范围滑块
// 类别选择
// 截止时间筛选
// 排序选项
```

**10. WithdrawalForm.tsx** - 提现表单（新增）
```typescript
// 提现金额输入
// 银行卡选择
// 到账时间提示
```

---

**❌ 删除的组件（从15个减少到10个）**：
1. ~~OrderStatusTimeline~~ - 删除复杂状态流转图
2. ~~FreelancerSearchView~~ - AI推荐替代人工搜索
3. ~~DisputeDialog~~ - 简化为"举报"按钮
4. ~~WhisperMessageDialog~~ - 删除Whisper功能
5. ~~ReceivesTopupView~~ - 删除Receives虚拟货币

---

## 📋 Phase 6: TypeScript类型更新（预计0.5天 - 极简版减少字段）

**文件**：`src/types/api.ts`

```typescript
[ ] 新增任务相关类型（极简版）

export interface Task {
  id: number
  posterId: number
  poster: {
    id: number
    name: string
    avatar: string
    university: { id: number; name: string }
    posterRating: number  // 发单者评分
    postedTasksCount: number  // 发布任务数
  }
  title: string
  description: string
  budgetMin: number
  budgetMax: number
  finalAmount?: number  // 实际支付金额
  deadline: string
  category: string
  skills: string[]  // 所需技能
  attachments: TaskAttachment[]
  status: 'draft' | 'published' | 'in_progress' | 'submitted' | 'completed' | 'cancelled'
  createdAt: string
  publishedAt?: string
  completedAt?: string
}

export interface TaskAttachment {
  id: number
  url: string
  name: string
  type: 'image' | 'document' | 'other'
}

[ ] 新增申请相关类型（用户决策 5.1 - 右滑直接申请）

export interface TaskApplication {
  id: number
  taskId: number
  freelancerId: number
  freelancer: UserProfile
  message: string  // AI生成的申请话术
  quotedPrice: number
  estimatedDays: number
  status: 'pending' | 'accepted' | 'rejected'
  appliedAt: string
}

[ ] 新增订单相关类型（用户决策 5.2 - 极简验收流程）

export interface Order {
  id: number
  taskId: number
  task: Task
  posterId: number
  poster: UserProfile
  freelancerId: number
  freelancer: UserProfile
  amount: number  // 订单金额
  platformFee: number  // 平台费用（10%）
  freelancerIncome: number  // 接单者收入（90%）
  status: 'paid' | 'in_progress' | 'submitted' | 'completed' | 'disputed'  // ✅ 简化状态
  createdAt: string
  paidAt?: string
  submittedAt?: string
  completedAt?: string
  deliverables: OrderDeliverable[]
  review?: Review  // 单向评价
}

export interface OrderDeliverable {
  id: number
  orderId: number
  fileUrl: string
  fileType: string
  fileName: string
  description: string
  uploadedAt: string
}

[ ] 新增评价类型（用户决策 5.3 - 仅5星评分）

export interface Review {
  id: number
  orderId: number
  reviewerId: number  // 发单者
  revieweeId: number  // 接单者
  overallRating: number  // ✅ 仅5星评分，无分项
  comment: string  // ✅ 留空
  createdAt: string
}

[ ] 新增钱包类型（用户决策 4.1 - Minimalist钱包）

export interface UserWallet {
  userId: number
  availableBalance: number  // 可用余额
  frozenAmount: number  // 冻结金额
  totalIncome: number
  totalExpense: number
  updatedAt: string
}

export interface WalletTransaction {
  id: number
  orderId?: number
  type: 'income' | 'expense' | 'withdrawal' | 'fee'
  amount: number
  balanceAfter: number
  description: string
  createdAt: string
}

[ ] 修改UserProfile类型（极简版）

export interface UserProfile {
  id: string
  name: string
  avatar: string
  bio: string
  
  // ❌ 删除匹配平台字段
  // goals?: string[]
  // demands?: string[]
  // resources?: string[]
  // receivesLeft?: number
  // membership?: 'free' | 'pro'
  
  // ✅ 简化统计字段（用户决策 4.2）
  rating: number  // 综合评分
  completedTasks: number  // 完成任务数
  postedTasks: number  // 发布任务数
  
  // ✅ 保留展示字段
  skills: string[]
  portfolio?: PortfolioItem[]
  university?: { id: number; name: string }
}

export interface PortfolioItem {
  id: number
  title: string
  thumbnail: string
  description: string
  createdAt: string
}
```

---

## 📋 Phase 7: 测试与调试（预计1-2天）

```typescript
[ ] 端到端测试：完整任务流程（极简版）
    1. 发单者与AI对话生成任务草稿
    2. 编辑并发布任务
    3. 切换到接单者角色（顶部按钮切换）
    4. 搜索并浏览任务卡片（ChatCards显示）
    5. 右滑直接申请（无表单，AI生成申请话术）
    6. 发单者在消息列表查看申请并接受
    7. 发单者支付订单（钱包扣款 + 冻结金额）
    8. 接单者提交交付物
    9. 发单者点击"验收通过"或"举报"（极简验收）
    10. 弹出5星评价对话框（无文字评价）
    11. 检查钱包余额更新、stat自动更新

[ ] 角色切换测试（用户决策 2.1）
    - 顶部两个大按钮切换正常
    - 切换后AI欢迎语更新
    - ChatCards显示模式正确（任务卡 vs 接单者卡）
    - Toast提示正常显示

[ ] ChatCards双模式测试（用户决策 2.1）
    - 接单者模式：卡片显示预算、标题、类别、截止日期、简略描述
    - 发单者模式：卡片显示头像、姓名、评分、完成数、专业Tag
    - 展开态：任务卡显示完整描述，接单者卡显示Profile
    - ❌ 确认无matchScore/whyMatch显示

[ ] 极简申请流程测试（用户决策 5.1）
    - 右滑任务卡片直接提交申请
    - AI生成申请话术
    - 跳转到消息列表
    - ❌ 确认无申请表单弹窗

[ ] 极简验收流程测试（用户决策 5.2）
    - 订单详情页只显示"验收通过"和"举报"按钮
    - ❌ 确认无"申请修改"、"申请取消"等按钮
    - 验收通过后自动弹出评价对话框

[ ] 极简评价系统测试（用户决策 5.3）
    - 仅5颗星评分
    - ❌ 确认无文字评价输入框
    - 点击星星直接提交
    - 评分更新到用户rating

[ ] Minimalist钱包测试（用户决策 4.1）
    - 顶部余额卡片大字体显示
    - 可展开板块（冻结金额、交易明细）使用Collapsible组件
    - 提现/充值按钮正常工作
    - 交易明细正确分类显示

[ ] 简化订单详情测试（用户决策 3.2）
    - 顶部显示状态Badge + 任务标题
    - 任务信息Card可点击跳转
    - 对方信息Card显示头像、姓名、评分
    - 交付物Card显示文件列表
    - ❌ 确认无复杂状态流转图

[ ] ProfileView极简stat测试（用户决策 4.2）
    - 3个stat横向排列（评分、完成任务、发布任务）
    - ❌ 确认无Tab切换
    - ❌ 确认无goals/demands/resources显示
    - 技能标签和作品集正常显示

[ ] 底部导航测试（用户决策 1.1）
    - 4个Tab：AI助手、任务/订单、消息、我的
    - 点击跳转正确
    - 当前Tab高亮显示

[ ] 设置页测试
    - ❌ 确认无"充值Receives"菜单
    - ❌ 确认无"Pro会员升级"菜单
    - ✅ 确认有"我的钱包"菜单

[ ] 兼容性测试
    - 移动端响应式布局（iPhone SE、iPhone 14 Pro Max）
    - iOS Safari浏览器兼容
    - Android Chrome浏览器兼容
    - 微信内置浏览器测试（分享功能）
    - 横屏模式适配
```

**测试清单总结**：
- ✅ 完整业务流程测试（发布→申请→支付→验收→评价）
- ✅ 角色切换测试（顶部按钮、AI欢迎语、卡片模式）
- ✅ AI任务生成测试（意图识别、任务卡片显示）
- ✅ 极简流程测试（右滑申请、极简验收、5星评价）
- ✅ Minimalist设计测试（钱包Collapsible、订单详情Card、Profile极简stat）
- ✅ 删除确认测试（无matchScore、无Receives、无Pro会员）
- ✅ 兼容性测试（移动端、iOS/Android、微信）

---

## 📍 路由结构（用户决策 1.2 - 方案A：React Router）

**文件**：`src/App.tsx` 或 `src/router/index.tsx`

```typescript
import { BrowserRouter, Routes, Route } from 'react-router-dom'

const router = (
  <BrowserRouter>
    <Routes>
      {/* 主导航路由（对应底部4个Tab） */}
      <Route path="/home" element={<ChatInterface />} />  {/* AI助手（AI对话+ChatCards） */}
      <Route path="/orders" element={<OrderManagementView />} />  {/* 任务/订单 */}
      <Route path="/messages" element={<MessageListView />} />  {/* 用户间聊天列表 */}
      <Route path="/profile" element={<ProfileView />} />  {/* 我的 */}
      
      {/* 二级页面 */}
      <Route path="/messages/:conversationId" element={<ChatConversation />} />  {/* 单个对话 */}
      <Route path="/tasks/:taskId" element={<TaskDetailView />} />  {/* 任务详情 */}
      <Route path="/orders/:orderId" element={<OrderDetailView />} />  {/* 订单详情 */}
      <Route path="/profile/:userId" element={<ProfileView />} />  {/* 其他用户档案 */}
      <Route path="/wallet" element={<WalletView />} />  {/* 钱包 */}
      
      {/* 设置相关 */}
      <Route path="/settings" element={<SettingsScreen />} />
      <Route path="/settings/edit-profile" element={<EditProfileView />} />
      <Route path="/settings/withdrawal" element={<WithdrawalForm />} />
      
      {/* 默认路由 */}
      <Route path="/" element={<Navigate to="/home" replace />} />
      <Route path="*" element={<NotFoundView />} />
    </Routes>
    
    {/* BottomNavigation在所有页面显示 */}
    <BottomNavigation />
  </BrowserRouter>
)
```

**路由说明**：
- `/home` = ChatInterface（AI对话，非任务浏览）
- `/messages` = 用户间聊天（NEW核心功能）
- `/orders` = 任务/订单管理（双角色视图）
- `/profile` = 我的档案（极简stat）

---

## ✅ 实施优先级

**Week 1**：
1. ChatInterface角色切换器 + BottomNavigation（1天）
2. ChatCards双模式实现（2天）
3. 路由结构搭建 + MessageListView/ChatConversation（2天）

**Week 2**：
4. AI任务生成流程 + TaskCreationWizard（2天）
5. WalletView + OrderDetailView（Minimalist设计）（2天）
6. ProfileView极简stat + 设置页调整（1天）

**Week 3**：
7. OrderManagementView + 极简申请/验收流程（2天）
8. ReviewDialog（5星评价）+ TypeScript类型（1天）
9. 端到端测试（2天）

---

**文档版本**：v3.0（极简版 - 根据用户决策更新）
**最后更新**：2025-10-22  
**状态**：✅ 已更新（极简设计原则，减少组件数量）

---

## 🎯 新增：极简化流程实施（根据用户决策）

### Phase 5.5: 简化任务申请流程（用户决策 5.1）

**用户确认的流程**：右滑卡片直接申请，无需填写表单

```typescript
// ChatCards.tsx - 修改右滑行为

[ ] 删除WhisperMessageDialog，改为直接提交申请

const handleSwipeRight = async (profile: Profile) => {
  if (currentRole === 'freelancer') {
    // 接单者右滑任务卡片 → 直接申请
    try {
      // ✅ AI自动生成申请话术（无需用户填写）
      const application = await applyForTask({
        taskId: profile.id,
        message: generateApplicationMessage(userProfile, profile),  // AI生成
        quotedPrice: profile.budgetMax,  // 默认预算上限
        estimatedDays: estimateDays(profile)  // AI估算
      })
      
      toast.success('申请已提交！等待发单者回复')
      
      // 自动跳转到消息列表
      navigate('/messages')
      
    } catch (error) {
      toast.error('申请失败，请重试')
    }
  } else {
    // 发单者右滑接单者 → 邀请合作
    sendInvitation(profile.id)
  }
}

// ❌ 删除原有的Whisper对话框
// ❌ 删除手动填写申请表单的逻辑
```

---

### Phase 5.6: 简化订单验收流程（用户决策 5.2）

**用户确认的极简流程**：只有"验收通过"和"举报"两个按钮

```typescript
// OrderDetailView.tsx - 极简验收

[ ] 删除复杂的状态流转UI

// ❌ 删除这些按钮
<Button>申请修改</Button>
<Button>申请取消</Button>
<Button>延长截止时间</Button>

[ ] 保留两个核心按钮

{order.status === 'submitted' && order.role === 'poster' && (
  <div className="fixed bottom-0 left-0 right-0 bg-white border-t p-4 pb-safe flex gap-3">
    <Button 
      variant="primary" 
      className="flex-1"
      onClick={async () => {
        await approveOrder(order.id)
        toast.success('验收通过！款项已结算给接单者')
        // ✅ 弹出5星评价
        setShowReviewDialog(true)
      }}
    >
      ✅ 验收通过
    </Button>
    
    <Button 
      variant="outline" 
      onClick={() => navigate(`/report/${order.id}`)}
    >
      🚨 举报
    </Button>
  </div>
)}
```

---

### Phase 5.7: 极简评价系统（用户决策 5.3）

**用户确认**：仅5星评分，无文字评价

```typescript
// ReviewDialog.tsx - 超级简化

export function ReviewDialog({ orderId, onClose }: ReviewDialogProps) {
  const [rating, setRating] = useState(0)
  
  return (
    <Dialog open onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>评价接单者</DialogTitle>
        </DialogHeader>
        
        {/* 仅5星评分 */}
        <div className="flex justify-center gap-2 my-6">
          {[1, 2, 3, 4, 5].map(star => (
            <Star 
              key={star}
              className={cn(
                "w-12 h-12 cursor-pointer transition-all",
                rating >= star ? "fill-yellow-400 text-yellow-400" : "text-gray-300"
              )}
              onClick={() => setRating(star)}
            />
          ))}
        </div>
        
        <Button 
          disabled={rating === 0}
          onClick={async () => {
            await submitReview({
              orderId,
              overallRating: rating,
              qualityRating: rating,  // 所有分项都用同一评分
              speedRating: rating,
              communicationRating: rating,
              comment: ''  // 无文字评价
            })
            toast.success('评价已提交')
            onClose()
          }}
        >
          提交评价
        </Button>
      </DialogContent>
    </Dialog>
  )
}

// ❌ 删除这些字段
// <Textarea label="文字评价" />
// <RadioGroup label="沟通态度" />
// <RadioGroup label="完成质量" />
```

---

### Phase 5.8: Minimalist钱包页面（用户决策 4.1）

**用户要求**：可展开板块，保持整体干净

```typescript
// WalletView.tsx - 新建

[ ] 创建极简钱包组件

import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '@/components/ui/collapsible'
import { ChevronDown, Lock, History, TrendingUp } from 'lucide-react'

export function WalletView() {
  const [expandedSection, setExpandedSection] = useState<string | null>(null)
  
  return (
    <div className="min-h-screen bg-gray-50 pb-safe">
      {/* 顶部余额卡片 - 大字体极简 */}
      <Card className="m-4 p-6 bg-gradient-to-br from-blue-500 to-blue-600 text-white">
        <p className="text-sm opacity-80">可用余额</p>
        <h1 className="text-4xl font-bold mt-1">¥{wallet.availableBalance}</h1>
        
        <div className="flex gap-3 mt-6">
          <Button variant="secondary" size="sm" className="flex-1">
            提现
          </Button>
          <Button variant="outline" size="sm" className="flex-1 text-white border-white">
            充值
          </Button>
        </div>
      </Card>
      
      {/* 可展开板块 */}
      <div className="px-4 space-y-2">
        {/* 冻结金额 */}
        <Collapsible
          open={expandedSection === 'frozen'}
          onOpenChange={() => setExpandedSection(expandedSection === 'frozen' ? null : 'frozen')}
        >
          <Card className="overflow-hidden">
            <CollapsibleTrigger className="w-full p-4 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <Lock className="w-5 h-5 text-gray-400" />
                <div className="text-left">
                  <p className="font-medium">冻结金额</p>
                  <p className="text-sm text-gray-500">进行中的订单</p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <span className="font-bold">¥{wallet.frozenAmount}</span>
                <ChevronDown className={cn("w-4 h-4 transition-transform", expandedSection === 'frozen' && "rotate-180")} />
              </div>
            </CollapsibleTrigger>
            
            <CollapsibleContent>
              <div className="px-4 pb-4 space-y-2">
                {wallet.frozenOrders.map(order => (
                  <div key={order.id} className="flex justify-between text-sm">
                    <span>订单 #{order.id}</span>
                    <span>¥{order.amount}</span>
                  </div>
                ))}
              </div>
            </CollapsibleContent>
          </Card>
        </Collapsible>
        
        {/* 交易明细 */}
        <Collapsible
          open={expandedSection === 'transactions'}
          onOpenChange={() => setExpandedSection(expandedSection === 'transactions' ? null : 'transactions')}
        >
          <Card className="overflow-hidden">
            <CollapsibleTrigger className="w-full p-4 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <History className="w-5 h-5 text-gray-400" />
                <p className="font-medium">交易明细</p>
              </div>
              <ChevronDown className={cn("w-4 h-4 transition-transform", expandedSection === 'transactions' && "rotate-180")} />
            </CollapsibleTrigger>
            
            <CollapsibleContent>
              <div className="px-4 pb-4 space-y-3">
                {recentTransactions.map(tx => (
                  <div key={tx.id} className="flex justify-between text-sm">
                    <div>
                      <p className="font-medium">{tx.title}</p>
                      <p className="text-gray-500 text-xs">{tx.date}</p>
                    </div>
                    <span className={cn("font-semibold", tx.type === 'income' ? 'text-green-600' : 'text-red-600')}>
                      {tx.type === 'income' ? '+' : '-'}¥{tx.amount}
                    </span>
                  </div>
                ))}
              </div>
            </CollapsibleContent>
          </Card>
        </Collapsible>
      </div>
    </div>
  )
}
```

---

### Phase 5.9: 简化订单详情Card（用户决策 3.2）

**用户要求**：参考NotificationPanel和ContactHistory的Card设计

```typescript
// OrderDetailView.tsx - Card板块设计

[ ] 创建简化版订单详情

export function OrderDetailView({ orderId }: { orderId: string }) {
  return (
    <div className="min-h-screen bg-gray-50 pb-safe">
      <div className="bg-white px-4 py-3 border-b">
        <Badge variant={getStatusVariant(order.status)}>
          {getStatusText(order.status)}
        </Badge>
        <h1 className="text-lg font-semibold mt-1">{order.taskTitle}</h1>
      </div>
      
      <div className="p-4 space-y-3">
        {/* 任务信息 - 可点击Card */}
        <Card 
          className="p-4 cursor-pointer active:scale-95 transition-transform"
          onClick={() => navigate(`/tasks/${order.taskId}`)}
        >
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <FileText className="w-5 h-5 text-gray-400" />
              <div>
                <p className="font-medium">任务信息</p>
                <p className="text-sm text-gray-500">预算 ¥{order.amount}</p>
              </div>
            </div>
            <ChevronRight className="w-4 h-4 text-gray-400" />
          </div>
        </Card>
        
        {/* 对方信息 - 可点击Card */}
        <Card 
          className="p-4 cursor-pointer active:scale-95 transition-transform"
          onClick={() => navigate(`/profile/${order.partnerId}`)}
        >
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Avatar src={order.partnerAvatar} size="md" />
              <div>
                <p className="font-medium">{order.partnerName}</p>
                <p className="text-sm text-gray-500">⭐ {order.partnerRating.toFixed(1)}</p>
              </div>
            </div>
            <Button variant="ghost" size="sm" onClick={(e) => {
              e.stopPropagation()
              navigate(`/messages/${order.conversationId}`)
            }}>
              发送消息
            </Button>
          </div>
        </Card>
        
        {/* 交付物 - 简化显示 */}
        {order.deliverables?.length > 0 && (
          <Card className="p-4">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <Upload className="w-5 h-5 text-gray-400" />
                <p className="font-medium">交付物</p>
              </div>
              <Badge>{order.deliverables.length}个文件</Badge>
            </div>
            
            <div className="space-y-2">
              {order.deliverables.map(file => (
                <div key={file.id} className="flex items-center justify-between p-2 bg-gray-50 rounded">
                  <span className="text-sm truncate">{file.fileName}</span>
                  <Button variant="ghost" size="sm">查看</Button>
                </div>
              ))}
            </div>
          </Card>
        )}
      </div>
    </div>
  )
}
```

---

## 📊 最终精简后的工作量

| Phase | 原估计 | 极简后 | 减少 |
|-------|--------|--------|------|
| Phase 1: 核心组件调整 | 3-4天 | 2-3天 | -25% |
| Phase 2: AI任务生成 | 2天 | 2天 | 0% |
| Phase 3: ProfileView调整 | 0.5天 | 0.5天 | 0% |
| Phase 4: 设置页调整 | 0.5天 | 0.5天 | 0% |
| Phase 5: API集成 | 2-3天 | 1-2天 | -33% |
| Phase 6: TypeScript | 1天 | 0.5天 | -50% |
| **新增组件开发** | 5天 | **2天** | **-60%** |
| **总计** | **14-17天** | **9-11天** | **-40%** |

**极简设计的优势**：
- ✅ 组件数量从15个减少到10个
- ✅ 删除了复杂的状态流转逻辑
- ✅ 删除了表单填写步骤
- ✅ 大幅减少UI层代码量

---

**更新说明**：根据用户确认的极简设计原则，简化了任务申请、订单验收、评价等流程，并新增了钱包Minimalist设计和订单详情Card设计的实施指南。
