# Ques Pivot 后端实施清单 ✅

## 从"AI人才匹配平台" → "校园任务平台（高校线下场景）" - 后端逐步实施指南

**🎓 产品定位**：专注于大学校园内的线下单次任务，包括课程辅导、代签到、数据标注、活动帮手、技能外包等场景。

**核心特点**：
- 校内认证（university字段验证）
- 线下为主（location地理匹配）
- 小额高频（¥30-300，微信支付分账）
- 技术含量适中（skills标签匹配）
- 时间灵活（deadline和提醒系统）

---

## 📋 Phase 1: 数据库结构调整（预计3-4天）

### 1.1 备份现有数据库

```bash
[ ] 创建完整数据库备份
pg_dump ques_db > backup_$(date +%Y%m%d).sql

[ ] 导出现有用户数据（用于迁移测试）
SELECT * FROM users INTO OUTFILE '/backup/users.csv';
```

---

### 1.2 修改 `user_profiles` 表

```sql
[ ] 删除废弃字段
ALTER TABLE user_profiles DROP COLUMN IF EXISTS goals;
ALTER TABLE user_profiles DROP COLUMN IF EXISTS demands;
ALTER TABLE user_profiles DROP COLUMN IF EXISTS resources;

[ ] 新增接单者stat字段
ALTER TABLE user_profiles 
ADD COLUMN completion_rate DECIMAL(5,2) DEFAULT 100.00 COMMENT '完成率',
ADD COLUMN average_rating DECIMAL(3,2) DEFAULT 5.00 COMMENT '平均评分',
ADD COLUMN completed_tasks_count INT DEFAULT 0 COMMENT '完成任务数',
ADD COLUMN response_time_minutes INT DEFAULT 60 COMMENT '平均响应时间(分钟)';

[ ] 新增发单者stat字段
ALTER TABLE user_profiles
ADD COLUMN posted_tasks_count INT DEFAULT 0 COMMENT '发布任务数',
ADD COLUMN on_time_payment_rate DECIMAL(5,2) DEFAULT 100.00 COMMENT '按时付款率',
ADD COLUMN poster_rating DECIMAL(3,2) DEFAULT 5.00 COMMENT '发单者评分';

[ ] 创建索引
CREATE INDEX idx_completion_rate ON user_profiles(completion_rate);
CREATE INDEX idx_average_rating ON user_profiles(average_rating);
```

**影响API**：
- `GET /api/users/:id/profile` - 响应中添加新stat字段
- `GET /api/users/:id/freelancer-stats` - 新增接口
- `GET /api/users/:id/poster-stats` - 新增接口

---

### 1.3 重命名 `user_projects` 为 `portfolios`

```sql
[ ] 重命名表
ALTER TABLE user_projects RENAME TO portfolios;

[ ] 添加新字段（用于区分作品集和任务附件）
ALTER TABLE portfolios
ADD COLUMN item_type VARCHAR(20) DEFAULT 'portfolio' COMMENT 'portfolio或task_attachment',
ADD COLUMN task_id BIGINT NULL COMMENT '关联的任务ID（如果是任务附件）';

[ ] 创建索引
CREATE INDEX idx_task_id ON portfolios(task_id);
CREATE INDEX idx_item_type ON portfolios(item_type);
```

**影响API**：
- `GET /api/users/:id/portfolios` - 仅返回item_type='portfolio'的记录
- `GET /api/tasks/:id/attachments` - 返回item_type='task_attachment'的记录

---

### 1.4 删除废弃表

```sql
[ ] 备份数据（以防需要恢复）
CREATE TABLE user_quotas_backup AS SELECT * FROM user_quotas;
CREATE TABLE memberships_backup AS SELECT * FROM memberships;
CREATE TABLE whispers_backup AS SELECT * FROM whispers;

[ ] 删除表
DROP TABLE IF EXISTS user_quotas CASCADE;
DROP TABLE IF EXISTS membership_transactions CASCADE;
DROP TABLE IF EXISTS memberships CASCADE;
DROP TABLE IF EXISTS whispers CASCADE;
DROP TABLE IF EXISTS payment_sessions CASCADE;  -- 如果有的话

[ ] 删除相关外键约束（如果存在）
-- 根据实际情况调整
```

**影响API（需删除）**：
- ❌ `GET /api/settings/receives` - 删除
- ❌ `POST /api/payments/topup-receives` - 删除
- ❌ `POST /api/payments/upgrade-pro` - 删除
- ❌ `GET /api/whispers` - 删除

---

### 1.5 创建新表：`tasks`

```sql
[ ] 创建tasks表
CREATE TABLE tasks (
    id BIGSERIAL PRIMARY KEY,
    poster_id BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    title VARCHAR(200) NOT NULL,
    description TEXT NOT NULL,
    budget_min DECIMAL(10,2),
    budget_max DECIMAL(10,2),
    final_amount DECIMAL(10,2),
    deadline TIMESTAMP,
    location VARCHAR(200),
    status VARCHAR(50) NOT NULL DEFAULT 'draft',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    published_at TIMESTAMP,
    completed_at TIMESTAMP,
    
    -- AI向量（复用现有向量表结构）
    embedding_vector vector(1024),
    sparse_vector jsonb,
    
    -- 统计
    view_count INT DEFAULT 0,
    application_count INT DEFAULT 0,
    
    CHECK (budget_min <= budget_max),
    CHECK (status IN ('draft', 'published', 'in_progress', 'reviewing', 'completed', 'cancelled', 'disputed'))
);

[ ] 创建索引
CREATE INDEX idx_tasks_poster_id ON tasks(poster_id);
CREATE INDEX idx_tasks_status ON tasks(status);
CREATE INDEX idx_tasks_published_at ON tasks(published_at);
CREATE INDEX idx_tasks_location ON tasks(location);

[ ] 创建向量搜索索引（如果使用pgvector）
CREATE INDEX idx_tasks_embedding ON tasks USING ivfflat (embedding_vector vector_cosine_ops);
```

---

### 1.6 创建新表：`task_skills`

```sql
[ ] 创建task_skills表
CREATE TABLE task_skills (
    task_id BIGINT NOT NULL REFERENCES tasks(id) ON DELETE CASCADE,
    skill_name VARCHAR(100) NOT NULL,
    PRIMARY KEY (task_id, skill_name)
);

[ ] 创建索引
CREATE INDEX idx_task_skills_skill_name ON task_skills(skill_name);
```

---

### 1.7 创建新表：`task_applications`

```sql
[ ] 创建task_applications表
CREATE TABLE task_applications (
    id BIGSERIAL PRIMARY KEY,
    task_id BIGINT NOT NULL REFERENCES tasks(id) ON DELETE CASCADE,
    freelancer_id BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    message TEXT,
    quoted_price DECIMAL(10,2),
    estimated_days INT,
    status VARCHAR(50) DEFAULT 'pending',
    applied_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    responded_at TIMESTAMP,
    
    UNIQUE KEY unique_application (task_id, freelancer_id),
    CHECK (status IN ('pending', 'accepted', 'rejected', 'withdrawn'))
);

[ ] 创建索引
CREATE INDEX idx_applications_task_id ON task_applications(task_id);
CREATE INDEX idx_applications_freelancer_id ON task_applications(freelancer_id);
CREATE INDEX idx_applications_status ON task_applications(status);
```

---

### 1.8 创建新表：`orders`

```sql
[ ] 创建orders表
CREATE TABLE orders (
    id BIGSERIAL PRIMARY KEY,
    task_id BIGINT NOT NULL REFERENCES tasks(id),
    poster_id BIGINT NOT NULL REFERENCES users(id),
    freelancer_id BIGINT NOT NULL REFERENCES users(id),
    amount DECIMAL(10,2) NOT NULL,
    platform_fee DECIMAL(10,2) NOT NULL,
    freelancer_income DECIMAL(10,2) NOT NULL,
    status VARCHAR(50) NOT NULL DEFAULT 'pending_payment',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    paid_at TIMESTAMP,
    submitted_at TIMESTAMP,
    completed_at TIMESTAMP,
    cancelled_at TIMESTAMP,
    
    -- 支付信息
    payment_method VARCHAR(50),
    transaction_id VARCHAR(200),
    
    CHECK (amount > 0),
    CHECK (platform_fee >= 0),
    CHECK (freelancer_income >= 0),
    CHECK (status IN (
        'pending_payment', 'paid', 'in_progress', 'submitted', 
        'reviewing', 'completed', 'refund_requested', 'refunded', 
        'disputed', 'cancelled'
    ))
);

[ ] 创建索引
CREATE INDEX idx_orders_task_id ON orders(task_id);
CREATE INDEX idx_orders_poster_id ON orders(poster_id);
CREATE INDEX idx_orders_freelancer_id ON orders(freelancer_id);
CREATE INDEX idx_orders_status ON orders(status);
CREATE INDEX idx_orders_created_at ON orders(created_at);
```

---

### 1.9 创建新表：`order_deliverables`

```sql
[ ] 创建order_deliverables表
CREATE TABLE order_deliverables (
    id BIGSERIAL PRIMARY KEY,
    order_id BIGINT NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
    file_url TEXT NOT NULL,
    file_type VARCHAR(50),
    description TEXT,
    uploaded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

[ ] 创建索引
CREATE INDEX idx_deliverables_order_id ON order_deliverables(order_id);
```

---

### 1.10 创建新表：`reviews`

```sql
[ ] 创建reviews表
CREATE TABLE reviews (
    id BIGSERIAL PRIMARY KEY,
    order_id BIGINT NOT NULL REFERENCES orders(id),
    reviewer_id BIGINT NOT NULL REFERENCES users(id),
    reviewee_id BIGINT NOT NULL REFERENCES users(id),
    role VARCHAR(20) NOT NULL CHECK (role IN ('freelancer', 'poster')),
    
    -- 评分
    quality_rating INT CHECK (quality_rating BETWEEN 1 AND 5),
    speed_rating INT CHECK (speed_rating BETWEEN 1 AND 5),
    communication_rating INT CHECK (communication_rating BETWEEN 1 AND 5),
    overall_rating DECIMAL(3,2),
    
    comment TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    UNIQUE KEY unique_review (order_id, reviewer_id)
);

[ ] 创建索引
CREATE INDEX idx_reviews_order_id ON reviews(order_id);
CREATE INDEX idx_reviews_reviewee_id ON reviews(reviewee_id);
CREATE INDEX idx_reviews_created_at ON reviews(created_at);
```

---

### 1.11 创建新表：`user_wallets`

```sql
[ ] 创建user_wallets表
CREATE TABLE user_wallets (
    user_id BIGINT PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
    balance DECIMAL(10,2) DEFAULT 0.00 CHECK (balance >= 0),
    frozen_amount DECIMAL(10,2) DEFAULT 0.00 CHECK (frozen_amount >= 0),
    total_income DECIMAL(10,2) DEFAULT 0.00,
    total_expense DECIMAL(10,2) DEFAULT 0.00,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

[ ] 为所有现有用户初始化钱包
INSERT INTO user_wallets (user_id, balance)
SELECT id, 0.00 FROM users
ON CONFLICT (user_id) DO NOTHING;
```

---

### 1.12 创建新表：`transactions`

```sql
[ ] 创建transactions表
CREATE TABLE transactions (
    id BIGSERIAL PRIMARY KEY,
    order_id BIGINT REFERENCES orders(id),
    user_id BIGINT NOT NULL REFERENCES users(id),
    type VARCHAR(50) NOT NULL,
    amount DECIMAL(10,2) NOT NULL,
    balance_after DECIMAL(10,2),
    description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    CHECK (type IN ('payment', 'income', 'fee', 'refund', 'withdrawal'))
);

[ ] 创建索引
CREATE INDEX idx_transactions_user_id ON transactions(user_id);
CREATE INDEX idx_transactions_order_id ON transactions(order_id);
CREATE INDEX idx_transactions_created_at ON transactions(created_at);
CREATE INDEX idx_transactions_type ON transactions(type);
```

---

### 1.13 创建数据库触发器

```sql
[ ] 创建触发器：自动计算订单抽成
CREATE OR REPLACE FUNCTION calculate_platform_fee()
RETURNS TRIGGER AS $$
BEGIN
    NEW.platform_fee := ROUND(NEW.amount * 0.10, 2);
    NEW.freelancer_income := NEW.amount - NEW.platform_fee;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trigger_calculate_fee
BEFORE INSERT OR UPDATE OF amount ON orders
FOR EACH ROW
EXECUTE FUNCTION calculate_platform_fee();

[ ] 测试触发器
INSERT INTO orders (task_id, poster_id, freelancer_id, amount, status)
VALUES (1, 1, 2, 120.00, 'pending_payment');
-- 验证：platform_fee应该是12.00，freelancer_income应该是108.00

[ ] 创建触发器：更新完成率
CREATE OR REPLACE FUNCTION update_freelancer_stats()
RETURNS TRIGGER AS $$
BEGIN
    IF NEW.status = 'completed' AND OLD.status != 'completed' THEN
        UPDATE user_profiles
        SET 
            completed_tasks_count = completed_tasks_count + 1,
            completion_rate = (
                SELECT ROUND(
                    (COUNT(*) FILTER (WHERE status = 'completed') * 100.0 / 
                     NULLIF(COUNT(*), 0)), 
                    2
                )
                FROM orders
                WHERE freelancer_id = NEW.freelancer_id
            )
        WHERE user_id = NEW.freelancer_id;
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trigger_update_freelancer_stats
AFTER UPDATE OF status ON orders
FOR EACH ROW
EXECUTE FUNCTION update_freelancer_stats();

[ ] 创建触发器：更新平均评分
CREATE OR REPLACE FUNCTION update_average_rating()
RETURNS TRIGGER AS $$
BEGIN
    -- 计算overall_rating
    NEW.overall_rating := ROUND(
        (NEW.quality_rating + NEW.speed_rating + NEW.communication_rating) / 3.0, 
        2
    );
    
    -- 更新被评价者的平均评分
    UPDATE user_profiles
    SET average_rating = (
        SELECT ROUND(AVG(overall_rating), 2)
        FROM reviews
        WHERE reviewee_id = NEW.reviewee_id
    )
    WHERE user_id = NEW.reviewee_id;
    
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trigger_update_rating
BEFORE INSERT ON reviews
FOR EACH ROW
EXECUTE FUNCTION update_average_rating();

[ ] 创建触发器：更新任务申请数
CREATE OR REPLACE FUNCTION update_application_count()
RETURNS TRIGGER AS $$
BEGIN
    UPDATE tasks
    SET application_count = (
        SELECT COUNT(*) FROM task_applications WHERE task_id = NEW.task_id
    )
    WHERE id = NEW.task_id;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trigger_update_app_count
AFTER INSERT ON task_applications
FOR EACH ROW
EXECUTE FUNCTION update_application_count();
```

---

## 📋 Phase 2: 后端模型定义（预计1天）

### 2.1 创建 `models/tasks.py`

```python
[ ] 定义Task模型
from sqlalchemy import Column, BigInteger, String, Text, DECIMAL, TIMESTAMP, Integer, CheckConstraint
from sqlalchemy.orm import relationship
from models.base import Base

class Task(Base):
    __tablename__ = 'tasks'
    
    id = Column(BigInteger, primary_key=True)
    poster_id = Column(BigInteger, ForeignKey('users.id'), nullable=False)
    title = Column(String(200), nullable=False)
    description = Column(Text, nullable=False)
    budget_min = Column(DECIMAL(10, 2))
    budget_max = Column(DECIMAL(10, 2))
    final_amount = Column(DECIMAL(10, 2))
    deadline = Column(TIMESTAMP)
    location = Column(String(200))
    status = Column(String(50), nullable=False, default='draft')
    created_at = Column(TIMESTAMP, default=datetime.utcnow)
    updated_at = Column(TIMESTAMP, default=datetime.utcnow, onupdate=datetime.utcnow)
    published_at = Column(TIMESTAMP)
    completed_at = Column(TIMESTAMP)
    view_count = Column(Integer, default=0)
    application_count = Column(Integer, default=0)
    
    # 关系
    poster = relationship('User', foreign_keys=[poster_id])
    skills = relationship('TaskSkill', back_populates='task', cascade='all, delete-orphan')
    applications = relationship('TaskApplication', back_populates='task')
    
    __table_args__ = (
        CheckConstraint('budget_min <= budget_max'),
    )

[ ] 定义TaskSkill模型
class TaskSkill(Base):
    __tablename__ = 'task_skills'
    
    task_id = Column(BigInteger, ForeignKey('tasks.id', ondelete='CASCADE'), primary_key=True)
    skill_name = Column(String(100), primary_key=True)
    
    task = relationship('Task', back_populates='skills')

[ ] 定义TaskApplication模型
class TaskApplication(Base):
    __tablename__ = 'task_applications'
    
    id = Column(BigInteger, primary_key=True)
    task_id = Column(BigInteger, ForeignKey('tasks.id', ondelete='CASCADE'), nullable=False)
    freelancer_id = Column(BigInteger, ForeignKey('users.id', ondelete='CASCADE'), nullable=False)
    message = Column(Text)
    quoted_price = Column(DECIMAL(10, 2))
    estimated_days = Column(Integer)
    status = Column(String(50), default='pending')
    applied_at = Column(TIMESTAMP, default=datetime.utcnow)
    responded_at = Column(TIMESTAMP)
    
    task = relationship('Task', back_populates='applications')
    freelancer = relationship('User', foreign_keys=[freelancer_id])
```

---

### 2.2 创建 `models/orders.py`

```python
[ ] 定义Order模型
class Order(Base):
    __tablename__ = 'orders'
    
    id = Column(BigInteger, primary_key=True)
    task_id = Column(BigInteger, ForeignKey('tasks.id'), nullable=False)
    poster_id = Column(BigInteger, ForeignKey('users.id'), nullable=False)
    freelancer_id = Column(BigInteger, ForeignKey('users.id'), nullable=False)
    amount = Column(DECIMAL(10, 2), nullable=False)
    platform_fee = Column(DECIMAL(10, 2), nullable=False)
    freelancer_income = Column(DECIMAL(10, 2), nullable=False)
    status = Column(String(50), nullable=False, default='pending_payment')
    created_at = Column(TIMESTAMP, default=datetime.utcnow)
    paid_at = Column(TIMESTAMP)
    submitted_at = Column(TIMESTAMP)
    completed_at = Column(TIMESTAMP)
    cancelled_at = Column(TIMESTAMP)
    payment_method = Column(String(50))
    transaction_id = Column(String(200))
    
    task = relationship('Task')
    poster = relationship('User', foreign_keys=[poster_id])
    freelancer = relationship('User', foreign_keys=[freelancer_id])
    deliverables = relationship('OrderDeliverable', back_populates='order')
    reviews = relationship('Review', back_populates='order')

[ ] 定义OrderDeliverable模型
class OrderDeliverable(Base):
    __tablename__ = 'order_deliverables'
    
    id = Column(BigInteger, primary_key=True)
    order_id = Column(BigInteger, ForeignKey('orders.id', ondelete='CASCADE'), nullable=False)
    file_url = Column(Text, nullable=False)
    file_type = Column(String(50))
    description = Column(Text)
    uploaded_at = Column(TIMESTAMP, default=datetime.utcnow)
    
    order = relationship('Order', back_populates='deliverables')
```

---

### 2.3 创建 `models/reviews.py`

```python
[ ] 定义Review模型
class Review(Base):
    __tablename__ = 'reviews'
    
    id = Column(BigInteger, primary_key=True)
    order_id = Column(BigInteger, ForeignKey('orders.id'), nullable=False)
    reviewer_id = Column(BigInteger, ForeignKey('users.id'), nullable=False)
    reviewee_id = Column(BigInteger, ForeignKey('users.id'), nullable=False)
    role = Column(String(20), nullable=False)  # 'freelancer' or 'poster'
    quality_rating = Column(Integer, CheckConstraint('quality_rating BETWEEN 1 AND 5'))
    speed_rating = Column(Integer, CheckConstraint('speed_rating BETWEEN 1 AND 5'))
    communication_rating = Column(Integer, CheckConstraint('communication_rating BETWEEN 1 AND 5'))
    overall_rating = Column(DECIMAL(3, 2))
    comment = Column(Text)
    created_at = Column(TIMESTAMP, default=datetime.utcnow)
    
    order = relationship('Order', back_populates='reviews')
    reviewer = relationship('User', foreign_keys=[reviewer_id])
    reviewee = relationship('User', foreign_keys=[reviewee_id])
```

---

### 2.4 更新 `models/user_profiles.py`

```python
[ ] 添加新字段到UserProfile模型
class UserProfile(Base):
    # ... 原有字段
    
    # 🔴 新增：接单者stat
    completion_rate = Column(DECIMAL(5, 2), default=100.00)
    average_rating = Column(DECIMAL(3, 2), default=5.00)
    completed_tasks_count = Column(Integer, default=0)
    response_time_minutes = Column(Integer, default=60)
    
    # 🔴 新增：发单者stat
    posted_tasks_count = Column(Integer, default=0)
    on_time_payment_rate = Column(DECIMAL(5, 2), default=100.00)
    poster_rating = Column(DECIMAL(3, 2), default=5.00)
```

---

## 📋 Phase 3: API路由实现（预计5-7天）

### 3.1 创建 `routers/tasks.py`

```python
[ ] POST /api/tasks/create-from-conversation
    # AI生成任务草稿
    async def create_task_from_conversation(
        conversation_data: ConversationTaskCreate,
        current_user: User = Depends(get_current_user)
    ):
        # 1. 调用GLM-4生成任务卡片
        # 2. 生成embedding向量
        # 3. 保存为draft状态
        pass

[ ] POST /api/tasks/{task_id}/publish
    # 发布任务
    async def publish_task(task_id: int, current_user: User):
        # 验证权限
        # 状态: draft -> published
        pass

[ ] POST /api/tasks/search
    # 搜索任务（接单者视角）
    async def search_tasks(
        search_params: TaskSearchParams,
        current_user: User
    ):
        # 1. 生成查询向量
        # 2. 向量数据库搜索
        # 3. 二次排序
        # 4. 生成AI匹配理由
        pass

[ ] GET /api/tasks/{task_id}
    # 获取任务详情
    async def get_task_detail(task_id: int):
        # 返回完整任务信息 + 发单者信息
        pass

[ ] PUT /api/tasks/{task_id}
    # 修改任务（仅draft状态可修改）
    async def update_task(task_id: int, update_data: TaskUpdate):
        pass

[ ] DELETE /api/tasks/{task_id}
    # 删除任务（仅draft或无申请的published可删除）
    async def delete_task(task_id: int):
        pass

[ ] GET /api/tasks/{task_id}/applications
    # 获取任务的所有申请
    async def get_task_applications(task_id: int):
        # 仅发单者可访问
        pass
```

---

### 3.2 创建 `routers/freelancers.py`

```python
[ ] POST /api/freelancers/search
    # 搜索接单者（发单者视角）
    async def search_freelancers(
        search_params: FreelancerSearchParams,
        current_user: User
    ):
        # 1. 生成查询向量
        # 2. 搜索用户档案
        # 3. 过滤条件（技能、评分、完成率）
        # 4. 生成AI匹配理由
        pass

[ ] GET /api/freelancers/{user_id}/profile
    # 获取接单者完整档案
    async def get_freelancer_profile(user_id: int):
        # 返回：技能、作品集、stat、评价
        pass

[ ] GET /api/freelancers/{user_id}/stats
    # 获取接单者统计数据
    async def get_freelancer_stats(user_id: int):
        return {
            'completion_rate': ...,
            'average_rating': ...,
            'completed_tasks_count': ...,
            'response_time': ...,
        }
```

---

### 3.3 创建 `routers/applications.py`

```python
[ ] POST /api/tasks/{task_id}/apply
    # 申请任务
    async def apply_for_task(
        task_id: int,
        application_data: ApplicationCreate,
        current_user: User
    ):
        # 1. 检查是否已申请
        # 2. AI生成申请消息（如果未提供）
        # 3. 创建申请记录
        # 4. 通知发单者
        pass

[ ] GET /api/applications/my-applications
    # 我的申请列表（接单者视角）
    async def get_my_applications(current_user: User):
        pass

[ ] PUT /api/applications/{application_id}/withdraw
    # 撤回申请
    async def withdraw_application(application_id: int):
        pass

[ ] POST /api/applications/{application_id}/accept
    # 接受申请（发单者）
    async def accept_application(application_id: int):
        # 1. 验证权限
        # 2. 状态: pending -> accepted
        # 3. 创建订单
        # 4. 拒绝其他申请
        # 5. 任务状态: published -> in_progress
        pass

[ ] POST /api/applications/{application_id}/reject
    # 拒绝申请
    async def reject_application(application_id: int):
        pass
```

---

### 3.4 创建 `routers/orders.py`

```python
[ ] POST /api/orders/create
    # 创建订单（接受申请后自动调用）
    async def create_order(order_data: OrderCreate):
        # 1. 创建订单记录
        # 2. 自动计算抽成（触发器）
        # 3. 状态: pending_payment
        pass

[ ] POST /api/orders/{order_id}/pay
    # 支付订单
    async def pay_order(
        order_id: int,
        payment_data: PaymentData,
        current_user: User
    ):
        # 1. 验证权限（仅发单者）
        # 2. 调用支付SDK（微信/支付宝）
        # 3. 状态: pending_payment -> paid
        # 4. 记录交易流水
        # 5. 通知接单者
        pass

[ ] GET /api/orders/my-orders
    # 我的订单列表
    async def get_my_orders(
        role: str = Query('all'),  # 'freelancer', 'poster', 'all'
        status: str = Query(None),
        current_user: User
    ):
        pass

[ ] GET /api/orders/{order_id}
    # 订单详情
    async def get_order_detail(order_id: int):
        pass

[ ] POST /api/orders/{order_id}/submit
    # 提交交付物
    async def submit_deliverables(
        order_id: int,
        files: List[UploadFile],
        message: str,
        current_user: User
    ):
        # 1. 验证权限（仅接单者）
        # 2. 上传文件到COS
        # 3. 保存deliverables记录
        # 4. 状态: in_progress -> submitted
        # 5. 通知发单者
        pass

[ ] POST /api/orders/{order_id}/approve
    # 验收通过
    async def approve_order(order_id: int, current_user: User):
        # 1. 验证权限（仅发单者）
        # 2. 状态: submitted -> completed
        # 3. 结算款项（调用财务模块）
        # 4. 更新stat（触发器）
        # 5. 通知双方评价
        pass

[ ] POST /api/orders/{order_id}/request-revision
    # 申请修改
    async def request_revision(
        order_id: int,
        revision_data: RevisionRequest,
        current_user: User
    ):
        # 状态: submitted -> in_progress（回退）
        pass

[ ] POST /api/orders/{order_id}/cancel
    # 取消订单
    async def cancel_order(order_id: int, reason: str):
        # 根据不同状态执行不同退款逻辑
        pass
```

---

### 3.5 创建 `routers/reviews.py`

```python
[ ] POST /api/reviews/create
    # 提交评价
    async def create_review(
        review_data: ReviewCreate,
        current_user: User
    ):
        # 1. 验证订单已完成
        # 2. 验证未重复评价
        # 3. 创建评价记录
        # 4. 计算overall_rating（触发器）
        # 5. 更新被评价者average_rating（触发器）
        pass

[ ] GET /api/reviews/my-reviews
    # 我收到的评价
    async def get_my_reviews(current_user: User):
        pass

[ ] GET /api/users/{user_id}/reviews
    # 某用户的评价列表
    async def get_user_reviews(user_id: int):
        pass
```

---

### 3.6 更新 `routers/users.py`

```python
[ ] 修改 GET /api/users/{user_id}/profile
    # 添加新stat字段到响应
    return {
        # ... 原有字段
        'completion_rate': profile.completion_rate,
        'average_rating': profile.average_rating,
        'completed_tasks_count': profile.completed_tasks_count,
        'response_time_minutes': profile.response_time_minutes,
        'posted_tasks_count': profile.posted_tasks_count,
        'on_time_payment_rate': profile.on_time_payment_rate,
        'poster_rating': profile.poster_rating,
    }

[ ] 新增 GET /api/users/{user_id}/freelancer-stats
    # 接单者统计数据（包含收益）
    
[ ] 新增 GET /api/users/{user_id}/poster-stats
    # 发单者统计数据（包含支出）
```

---

### 3.7 删除废弃路由

```python
[ ] 删除 routers/whispers.py
[ ] 删除 routers/payments.py 中的：
    - POST /api/payments/topup-receives
    - POST /api/payments/upgrade-pro
    - GET /api/payments/membership-info
```

---

## 📋 Phase 4: 支付集成（预计3-4天）

### 4.1 选择支付SDK

```python
[ ] 确认支付方式（需提供商户号）
    - [ ] 微信支付（推荐）
    - [ ] 支付宝
    - [ ] 第三方聚合（Ping++/BeeCloud）

[ ] 安装SDK
pip install wechatpay-python  # 如果用微信支付
```

---

### 4.2 实现支付服务 `services/payment_service.py`

```python
[ ] 创建支付会话
async def create_payment_session(order_id: int, amount: Decimal):
    # 调用微信支付API生成二维码
    # 返回payment_url和transaction_id
    pass

[ ] 支付回调处理
async def handle_payment_callback(transaction_id: str):
    # 1. 验证签名
    # 2. 更新订单状态
    # 3. 记录交易流水
    pass

[ ] 退款处理
async def process_refund(order_id: int):
    # 调用支付SDK退款接口
    pass
```

---

### 4.3 实现财务模块 `services/finance_service.py`

```python
[ ] 结算接单者收入
async def settle_freelancer_income(order_id: int):
    order = db.query(Order).filter(Order.id == order_id).first()
    
    # 1. 更新钱包余额
    wallet = db.query(UserWallet).filter(UserWallet.user_id == order.freelancer_id).first()
    wallet.balance += order.freelancer_income
    wallet.total_income += order.freelancer_income
    
    # 2. 记录流水
    transaction = Transaction(
        order_id=order_id,
        user_id=order.freelancer_id,
        type='income',
        amount=order.freelancer_income,
        balance_after=wallet.balance,
        description=f'任务 #{order.task_id} 收入'
    )
    db.add(transaction)
    
    # 3. 记录平台抽成流水
    platform_transaction = Transaction(
        order_id=order_id,
        user_id=0,  # 平台账户
        type='fee',
        amount=order.platform_fee,
        description=f'任务 #{order.task_id} 平台抽成'
    )
    db.add(platform_transaction)
    
    db.commit()

[ ] 冻结/解冻资金
async def freeze_amount(user_id: int, amount: Decimal):
    # 进行中订单冻结资金
    pass

[ ] 提现处理（Phase 2实现）
async def process_withdrawal(user_id: int, amount: Decimal, method: str):
    pass
```

---

## 📋 Phase 5: 通知系统更新（预计1天）

### 5.1 更新通知模板

```python
[ ] 修改 services/notification_service.py

notification_templates = {
    # 🔴 新增：任务相关通知
    'task_application': '{name} 申请了你的任务"{task_title}"',
    'application_accepted': '你的申请被接受！任务"{task_title}"',
    'payment_received': '你已收到 ¥{amount} 任务款项',
    'task_submitted': '接单者已提交任务"{task_title}"，请验收',
    'task_approved': '发单者已验收通过任务"{task_title}"',
    'revision_requested': '发单者申请修改任务"{task_title}"',
    'task_deadline_reminder': '任务"{task_title}"即将截止（还剩24小时）',
    
    # ❌ 删除：Whisper相关通知
    # 'whisper_received': ...
    # 'identity_revealed': ...
}
```

---

## 📋 Phase 6: AI服务调整（预计2天）

### 6.1 任务生成服务 `services/task_generation_service.py`

```python
[ ] 创建AI任务生成函数
async def generate_task_from_conversation(
    conversation_history: List[dict],
    user_profile: UserProfile
) -> dict:
    """
    根据对话历史生成任务卡片
    """
    prompt = f"""
    根据以下对话，生成一个任务发布卡片的JSON：
    
    对话历史：
    {format_conversation(conversation_history)}
    
    用户信息：
    - 姓名：{user_profile.name}
    - 学校：{user_profile.university}
    - 位置：{user_profile.location}
    
    请生成JSON格式，包含以下字段：
    {{
        "title": "任务标题（10字以内）",
        "description": "详细描述（100-500字）",
        "budget_min": 预算下限（数字）,
        "budget_max": 预算上限（数字）,
        "deadline": "截止时间（YYYY-MM-DD格式）",
        "skills_required": ["技能1", "技能2"],
        "deliverables": ["交付物1", "交付物2"]
    }}
    """
    
    response = await glm4_client.generate(prompt)
    task_data = json.loads(response)
    
    # 生成嵌入向量
    embedding = await generate_embedding(task_data['description'])
    sparse_keywords = await extract_keywords(task_data['description'])
    
    task_data['embedding_vector'] = embedding
    task_data['sparse_vector'] = sparse_keywords
    
    return task_data
```

---

### 6.2 更新匹配服务 `services/intelligent_search/`

```python
[ ] 修改 search_service.py 支持双向搜索
async def search(
    query: str,
    user_role: str,  # 'freelancer' or 'poster'
    user_profile: UserProfile,
    filters: dict
):
    if user_role == 'freelancer':
        # 搜索任务
        return await search_tasks(query, user_profile, filters)
    else:
        # 搜索接单者
        return await search_freelancers(query, user_profile, filters)

[ ] 实现 search_tasks()
    # 向量搜索tasks表
    
[ ] 实现 search_freelancers()
    # 向量搜索user_profiles表
```

---

## 📋 Phase 7: 测试与部署（预计2-3天）

### 7.1 单元测试

```python
[ ] 测试tasks CRUD
pytest tests/test_tasks.py

[ ] 测试applications流程
pytest tests/test_applications.py

[ ] 测试orders状态流转
pytest tests/test_orders.py

[ ] 测试支付回调
pytest tests/test_payments.py

[ ] 测试stat自动计算
pytest tests/test_stats.py

[ ] 测试抽成计算
pytest tests/test_finance.py
```

---

### 7.2 集成测试

```bash
[ ] 端到端测试：完整任务流程
    1. 发单者创建任务
    2. 接单者申请
    3. 发单者接受申请并支付
    4. 接单者提交作品
    5. 发单者验收通过
    6. 双方评价
    7. 验证stat更新

[ ] 测试并发场景
    - 多人同时申请同一任务
    - 支付回调并发
```

---

### 7.3 数据迁移

```sql
[ ] 迁移现有用户数据
    - user_profiles新字段默认值验证
    - user_projects -> portfolios迁移
    - 删除废弃表的外键清理

[ ] 验证数据完整性
    - 外键约束检查
    - 触发器测试
```

---

### 7.4 部署

```bash
[ ] 更新requirements.txt
pip freeze > requirements.txt

[ ] 运行数据库迁移
alembic upgrade head

[ ] 重启服务
docker-compose down
docker-compose up -d --build

[ ] 验证健康检查
curl http://localhost:8000/health
```

---

## ⚠️ 后端不确定点清单（需确认）

### 支付相关
```
[ ] 微信支付商户号是否已申请？
[ ] 是否需要真实资金流转还是沙箱测试？
[ ] 平台托管账户的开户行和账号？
```

### 业务逻辑
```
[ ] 争议订单如何处理？需要客服系统吗？
[ ] 提现功能的具体规格（手续费、到账时间）？
[ ] 抽成比例是否会调整（阶梯抽成、活动免抽成）？
[ ] 任务是否可以修改？修改后如何处理已有申请？
```

### 技术选型
```
[ ] 向量数据库：继续用腾讯云VectorDB还是切换到Qdrant？
[ ] 文件存储：本地存储还是腾讯云COS？
[ ] 消息队列：是否需要引入（处理支付回调、异步通知）？
```

---

## 📊 工时统计

| Phase | 预计时间 | 实际时间 | 完成度 |
|-------|---------|---------|--------|
| Phase 1: 数据库调整 | 3-4天 | ___ | ☐ |
| Phase 2: 模型定义 | 1天 | ___ | ☐ |
| Phase 3: API实现 | 5-7天 | ___ | ☐ |
| Phase 4: 支付集成 | 3-4天 | ___ | ☐ |
| Phase 5: 通知更新 | 1天 | ___ | ☐ |
| Phase 6: AI调整 | 2天 | ___ | ☐ |
| Phase 7: 测试部署 | 2-3天 | ___ | ☐ |
| **总计** | **17-24天** | **___** | **☐** |

---

**文档版本**：v1.0  
**最后更新**：2025-10-22  
**状态**：待确认⚠️标记的问题
