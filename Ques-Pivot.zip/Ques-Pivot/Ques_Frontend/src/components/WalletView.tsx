import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { 
  Wallet, 
  TrendingUp, 
  TrendingDown, 
  Lock, 
  ChevronDown, 
  ChevronUp,
  ArrowUpRight,
  ArrowDownLeft,
  Clock
} from 'lucide-react';

interface WalletViewProps {
  // Future: connect to real wallet data
}

interface Transaction {
  id: string;
  type: 'income' | 'expense' | 'withdrawal' | 'deposit';
  amount: number;
  description: string;
  timestamp: Date;
  status: 'completed' | 'pending' | 'failed';
}

export function WalletView({ }: WalletViewProps) {
  const [expandedSection, setExpandedSection] = useState<string | null>(null);
  
  // Mock data - will be replaced with API
  const wallet = {
    availableBalance: 1250.50,
    frozenAmount: 300.00,
    totalIncome: 2800.00,
    totalExpense: 1550.50
  };
  
  const transactions: Transaction[] = [
    {
      id: '1',
      type: 'income',
      amount: 150,
      description: 'PPT设计任务完成',
      timestamp: new Date(Date.now() - 2 * 60 * 60 * 1000),
      status: 'completed'
    },
    {
      id: '2',
      type: 'expense',
      amount: 300,
      description: '视频剪辑任务支付',
      timestamp: new Date(Date.now() - 5 * 60 * 60 * 1000),
      status: 'pending'
    },
    {
      id: '3',
      type: 'income',
      amount: 200,
      description: 'Logo设计任务完成',
      timestamp: new Date(Date.now() - 24 * 60 * 60 * 1000),
      status: 'completed'
    }
  ];
  
  const formatTime = (date: Date) => {
    const now = new Date();
    const diff = now.getTime() - date.getTime();
    const hours = Math.floor(diff / 3600000);
    const days = Math.floor(diff / 86400000);
    
    if (hours < 24) return `${hours}小时前`;
    if (days < 7) return `${days}天前`;
    return date.toLocaleDateString();
  };
  
  const toggleSection = (section: string) => {
    setExpandedSection(expandedSection === section ? null : section);
  };
  
  return (
    <div className="h-full flex flex-col bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b px-4 py-4">
        <h1 className="text-xl font-semibold">我的钱包</h1>
      </div>
      
      {/* Balance Card - Minimalist Design */}
      <div className="p-4">
        <Card className="p-6 bg-gradient-to-br from-blue-500 to-blue-600 text-white">
          <div className="flex items-center gap-2 mb-2">
            <Wallet className="w-5 h-5" />
            <span className="text-sm opacity-80">可用余额</span>
          </div>
          <h2 className="text-4xl font-bold mb-6">
            ¥{wallet.availableBalance.toFixed(2)}
          </h2>
          
          <div className="flex gap-3">
            <Button 
              variant="secondary" 
              size="sm" 
              className="flex-1 bg-white/20 hover:bg-white/30 border-none text-white"
              onClick={() => console.log('Withdraw')}
            >
              <ArrowUpRight className="w-4 h-4 mr-1" />
              提现
            </Button>
            <Button 
              variant="secondary" 
              size="sm" 
              className="flex-1 bg-white/20 hover:bg-white/30 border-none text-white"
              onClick={() => console.log('Deposit')}
            >
              <ArrowDownLeft className="w-4 h-4 mr-1" />
              充值
            </Button>
          </div>
        </Card>
      </div>
      
      {/* Collapsible Sections */}
      <div className="flex-1 overflow-y-auto px-4 space-y-2 pb-4">
        {/* Frozen Amount Section */}
        <Card className="overflow-hidden">
          <button
            onClick={() => toggleSection('frozen')}
            className="w-full p-4 flex items-center justify-between hover:bg-gray-50 transition-colors"
          >
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-orange-100 flex items-center justify-center">
                <Lock className="w-5 h-5 text-orange-600" />
              </div>
              <div className="text-left">
                <h3 className="font-semibold">冻结金额</h3>
                <p className="text-sm text-gray-500">订单进行中</p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <span className="font-bold text-orange-600">¥{wallet.frozenAmount.toFixed(2)}</span>
              {expandedSection === 'frozen' ? (
                <ChevronUp className="w-5 h-5 text-gray-400" />
              ) : (
                <ChevronDown className="w-5 h-5 text-gray-400" />
              )}
            </div>
          </button>
          
          {expandedSection === 'frozen' && (
            <motion.div
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: 'auto', opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              className="border-t p-4 bg-gray-50"
            >
              <p className="text-sm text-gray-600">
                这部分资金将在任务完成并验收后自动释放给接单者
              </p>
            </motion.div>
          )}
        </Card>
        
        {/* Transaction History Section */}
        <Card className="overflow-hidden">
          <button
            onClick={() => toggleSection('transactions')}
            className="w-full p-4 flex items-center justify-between hover:bg-gray-50 transition-colors"
          >
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-blue-100 flex items-center justify-center">
                <Clock className="w-5 h-5 text-blue-600" />
              </div>
              <div className="text-left">
                <h3 className="font-semibold">交易明细</h3>
                <p className="text-sm text-gray-500">查看所有交易</p>
              </div>
            </div>
            {expandedSection === 'transactions' ? (
              <ChevronUp className="w-5 h-5 text-gray-400" />
            ) : (
              <ChevronDown className="w-5 h-5 text-gray-400" />
            )}
          </button>
          
          {expandedSection === 'transactions' && (
            <motion.div
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: 'auto', opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              className="border-t bg-white"
            >
              <div className="divide-y">
                {transactions.map(tx => (
                  <div key={tx.id} className="p-4 hover:bg-gray-50">
                    <div className="flex items-start justify-between">
                      <div className="flex items-start gap-3">
                        <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                          tx.type === 'income' 
                            ? 'bg-green-100' 
                            : 'bg-red-100'
                        }`}>
                          {tx.type === 'income' ? (
                            <TrendingUp className="w-4 h-4 text-green-600" />
                          ) : (
                            <TrendingDown className="w-4 h-4 text-red-600" />
                          )}
                        </div>
                        <div>
                          <p className="text-sm font-medium">{tx.description}</p>
                          <p className="text-xs text-gray-500 flex items-center gap-1 mt-1">
                            <Clock className="w-3 h-3" />
                            {formatTime(tx.timestamp)}
                          </p>
                        </div>
                      </div>
                      <div className="text-right">
                        <p className={`font-semibold ${
                          tx.type === 'income' 
                            ? 'text-green-600' 
                            : 'text-red-600'
                        }`}>
                          {tx.type === 'income' ? '+' : '-'}¥{tx.amount}
                        </p>
                        <Badge 
                          variant={tx.status === 'completed' ? 'default' : 'secondary'}
                          className="text-xs mt-1"
                        >
                          {tx.status === 'completed' ? '已完成' : '处理中'}
                        </Badge>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </motion.div>
          )}
        </Card>
        
        {/* Income/Expense Summary */}
        <Card className="p-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <div className="flex items-center gap-2 mb-1">
                <TrendingUp className="w-4 h-4 text-green-500" />
                <span className="text-sm text-gray-600">总收入</span>
              </div>
              <p className="text-xl font-bold text-green-600">
                ¥{wallet.totalIncome.toFixed(2)}
              </p>
            </div>
            <div>
              <div className="flex items-center gap-2 mb-1">
                <TrendingDown className="w-4 h-4 text-red-500" />
                <span className="text-sm text-gray-600">总支出</span>
              </div>
              <p className="text-xl font-bold text-red-600">
                ¥{wallet.totalExpense.toFixed(2)}
              </p>
            </div>
          </div>
        </Card>
      </div>
    </div>
  );
}
