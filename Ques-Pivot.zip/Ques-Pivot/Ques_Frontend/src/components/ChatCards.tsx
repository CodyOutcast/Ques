import React, { useState, useRef, useEffect, forwardRef, useImperativeHandle } from 'react';
import { motion, AnimatePresence, PanInfo, useMotionValue, useTransform, animate } from 'framer-motion';
import { Share2, ChevronDown, ChevronUp, DollarSign, Clock, Users } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';
import { calculateAge } from '../utils/dateUtils';
import type { UserRole } from '../types/pivot';

interface Profile {
  id: string;
  name: string;
  birthday?: string;
  gender?: string;
  avatar: string;
  location: string;
  hobbies?: string[];
  languages?: string[];
  skills: string[];
  resources?: string[];
  projects?: { 
    title: string; 
    role: string; 
    description: string; 
    referenceLinks: string[] 
  }[];
  goals?: string[];
  demands?: string[];
  institutions?: { 
    name: string; 
    role: string; 
    description: string; 
    verified: boolean;
  }[];
  university?: {
    name: string;
    verified: boolean;
  };
  // ❌ DEPRECATED: Being removed in pivot
  matchScore?: number;
  whyMatch?: string;
  bio: string;
  oneSentenceIntro?: string;
  // 🔴 NEW: Task-specific fields
  _isTask?: boolean;
  _taskData?: any;
}

interface ChatCardsProps {
  profiles: Profile[];
  onSwipeLeft: (profile: Profile) => void;
  onSwipeRight: (profile: Profile) => void;
  onAllCardsFinished?: () => void;
  currentRole?: UserRole;
}

export interface ChatCardsRef {
  resetLastSwipe: () => void;
}

const ChatCards = forwardRef<ChatCardsRef, ChatCardsProps>(({ profiles, onSwipeLeft, onSwipeRight, onAllCardsFinished, currentRole = 'poster' }, ref) => {
  const { t } = useLanguage();
  const [currentIndex, setCurrentIndex] = useState(0);
  const [showFullProfile, setShowFullProfile] = useState(false);
  const [exitDirection, setExitDirection] = useState<'left' | 'right' | null>(null);
  const [dragDirection, setDragDirection] = useState<'left' | 'right' | null>(null);
  const [isDragging, setIsDragging] = useState(false);
  const [dragStart, setDragStart] = useState({ x: 0, y: 0 });
  const [pendingSwipe, setPendingSwipe] = useState<{ profile: Profile; direction: 'left' | 'right' } | null>(null);
  const constraintsRef = useRef(null);
  
  // 🔴 NEW: Helper to format deadline
  const formatDeadline = (deadline?: string) => {
    if (!deadline) return '未设置';
    const now = new Date();
    const end = new Date(deadline);
    const diff = end.getTime() - now.getTime();
    const days = Math.floor(diff / (1000 * 60 * 60 * 24));
    const hours = Math.floor((diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
    
    if (days > 0) {
      return `${days}天${hours}小时`;
    } else if (hours > 0) {
      return `${hours}小时`;
    } else {
      return '即将截止';
    }
  };
  
  // Motion values for smooth dragging
  const x = useMotionValue(0);
  const rotate = useTransform(x, [-500, -200, 0, 200, 500], [-45, -20, 0, 20, 45]); // Rotate based on drag distance
  
  // Reset motion values when card changes
  useEffect(() => {
    x.set(0);
  }, [currentIndex, x]);
  
  // Check if all cards are finished
  useEffect(() => {
    if ((profiles.length === 0 || currentIndex >= profiles.length) && onAllCardsFinished) {
      onAllCardsFinished();
    }
  }, [currentIndex, profiles.length, onAllCardsFinished]);

  // 暴露重置方法给父组件
  useImperativeHandle(ref, () => ({
    resetLastSwipe: () => {
      console.log('🔄 Resetting last swipe', pendingSwipe);
      if (pendingSwipe && currentIndex > 0) {
        // 回退到上一张卡片
        setCurrentIndex(prev => Math.max(0, prev - 1));
        
        // 取消退出动画
        setExitDirection(null);
        setPendingSwipe(null);
        setShowFullProfile(false);
        
        // 将卡片位置重置到中心
        x.set(0);
        
        console.log('✅ Card reset successfully - returning to previous card');
      }
    }
  }), [pendingSwipe, currentIndex, x]);

  if (profiles.length === 0 || currentIndex >= profiles.length) {
    return null;
  }

  const currentProfile = profiles[currentIndex];

  const handleDragStart = (event: any, info: PanInfo) => {
    setDragStart({ x: info.point.x, y: info.point.y });
    setIsDragging(false);
  };

  const handleDrag = (event: any, info: PanInfo) => {
    const { offset, point } = info;
    const deltaX = Math.abs(point.x - dragStart.x);
    const deltaY = Math.abs(point.y - dragStart.y);
    
    // Determine if this is horizontal drag or vertical scroll
    if (!isDragging && (deltaX > 10 || deltaY > 10)) {
      // If horizontal movement is more dominant, treat as drag
      if (deltaX > deltaY * 1.5) {
        setIsDragging(true);
      }
    }
    
    // Only show drag feedback if we're actually dragging horizontally
    if (isDragging && Math.abs(offset.x) > 20) {
      setDragDirection(offset.x > 0 ? 'right' : 'left');
    } else if (!isDragging) {
      setDragDirection(null);
    }
  };

  const handleDragEnd = (event: any, info: PanInfo) => {
    const { offset, velocity } = info;
    
    // Only process swipe if we were actually dragging (not scrolling)
    // Lower threshold for more responsive swiping like Tinder
    if (isDragging && (Math.abs(offset.x) > 80 || Math.abs(velocity.x) > 400)) {
      // Set exit direction immediately for instant response
      const direction = offset.x > 0 ? 'right' : 'left';
      
      console.log('💫 ChatCards handleDragEnd:', { 
        direction, 
        profileName: currentProfile.name,
        offset: offset.x 
      });
      
      // 保存待处理的滑动状态（用于可能的重置）
      setPendingSwipe({ profile: currentProfile, direction });
      
      // Reset drag states
      setDragDirection(null);
      setIsDragging(false);
      
      // Call appropriate callback
      if (direction === 'right') {
        console.log('➡️ Calling onSwipeRight for:', currentProfile.name);
        onSwipeRight(currentProfile);
      } else {
        console.log('⬅️ Calling onSwipeLeft for:', currentProfile.name);
        onSwipeLeft(currentProfile);
      }
      
      // Animate the card exit
      animate(x, direction === 'right' ? 500 : -500, {
        duration: 0.3,
        ease: [0.32, 0.72, 0, 1]
      });
      
      // Set exit direction for opacity and scale animation
      setExitDirection(direction);
      
      // Update state after animation completes
      setTimeout(() => {
        setCurrentIndex(prev => prev + 1);
        setExitDirection(null);
        setShowFullProfile(false);
      }, 300); // Match animation duration
    } else {
      setDragDirection(null);
      setIsDragging(false);
      // Animate back to center if swipe was not successful (rotate will follow automatically)
      animate(x, 0, {
        type: "spring",
        damping: 30,
        stiffness: 400
      });
    }
  };

  const handleShareProfile = () => {
    console.log('Sharing profile:', currentProfile.name);
  };

  const toggleExtendedProfile = () => {
    setShowFullProfile(!showFullProfile);
  };

  const nextProfiles = profiles.slice(currentIndex + 1, currentIndex + 3); // Get next 2 profiles for stack effect

  return (
    <div className="relative w-full flex flex-col items-center">
      <div className="relative" ref={constraintsRef} style={{ width: '300px', height: '420px' }}>
        {/* Background cards (stack effect) - Show next 2 cards */}
        {nextProfiles.map((profile, index) => (
          <motion.div
            key={`bg-${profile.id}`}
            className="absolute"
            style={{ 
              width: '300px', 
              height: '400px',
              top: (index + 1) * 10,
              left: 0,
              zIndex: nextProfiles.length - index
            }}
            initial={false}
            animate={{ 
              scale: 0.96 - (index * 0.02), 
              y: (index + 1) * 10
            }}
            transition={{ 
              type: "spring", 
              damping: 25, 
              stiffness: 300
            }}
          >
            <div 
              className="relative bg-white rounded-2xl overflow-hidden w-full h-full"
              style={{
                boxShadow: index === 0 
                  ? '0 8px 24px rgba(0, 0, 0, 0.15), 0 2px 8px rgba(0, 0, 0, 0.1)'
                  : '0 12px 32px rgba(0, 0, 0, 0.2), 0 4px 12px rgba(0, 0, 0, 0.15)'
              }}
            >
              {/* Background card - full collapsed view (non-interactive) */}
              <div className="relative w-full h-full pointer-events-none">
                {/* Profile Background */}
                <div className="relative w-full h-full flex items-center justify-center">
                  <div className="text-9xl select-none" style={{ fontSize: '12rem', lineHeight: '1' }}>
                    {profile.avatar}
                  </div>
                  <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-transparent to-transparent" />
                </div>

                {/* Bottom content area */}
                <div className="absolute bottom-0 left-0 right-0 p-6 text-white">
                  <div className="flex items-center justify-between mb-2">
                    <h2 className="text-lg font-bold">
                      {profile.name}
                    </h2>
                    <div className="flex gap-2">
                      <div className="p-2 bg-white/20 backdrop-blur-sm rounded-full">
                        <Share2 size={16} />
                      </div>
                      <div className="p-2 bg-blue-500 rounded-full">
                        <ChevronDown size={16} />
                      </div>
                    </div>
                  </div>
                  <p className="text-white/90 text-xs line-clamp-1 mb-3">
                    {profile.oneSentenceIntro || profile.bio}
                  </p>
                </div>
              </div>
            </div>
          </motion.div>
        ))}
        
        <AnimatePresence>
          {/* Main Card Container */}
          <motion.div
            key={currentProfile.id}
            className="absolute top-0 left-0 bg-white rounded-2xl overflow-hidden"
            style={{ 
              width: '300px', 
              height: '400px', 
              zIndex: exitDirection ? 50 : 10, // Higher z-index when exiting
              boxShadow: '0 20px 50px rgba(0, 0, 0, 0.3), 0 10px 20px rgba(0, 0, 0, 0.2), 0 0 0 1px rgba(0, 0, 0, 0.1)',
              x: x, // Always use motion value
              rotate: rotate // Always use motion value
            }}
            initial={{ scale: 0.96, y: 10, opacity: 1 }}
            animate={exitDirection ? {
              opacity: 0,
              scale: 0.8,
              transition: { duration: 0.3, ease: [0.32, 0.72, 0, 1] }
            } : { 
              scale: 1, 
              y: 0, 
              opacity: 1,
              transition: { 
                type: "spring", 
                damping: 30, 
                stiffness: 400
              }
            }}
            exit={{
              opacity: 0,
              transition: { duration: 0.1 }
            }}
          >
            {/* Drag Area - only for collapsed view or non-scrollable areas when expanded */}
            {!exitDirection && !showFullProfile && (
              <motion.div
                className="absolute inset-0 cursor-grab active:cursor-grabbing z-10"
                drag="x"
                dragElastic={0}
                onDragStart={handleDragStart}
                onDrag={handleDrag}
                onDragEnd={handleDragEnd}
                style={{ x }}
                dragMomentum={false}
                whileDrag={{ scale: 1.02 }}
              />
            )}
            {!exitDirection && showFullProfile && (
              /* Drag Area for expanded view - only covers header, excludes scrollable content */
              <motion.div
                className="absolute top-0 left-0 right-0 cursor-grab active:cursor-grabbing z-10"
                style={{ height: '80px', x }} // Only cover the header area
                drag="x"
                dragElastic={0}
                onDragStart={handleDragStart}
                onDrag={handleDrag}
                onDragEnd={handleDragEnd}
                dragMomentum={false}
              />
            )}

            {/* Drag Feedback Overlays */}
            <motion.div
              className="absolute inset-0 bg-red-500/20 flex items-center justify-center z-20 pointer-events-none"
              initial={{ opacity: 0 }}
              animate={{ opacity: dragDirection === 'left' ? 1 : 0 }}
              transition={{ duration: 0.1 }}
            >
              <div className="text-6xl">✕</div>
            </motion.div>
            
            <motion.div
              className="absolute inset-0 bg-green-500/20 flex items-center justify-center z-20 pointer-events-none"
              initial={{ opacity: 0 }}
              animate={{ opacity: dragDirection === 'right' ? 1 : 0 }}
              transition={{ duration: 0.1 }}
            >
              <div className="text-6xl">💬</div>
            </motion.div>

            <AnimatePresence mode="wait">
              {!showFullProfile ? (
                /* Collapsed Card View - 🔴 UPDATED: Different layout for tasks vs profiles */
                <motion.div
                  key="collapsed"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  transition={{ duration: 0.3, ease: "easeInOut" }}
                  className="relative w-full h-full"
                >
                  {/* Profile Background */}
                  <div className="relative w-full h-full flex items-center justify-center">
                    <div className="text-9xl select-none" style={{ fontSize: '12rem', lineHeight: '1' }}>
                      {currentProfile.avatar}
                    </div>
                    <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-transparent to-transparent" />
                  </div>

                  {/* Bottom content area - 🔴 Different content for tasks */}
                  <div className="absolute bottom-0 left-0 right-0 p-6 text-white z-30">
                    <div className="flex items-center justify-between mb-2">
                      <h2 className="text-lg font-bold">
                        {currentProfile.name}
                      </h2>
                      <div className="flex gap-2 relative z-50">
                        <button
                          onClick={handleShareProfile}
                          className="p-2 bg-white/20 backdrop-blur-sm rounded-full hover:bg-white/30 transition-colors relative z-50"
                        >
                          <Share2 size={16} />
                        </button>
                        <button
                          onClick={toggleExtendedProfile}
                          className="p-2 bg-blue-500 rounded-full hover:bg-blue-600 transition-colors relative z-50"
                        >
                          <ChevronDown size={16} />
                        </button>
                      </div>
                    </div>
                    
                    {/* 🔴 NEW: Show task info or profile info based on _isTask */}
                    {currentProfile._isTask && currentProfile._taskData ? (
                      <>
                        {/* Task Info */}
                        <div className="space-y-2 mb-12">
                          <div className="flex items-center gap-2 text-sm">
                            <DollarSign size={14} />
                            <span className="font-bold text-orange-300">¥{currentProfile._taskData.budget.min}-{currentProfile._taskData.budget.max}</span>
                          </div>
                          <div className="flex items-center gap-2 text-xs">
                            <Clock size={12} />
                            <span className="text-red-300">还剩 {formatDeadline(currentProfile._taskData.deadline)}</span>
                          </div>
                          <div className="flex items-center gap-2 text-xs">
                            <Users size={12} />
                            <span className="text-white/80">已有 {currentProfile._taskData.applicationCount} 人申请</span>
                          </div>
                        </div>
                      </>
                    ) : (
                      <>
                        {/* Profile Info */}
                        <p className="text-white/90 text-xs line-clamp-1 mb-3">
                          {currentProfile.oneSentenceIntro || currentProfile.bio}
                        </p>
                      </>
                    )}
                  </div>
                </motion.div>
              ) : (
                /* Expanded Card View */
                <motion.div
                  key="expanded"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  transition={{ duration: 0.3, ease: "easeInOut" }}
                  className="relative w-full h-full flex flex-col"
                >
                  {/* Header with avatar and basic info */}
                  <div className="bg-gray-50 p-4 border-b border-gray-200 flex-shrink-0 relative" style={{ height: '80px' }}>
                    <div className="flex items-center justify-between h-full">
                      <div className="flex items-center gap-3">
                        <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center text-2xl">
                          {currentProfile.avatar}
                        </div>
                        <div>
                          <h3 className="font-semibold text-gray-900">{currentProfile.name}</h3>
                          <p className="text-sm text-gray-600">{currentProfile.location} • {currentProfile.birthday ? calculateAge(currentProfile.birthday) : '--'}岁</p>
                        </div>
                      </div>
                      <div className="flex gap-2 relative z-50">
                        <button
                          onClick={handleShareProfile}
                          className="p-2 bg-white rounded-full shadow-sm hover:bg-gray-50 transition-colors relative z-50"
                        >
                          <Share2 size={16} className="text-gray-600" />
                        </button>
                        <button
                          onClick={toggleExtendedProfile}
                          className="p-2 bg-blue-500 rounded-full hover:bg-blue-600 transition-colors relative z-50"
                        >
                          <ChevronUp size={16} className="text-white" />
                        </button>
                      </div>
                    </div>
                  </div>

                  {/* Scrollable Content - 🔴 UPDATED: Different content for tasks */}
                  <div 
                    className="flex-1 overflow-y-auto" 
                    style={{ height: 'calc(400px - 80px)' }}
                  >
                    <div className="p-4 space-y-4">
                      {/* 🔴 NEW: Task Details or Profile Details */}
                      {currentProfile._isTask && currentProfile._taskData ? (
                        <>
                          {/* Task Description */}
                          <div>
                            <h4 className="font-semibold text-gray-900 text-sm mb-2">任务描述</h4>
                            <p className="text-gray-700 text-xs leading-relaxed">{currentProfile.bio}</p>
                          </div>

                          {/* Budget & Deadline */}
                          <div className="grid grid-cols-2 gap-3">
                            <div className="bg-orange-50 p-3 rounded-lg">
                              <p className="text-xs text-gray-600 mb-1">预算</p>
                              <p className="text-lg font-bold text-orange-600">
                                ¥{currentProfile._taskData.budget.min}-{currentProfile._taskData.budget.max}
                              </p>
                            </div>
                            <div className="bg-red-50 p-3 rounded-lg">
                              <p className="text-xs text-gray-600 mb-1">截止时间</p>
                              <p className="text-sm font-semibold text-red-600">
                                还剩 {formatDeadline(currentProfile._taskData.deadline)}
                              </p>
                            </div>
                          </div>

                          {/* Required Skills */}
                          <div>
                            <h4 className="font-semibold text-gray-900 text-sm mb-2">所需技能</h4>
                            <div className="flex flex-wrap gap-1">
                              {currentProfile.skills.map((skill, index) => (
                                <span key={index} className="px-2 py-1 bg-blue-100 text-blue-800 rounded-full text-xs">
                                  {skill}
                                </span>
                              ))}
                            </div>
                          </div>

                          {/* Deliverables */}
                          {currentProfile._taskData.deliverables && currentProfile._taskData.deliverables.length > 0 && (
                            <div>
                              <h4 className="font-semibold text-gray-900 text-sm mb-2">交付要求</h4>
                              <ul className="list-disc list-inside space-y-1 text-xs text-gray-700">
                                {currentProfile._taskData.deliverables.map((item: string, index: number) => (
                                  <li key={index}>{item}</li>
                                ))}
                              </ul>
                            </div>
                          )}

                          {/* Poster Info */}
                          <div className="bg-gray-50 p-3 rounded-lg border border-gray-200">
                            <h4 className="font-semibold text-gray-900 text-sm mb-2">发单者信息</h4>
                            <div className="flex items-center gap-2 mb-2">
                              <div className="text-2xl">{currentProfile._taskData.poster.avatar}</div>
                              <div>
                                <p className="font-medium text-sm">{currentProfile._taskData.poster.name}</p>
                                <p className="text-xs text-gray-500">{currentProfile._taskData.poster.university.name}</p>
                              </div>
                            </div>
                            <div className="flex gap-2 text-xs">
                              <span className="px-2 py-1 bg-yellow-100 text-yellow-800 rounded">
                                ★ {currentProfile._taskData.poster.posterRating.toFixed(1)}
                              </span>
                              <span className="px-2 py-1 bg-blue-100 text-blue-800 rounded">
                                发单 {currentProfile._taskData.poster.postedTasksCount}次
                              </span>
                              <span className="px-2 py-1 bg-green-100 text-green-800 rounded">
                                按时付款 {currentProfile._taskData.poster.onTimePaymentRate}%
                              </span>
                            </div>
                          </div>
                        </>
                      ) : (
                        <>
                          {/* Original Profile Content */}
                          {/* Resources */}
                          {currentProfile.resources && currentProfile.resources.length > 0 && (
                            <div>
                              <h4 className="font-semibold text-gray-900 text-sm mb-2">{t('cards.resources')}</h4>
                              <div className="flex flex-wrap gap-1">
                                {currentProfile.resources.map((resource, index) => (
                                  <span key={index} className="px-2 py-1 bg-green-100 text-green-800 rounded-full text-xs">
                                    {resource}
                                  </span>
                                ))}
                              </div>
                            </div>
                          )}

                          {/* Skills */}
                          <div>
                            <h4 className="font-semibold text-gray-900 text-sm mb-2">{t('cards.skills')}</h4>
                            <div className="flex flex-wrap gap-1">
                              {currentProfile.skills.map((skill, index) => (
                                <span key={index} className="px-2 py-1 bg-blue-100 text-blue-800 rounded-full text-xs">
                                  {skill}
                                </span>
                              ))}
                            </div>
                          </div>
                        </>
                      )}

                      {/* Languages & Hobbies */}
                      <div className="grid grid-cols-2 gap-3">
                        <div>
                          <h4 className="font-semibold text-gray-900 text-sm mb-2">{t('cards.languages')}</h4>
                          <div className="flex flex-wrap gap-1 overflow-x-hidden min-w-0">
                            {currentProfile.languages && currentProfile.languages.map((language, index) => (
                              <span key={index} className="px-2 py-1 bg-purple-100 text-purple-800 rounded-full text-xs max-w-full whitespace-normal break-all">
                                {language}
                              </span>
                            ))}
                          </div>
                        </div>
                        <div>
                          <h4 className="font-semibold text-gray-900 text-sm mb-2">{t('cards.hobbies')}</h4>
                          <div className="flex flex-wrap gap-1 overflow-x-hidden min-w-0">
                            {currentProfile.hobbies && currentProfile.hobbies.map((hobby, index) => (
                              <span key={index} className="px-2 py-1 bg-pink-100 text-pink-800 rounded-full text-xs max-w-full whitespace-normal break-all">
                                {hobby}
                              </span>
                            ))}
                          </div>
                        </div>
                      </div>

                      {/* Projects */}
                      {currentProfile.projects && currentProfile.projects.length > 0 && (
                        <div>
                          <h4 className="font-semibold text-gray-900 text-sm mb-2">{t('cards.projects')}</h4>
                          <div className="space-y-3">
                            {currentProfile.projects.map((project, index) => (
                              <div key={index} className="bg-gray-50 rounded-lg p-3 border border-gray-200">
                                <h5 className="font-medium text-gray-900 text-xs mb-1">{project.title}</h5>
                                <p className="text-blue-600 text-xs mb-1">{project.role}</p>
                                <p className="text-gray-700 text-xs mb-2 leading-relaxed">{project.description}</p>
                                {project.referenceLinks.length > 0 && (
                                  <div className="space-y-1">
                                    {project.referenceLinks.map((link, linkIndex) => (
                                      <a 
                                        key={linkIndex} 
                                        href={link} 
                                        className="text-xs text-blue-500 block hover:underline break-all"
                                        target="_blank" 
                                        rel="noopener noreferrer"
                                      >
                                        {link}
                                      </a>
                                    ))}
                                  </div>
                                )}
                              </div>
                            ))}
                          </div>
                        </div>
                      )}

                      {/* Institutions */}
                      {currentProfile.institutions && currentProfile.institutions.length > 0 && (
                        <div>
                          <h4 className="font-semibold text-gray-900 text-sm mb-2">{t('cards.institutions')}</h4>
                          <div className="space-y-3">
                            {currentProfile.institutions.map((institution, index) => (
                              <div key={index} className="bg-gray-50 rounded-lg p-3 border border-gray-200">
                                <h5 className="font-medium text-gray-900 text-xs mb-1">{institution.name}</h5>
                                <p className="text-blue-600 text-xs mb-1">{institution.role}</p>
                                <p className="text-gray-700 text-xs">{institution.description}</p>
                              </div>
                            ))}
                          </div>
                        </div>
                      )}

                      {/* University */}
                      {currentProfile.university && (
                        <div>
                          <h4 className="font-semibold text-gray-900 text-sm mb-2">{t('cards.university')}</h4>
                          <div className="bg-gradient-to-r from-blue-50 to-indigo-50 rounded-lg p-3 border border-blue-200">
                            <div className="flex items-start justify-between gap-2 mb-1">
                              <h5 className="font-medium text-gray-900 text-xs leading-tight flex-1 min-w-0 pr-2">
                                {currentProfile.university.name}
                              </h5>
                              {currentProfile.university.verified && (
                                <span className="text-blue-600 text-xs font-medium bg-blue-100 px-2 py-1 rounded-full whitespace-nowrap flex-shrink-0 flex items-center gap-1">
                                  <span>🎓</span>
                                  <span>{t('cards.verified')}</span>
                                </span>
                              )}
                            </div>
                            <p className="text-blue-700 text-xs">{t('cards.currentUniversity')}</p>
                          </div>
                        </div>
                      )}

                      {/* ❌ REMOVED: Why We Match section (matchScore/whyMatch) */}
                    </div>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </motion.div>
        </AnimatePresence>
      </div>
    </div>
  );
});

ChatCards.displayName = 'ChatCards';

export default ChatCards;
