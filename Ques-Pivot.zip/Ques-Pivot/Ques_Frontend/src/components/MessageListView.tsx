import React, { useState } from 'react';
import { Card } from './ui/card';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { MessageCircle, Clock, ArrowLeft, Send, Paperclip, MoreVertical } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

interface ChatMessage {
  id: string;
  senderId: string;
  content: string;
  timestamp: Date;
  type: 'text' | 'image' | 'file';
}

interface Conversation {
  id: string;
  partnerId: string;
  partnerName: string;
  partnerAvatar: string;
  taskTitle?: string;
  messages: ChatMessage[];
}

interface Message {
  id: string;
  partnerId: string;
  partnerName: string;
  partnerAvatar: string;
  lastMessage: string;
  timestamp: Date;
  unread: number;
  taskTitle?: string;
}

interface MessageListViewProps {
  // Future: user profile, messages data
}

export function MessageListView({ }: MessageListViewProps) {
  const [selectedConversation, setSelectedConversation] = useState<string | null>(null);
  const [messageInput, setMessageInput] = useState('');
  
  // Mock data - 高校线下任务场景
  const mockMessages: Message[] = [
    {
      id: '1',
      partnerId: 'user1',
      partnerName: '张小明',
      partnerAvatar: '👨‍💻',
      lastMessage: '好的，周三早上7:45我会准时到理科楼',
      timestamp: new Date(Date.now() - 5 * 60 * 1000),
      unread: 2,
      taskTitle: '帮忙代签到'
    },
    {
      id: '2',
      partnerId: 'user2',
      partnerName: '李华',
      partnerAvatar: '📚',
      lastMessage: '标注结果已完成，请查收Excel文件',
      timestamp: new Date(Date.now() - 2 * 60 * 60 * 1000),
      unread: 0,
      taskTitle: '论文数据标注'
    },
    {
      id: '3',
      partnerId: 'user3',
      partnerName: '王芳',
      partnerAvatar: '�',
      lastMessage: '题目都讲完了，有问题随时问我',
      timestamp: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000),
      unread: 0,
      taskTitle: '高数作业辅导'
    },
    {
      id: '4',
      partnerId: 'user4',
      partnerName: '赵敏',
      partnerAvatar: '🎤',
      lastMessage: '周六下午1:50在大礼堂广场集合吧',
      timestamp: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000),
      unread: 1,
      taskTitle: '活动现场帮手'
    }
  ];
  
  // Mock conversation data - 高校任务对话
  const mockConversation: Conversation | null = selectedConversation ? {
    id: selectedConversation,
    partnerId: mockMessages.find(m => m.id === selectedConversation)?.partnerId || '',
    partnerName: mockMessages.find(m => m.id === selectedConversation)?.partnerName || '',
    partnerAvatar: mockMessages.find(m => m.id === selectedConversation)?.partnerAvatar || '👤',
    taskTitle: mockMessages.find(m => m.id === selectedConversation)?.taskTitle,
    messages: [
      {
        id: 'm1',
        senderId: 'user1',
        content: '你好，我想确认一下签到的具体时间和地点',
        timestamp: new Date(Date.now() - 60 * 60 * 1000),
        type: 'text'
      },
      {
        id: 'm2',
        senderId: 'me',
        content: '周三和周五早上7:50前，理科楼A301教室。你需要帮我在签到表上签名，我会发学生证照片给你核对',
        timestamp: new Date(Date.now() - 55 * 60 * 1000),
        type: 'text'
      },
      {
        id: 'm3',
        senderId: 'user1',
        content: '明白了，我就住在理科楼附近，早上7:45准时到',
        timestamp: new Date(Date.now() - 50 * 60 * 1000),
        type: 'text'
      },
      {
        id: 'm4',
        senderId: 'me',
        content: '太好了！到时候请拍个照片发给我确认一下',
        timestamp: new Date(Date.now() - 10 * 60 * 1000),
        type: 'text'
      },
      {
        id: 'm5',
        senderId: 'user1',
        content: '好的，周三早上7:45我会准时到理科楼',
        timestamp: new Date(Date.now() - 5 * 60 * 1000),
        type: 'text'
      }
    ]
  } : null;
  
  const formatTimestamp = (date: Date) => {
    const now = new Date();
    const diff = now.getTime() - date.getTime();
    const minutes = Math.floor(diff / 60000);
    const hours = Math.floor(diff / 3600000);
    const days = Math.floor(diff / 86400000);
    
    if (minutes < 60) return `${minutes}分钟前`;
    if (hours < 24) return `${hours}小时前`;
    if (days < 7) return `${days}天前`;
    return date.toLocaleDateString();
  };
  
  const formatMessageTime = (date: Date) => {
    const hours = date.getHours().toString().padStart(2, '0');
    const minutes = date.getMinutes().toString().padStart(2, '0');
    return `${hours}:${minutes}`;
  };
  
  const handleSendMessage = () => {
    if (!messageInput.trim()) return;
    
    // TODO: Call API to send message
    console.log('Send message:', messageInput);
    setMessageInput('');
    alert('消息已发送！');
  };
  
  // If viewing a conversation, show conversation view
  if (selectedConversation && mockConversation) {
    return (
      <div className="h-full flex flex-col bg-white">
        {/* Conversation Header */}
        <div className="bg-white border-b px-4 py-3 flex items-center gap-3">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setSelectedConversation(null)}
            className="p-1"
          >
            <ArrowLeft className="w-5 h-5" />
          </Button>
          
          <div className="w-10 h-10 rounded-full flex items-center justify-center bg-gray-100 text-xl">
            {mockConversation.partnerAvatar}
          </div>
          
          <div className="flex-1">
            <h2 className="font-semibold">{mockConversation.partnerName}</h2>
            {mockConversation.taskTitle && (
              <p className="text-xs text-gray-500">{mockConversation.taskTitle}</p>
            )}
          </div>
          
          <Button variant="ghost" size="sm" className="p-1">
            <MoreVertical className="w-5 h-5" />
          </Button>
        </div>
        
        {/* Messages */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          {mockConversation.messages.map((message, index) => {
            const isMe = message.senderId === 'me';
            
            return (
              <motion.div
                key={message.id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.05 }}
                className={`flex ${isMe ? 'justify-end' : 'justify-start'}`}
              >
                <div className={`max-w-[75%] ${isMe ? 'order-2' : 'order-1'}`}>
                  <div
                    className={`rounded-2xl px-4 py-2 ${
                      isMe
                        ? 'bg-blue-500 text-white rounded-br-sm'
                        : 'bg-gray-100 text-gray-900 rounded-bl-sm'
                    }`}
                  >
                    <p className="text-sm">{message.content}</p>
                  </div>
                  <p className={`text-xs text-gray-400 mt-1 ${isMe ? 'text-right' : 'text-left'}`}>
                    {formatMessageTime(message.timestamp)}
                  </p>
                </div>
              </motion.div>
            );
          })}
        </div>
        
        {/* Input Area */}
        <div className="border-t p-4 bg-white">
          <div className="flex items-center gap-2">
            <Button variant="ghost" size="sm" className="p-2">
              <Paperclip className="w-5 h-5" />
            </Button>
            
            <Input
              value={messageInput}
              onChange={(e) => setMessageInput(e.target.value)}
              onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
              placeholder="输入消息..."
              className="flex-1"
            />
            
            <Button
              onClick={handleSendMessage}
              disabled={!messageInput.trim()}
              size="sm"
              className="px-4"
            >
              <Send className="w-4 h-4" />
            </Button>
          </div>
        </div>
      </div>
    );
  }
  
  // Messages list view
  return (
    <div className="h-full flex flex-col bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b px-4 py-4">
        <h1 className="text-xl font-semibold">消息</h1>
      </div>
      
      {/* Messages List */}
      <div className="flex-1 overflow-y-auto">
        {mockMessages.length === 0 ? (
          <div className="text-center py-12">
            <MessageCircle className="w-16 h-16 mx-auto text-gray-300 mb-4" />
            <p className="text-gray-500">暂无消息</p>
          </div>
        ) : (
          <div className="divide-y divide-gray-200">
            {mockMessages.map((message, index) => (
              <motion.div
                key={message.id}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: index * 0.1 }}
              >
                <button 
                  className="w-full bg-white hover:bg-gray-50 px-4 py-4 text-left transition-colors"
                  onClick={() => setSelectedConversation(message.id)}
                >
                  <div className="flex items-start gap-3">
                    {/* Avatar */}
                    <div className="w-12 h-12 rounded-full flex items-center justify-center bg-gray-100 text-2xl flex-shrink-0 relative">
                      {message.partnerAvatar}
                      {message.unread > 0 && (
                        <div className="absolute -top-1 -right-1 w-5 h-5 bg-red-500 rounded-full flex items-center justify-center text-white text-xs font-semibold">
                          {message.unread}
                        </div>
                      )}
                    </div>
                    
                    {/* Content */}
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between mb-1">
                        <div className="flex items-center gap-2">
                          <h3 className="font-semibold">{message.partnerName}</h3>
                          {message.taskTitle && (
                            <Badge variant="outline" className="text-xs">
                              {message.taskTitle}
                            </Badge>
                          )}
                        </div>
                        <span className="text-xs text-gray-500 flex items-center gap-1">
                          <Clock className="w-3 h-3" />
                          {formatTimestamp(message.timestamp)}
                        </span>
                      </div>
                      
                      <p className={`text-sm truncate ${message.unread > 0 ? 'font-medium text-gray-900' : 'text-gray-600'}`}>
                        {message.lastMessage}
                      </p>
                    </div>
                  </div>
                </button>
              </motion.div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
