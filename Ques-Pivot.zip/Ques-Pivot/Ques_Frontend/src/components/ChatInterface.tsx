import React, { useState, useRef, useEffect, forwardRef, useImperativeHandle } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Input } from './ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Send, History, Bell, School, Globe, Briefcase, Upload, Paperclip, X, Trash2 } from 'lucide-react';
import { toast } from 'sonner';
import { Switch } from './ui/switch';
import { Label } from './ui/label';
import logoIcon from '../assets/icon.jpg';
import { useLanguage } from '../contexts/LanguageContext';
import type { UserProfile } from '../App';
import type { FriendRequest } from './NotificationPanel';
import type { UserRole } from '../types/pivot';
import ChatCards, { ChatCardsRef } from './ChatCards';

// 🆕 2024-10-23: AI-guided task posting flow with payment integration

interface Message {
  id: string;
  type: 'user' | 'ai';
  content: string;
  timestamp: Date;
  // 🆕 NEW: Extended message types for task flow
  specialType?: 'task-draft' | 'task-preview' | 'task-payment' | 'freelancer-recommendations';
  taskData?: TaskDraft; // For task-draft and task-preview
  paymentData?: PaymentInfo; // For task-payment
  recommendedFreelancers?: UserRecommendation[]; // For freelancer-recommendations
}

// 🆕 NEW: Task draft structure for poster mode
interface TaskDraft {
  title?: string;
  description?: string;
  budget?: { min: number; max: number };
  deadline?: string;
  skills?: string[];
  category?: string;
  deliverables?: string[];
  isComplete: boolean; // Whether all required fields are filled
}

// 🆕 NEW: Payment information
interface PaymentInfo {
  taskTitle: string;
  amount: number;
  paymentMethod?: 'wechat' | 'alipay';
  status: 'pending' | 'processing' | 'completed' | 'failed';
}

interface ConversationState {
  lastQuery: string;
  availableContacts: UserRecommendation[];
  shownContacts: UserRecommendation[];
  currentIndex: number;
}

interface QuotedContact {
  id: string;
  name: string;
}

interface UserRecommendation {
  id: string;
  name: string;
  age?: string;
  gender?: string;
  avatar: string;
  location: string;
  hobbies?: string[];
  languages?: string[];
  skills: string[];
  resources?: string[];
  projects?: { 
    title: string; 
    role: string; 
    description: string; 
    referenceLinks: string[] 
  }[];
  goals?: string[];
  demands?: string[];
  institutions?: { 
    name: string; 
    role: string; 
    description: string; 
    verified: boolean;
  }[];
  university?: {
    name: string;
    verified: boolean;
  };
  // ❌ DEPRECATED: Being removed in pivot
  matchScore?: number;
  whyMatch?: string;
  bio: string;
  oneSentenceIntro?: string;
  whisperDefaultMessage?: string; // AI-generated message from user's perspective for whisper
  receivesLeft?: number;
}

interface ChatInterfaceProps {
  userProfile: UserProfile;
  onShowHistory: () => void;
  onShowNotifications: () => void;
  onRequestWhisper: (contact: UserRecommendation) => void;
  addedContactIds: Set<string>;
  unreadNotifications: number;
  quotedFromNotification: FriendRequest | null;
  onClearQuotedNotification: () => void;
  singleCardInChat?: any;
  onClearSingleCard?: () => void;
}

export interface ChatInterfaceRef {
  resetLastSwipe: () => void;
}

const MOCK_RECOMMENDATIONS: UserRecommendation[] = [
  {
    id: '1',
    name: 'Sarah Chen',
    age: '24',
    gender: 'Female',
    avatar: '👩‍💻',
    location: 'Beijing, China',
    hobbies: ['Rock Climbing', 'Photography', 'Cooking'],
    languages: ['English', 'Mandarin', 'Python'],
    skills: ['Python', 'Machine Learning', 'TensorFlow', 'Deep Learning', 'PyTorch'],
    resources: ['GPU Cluster Access', 'Research Lab', 'Datasets', 'ML Infrastructure'],
    projects: [
      {
        title: 'ML Ethics Framework',
        role: 'Lead Developer',
        description: 'Open-source framework for evaluating bias in ML models',
        referenceLinks: ['https://github.com/sarahchen/ml-ethics']
      },
      {
        title: 'Startup Accelerator',
        role: 'Technical Mentor',
        description: 'Mentoring 20+ AI startups on technical architecture',
        referenceLinks: []
      }
    ],
    goals: ['Build ethical AI products', 'Start a tech company', 'Publish research papers'],
    demands: ['Co-founder with business experience', 'Funding connections', 'Industry mentorship'],
    institutions: [
      {
        name: 'Tsinghua University',
        role: 'PhD Student - Computer Science',
        description: 'Research focus on ethical AI and machine learning safety',
        verified: true
      }
    ],
    university: {
      name: 'Tsinghua University',
      verified: true
    },
    matchScore: 95,
    bio: 'AI researcher passionate about ethical machine learning and startup innovation. PhD in Computer Science with 5 years of industry experience at Google AI.',
    oneSentenceIntro: 'I build AI systems that solve real-world problems while keeping humans at the center.',
    whyMatch: 'Perfect co-founder match! 🚀 You both have strong Python skills and share a passion for AI innovation. Sarah has the ML expertise to complement your technical background, and she\'s actively seeking a co-founder for her next venture.',
    whisperDefaultMessage: 'Hi Sarah! I noticed we both share a passion for ethical AI and have strong Python skills. I\'m really impressed by your ML Ethics Framework project. I believe my technical background could complement your ML expertise perfectly, and I\'d love to explore potential collaboration opportunities!',
  },
  {
    id: '2',
    name: 'Alex Kumar',
    age: '29',
    gender: 'Male',
    avatar: '👨‍💼',
    location: 'Shanghai, China',
    hobbies: ['Chess', 'Travel', 'Wine Tasting'],
    languages: ['English', 'Hindi', 'Mandarin'],
    skills: ['Product Management', 'Startup Scaling', 'Design Thinking', 'Growth Hacking', 'UX Strategy'],
    resources: ['VC Network', 'Mentor Network', 'Marketing Channels', 'International Connections'],
    projects: [
      {
        title: 'EdTech Platform',
        role: 'Co-founder & CEO',
        description: 'Built and scaled online learning platform to $10M ARR',
        referenceLinks: ['https://techcrunch.com/alex-kumar-edtech']
      },
      {
        title: 'SaaS Analytics Tool',
        role: 'Product Lead',
        description: 'Led product development for B2B analytics platform',
        referenceLinks: []
      }
    ],
    goals: ['Scale next startup to $100M', 'Expand to global markets', 'Build category-defining product'],
    demands: ['Technical co-founder', 'Engineering team', 'Series A funding'],
    institutions: [
      {
        name: 'Alibaba Group',
        role: 'Former Product Director',
        description: 'Led product strategy for cloud computing division',
        verified: true
      }
    ],
    university: {
      name: 'Shanghai Jiao Tong University',
      verified: true
    },
    matchScore: 88,
    bio: 'Serial entrepreneur with 3 successful exits, now mentoring and building. Former Product Director at Alibaba, expert in scaling 0-to-1 products.',
    oneSentenceIntro: 'I turn technical innovations into market-winning products that users love.',
    whyMatch: 'Excellent bidirectional match! 🤝 He brings the product management and startup scaling experience you need, while you offer the technical Python skills he\'s seeking for his next venture. Both actively looking for co-founders in the China market.',
    whisperDefaultMessage: 'Hi Alex! Your experience scaling EdTech to $10M ARR is incredibly inspiring. I have strong technical Python skills and I\'m looking for someone with your product and scaling expertise. I think we could build something amazing together in the China market!',
  },
  {
    id: '3',
    name: 'Maria Rodriguez',
    age: '26',
    gender: 'Female',
    avatar: '👩‍🔬',
    location: 'Guangzhou, China',
    hobbies: ['Hiking', 'Reading', 'Volunteer Work'],
    languages: ['Spanish', 'English', 'Portuguese'],
    skills: ['Data Science', 'Python', 'Research', 'Statistical Analysis', 'R', 'SQL'],
    resources: ['Research Database Access', 'Academic Network', 'Grant Writing', 'Publication Channels'],
    projects: [
      {
        title: 'Bias Detection Framework',
        role: 'Research Lead',
        description: 'Academic research on detecting and mitigating AI bias',
        referenceLinks: ['https://arxiv.org/abs/maria-bias-detection']
      },
      {
        title: 'Healthcare Analytics Platform',
        role: 'Data Scientist',
        description: 'ML models for predicting patient outcomes',
        referenceLinks: []
      }
    ],
    goals: ['Commercialize research', 'Impact healthcare with AI', 'Build diverse tech team'],
    demands: ['Business development partner', 'Healthcare industry connections', 'Regulatory expertise'],
    institutions: [
      {
        name: 'Sun Yat-sen University',
        role: 'Postdoc Researcher',
        description: 'Research in AI ethics and fairness in machine learning',
        verified: true
      }
    ],
    university: {
      name: 'Sun Yat-sen University',
      verified: true
    },
    matchScore: 82,
    bio: 'Data scientist passionate about AI ethics and open source contributions. Published researcher with 20+ papers in top-tier journals.',
    oneSentenceIntro: 'I use data science to solve real-world problems with ethical AI solutions.',
    whyMatch: 'Strong mutual interest! 🤝 Your AI ethics values align perfectly with her research focus, while your technical skills complement her data science background. She\'s looking for collaborators who share her values-driven approach to AI development.',
    whisperDefaultMessage: 'Hi Maria! I\'m deeply interested in AI ethics and your Bias Detection Framework research caught my attention. I share your values-driven approach to AI development and would love to discuss how we might collaborate on ethical AI solutions, especially in healthcare applications.',
  }
];

// 🔴 NEW: Mock tasks for freelancer mode - 高校线下任务场景
const MOCK_TASKS: any[] = [
  {
    id: 'task-design-1',
    title: '社团招新海报设计（2张）',
    description: '学生会需要设计2张招新海报，尺寸A3，要求简洁大气，突出社团特色。提供文字内容和参考图片，3天内完成即可。会提供之前的设计风格参考。',
    budget: { min: 150, max: 200 },
    deadline: new Date(Date.now() + 3 * 24 * 60 * 60 * 1000).toISOString(),
    skills: ['Photoshop', '平面设计', '海报设计'],
    category: '创意设计',
    status: 'published',
    deliverables: ['2张A3海报设计稿', '源文件PSD', '高清JPG导出'],
    attachments: [],
    applicationCount: 12,
    poster: {
      id: 'user-201',
      name: '李明',
      avatar: '👨‍💼',
      university: { name: '北京大学', verified: true },
      posterRating: 4.9,
      postedTasksCount: 8,
      onTimePaymentRate: 100
    },
    matchScore: 96,
    whyMatch: '你的Photoshop技能和海报设计经验完美匹配，发单者评价极高！'
  },
  {
    id: 'task-design-2',
    title: 'PPT模板美化（20页）',
    description: '毕业答辩PPT需要美化，已有文字内容，需要设计统一的视觉风格、配色和排版。要求简洁专业，突出重点内容。提供学校PPT模板规范。',
    budget: { min: 100, max: 150 },
    deadline: new Date(Date.now() + 5 * 24 * 60 * 60 * 1000).toISOString(),
    skills: ['PPT设计', '排版设计', '视觉设计'],
    category: '创意设计',
    status: 'published',
    deliverables: ['美化后的PPT文件', '可编辑的PPTX格式'],
    attachments: [],
    applicationCount: 15,
    poster: {
      id: 'user-202',
      name: '张婷',
      avatar: '👩',
      university: { name: '清华大学', verified: true },
      posterRating: 4.7,
      postedTasksCount: 5,
      onTimePaymentRate: 95
    },
    matchScore: 92,
    whyMatch: '你的PPT设计经验丰富，任务时间充足，非常适合！'
  },
  {
    id: 'task-design-3',
    title: '公众号封面图设计（5张）',
    description: '公众号运营需要设计5张封面图，尺寸900x383px。提供文章标题和关键词，需要设计吸引眼球的视觉效果。参考风格为扁平化设计。',
    budget: { min: 80, max: 120 },
    deadline: new Date(Date.now() + 4 * 24 * 60 * 60 * 1000).toISOString(),
    skills: ['Photoshop', '平面设计', '新媒体设计'],
    category: '创意设计',
    status: 'published',
    deliverables: ['5张封面图PNG格式', '符合公众号尺寸规范'],
    attachments: [],
    applicationCount: 20,
    poster: {
      id: 'user-203',
      name: '王浩',
      avatar: '👨',
      university: { name: '复旦大学', verified: true },
      posterRating: 4.8,
      postedTasksCount: 12,
      onTimePaymentRate: 100
    },
    matchScore: 90,
    whyMatch: '新媒体设计任务，你的扁平化设计风格很符合要求！'
  },
  {
    id: 'task-1',
    title: '帮忙早八课程签到（本周三次）',
    description: '微积分早八课，本周三、周五需要代签到两次。教室在理科楼A301，早上7:50前到即可。要求同校学生，可以提供学生证照片核实身份。',
    budget: { min: 30, max: 50 },
    deadline: new Date(Date.now() + 2 * 24 * 60 * 60 * 1000).toISOString(), // 2 days from now
    skills: ['同校学生', '早起', '守时'],
    category: '校园帮助',
    status: 'published',
    deliverables: ['现场签到照片', '课堂拍照确认', '微信实时汇报'],
    attachments: [],
    applicationCount: 8,
    poster: {
      id: 'user-101',
      name: '张小明',
      avatar: '👨‍💼',
      university: { name: '清华大学', verified: true },
      posterRating: 4.8,
      postedTasksCount: 12,
      onTimePaymentRate: 100
    },
    matchScore: 95,
    whyMatch: '你是清华在校生，距离理科楼近，早起签到任务完美匹配！'
  },
  {
    id: 'task-2',
    title: '毕业论文数据标注（500条）',
    description: '需要标注500条文本数据用于毕业论文实验，内容是情感分析（正面/负面/中性）。提供详细标注指南，每条约50字，预计3小时完成。要求认真负责，准确率高。',
    budget: { min: 80, max: 120 },
    deadline: new Date(Date.now() + 4 * 24 * 60 * 60 * 1000).toISOString(),
    skills: ['数据标注', '细心认真', '中文阅读理解'],
    category: '学术辅助',
    status: 'published',
    deliverables: ['Excel标注结果文件', '标注说明文档', '质量自查报告'],
    attachments: [],
    applicationCount: 6,
    poster: {
      id: 'user-102',
      name: '李华',
      avatar: '👩‍💻',
      university: { name: '北京大学', verified: true },
      posterRating: 4.9,
      postedTasksCount: 23,
      onTimePaymentRate: 95
    },
    matchScore: 92,
    whyMatch: '你的数据标注经验丰富，发单者评价很高，任务时间灵活！'
  },
  {
    id: 'task-3',
    title: '导师科研项目临时助理（3天）',
    description: '协助导师完成科研项目的文献整理和数据录入工作。需要在实验室现场工作，每天2-3小时，连续3天。要求：熟悉Office软件，有科研经历优先，理工科背景。',
    budget: { min: 200, max: 300 },
    deadline: new Date(Date.now() + 1 * 24 * 60 * 60 * 1000).toISOString(),
    skills: ['Office办公', '文献整理', '数据录入', '科研经历'],
    category: '学术辅助',
    status: 'published',
    deliverables: ['整理好的文献清单', '录入完成的数据表格', '工作日志'],
    attachments: [],
    applicationCount: 15,
    poster: {
      id: 'user-103',
      name: '王芳',
      avatar: '👩',
      university: { name: '复旦大学', verified: true },
      posterRating: 4.7,
      postedTasksCount: 8,
      onTimePaymentRate: 100
    },
    matchScore: 88,
    whyMatch: '你有科研经历且熟悉Office，导师项目助理经验加分！'
  },
  {
    id: 'task-4',
    title: '高数作业辅导（一对一）',
    description: '需要高数学霸帮忙讲解本周作业题（约15道题），主要是多元函数微积分。可以线下图书馆见面讲解，或线上视频辅导2小时。要求：高数成绩优秀，有耐心，讲解清晰。',
    budget: { min: 60, max: 100 },
    deadline: new Date(Date.now() + 3 * 24 * 60 * 60 * 1000).toISOString(),
    skills: ['高等数学', '一对一辅导', '讲解能力'],
    category: '课程辅导',
    status: 'published',
    deliverables: ['题目详细讲解', '解题思路总结', '答疑2小时'],
    attachments: [],
    applicationCount: 10,
    poster: {
      id: 'user-104',
      name: '赵敏',
      avatar: '👧',
      university: { name: '浙江大学', verified: true },
      posterRating: 5.0,
      postedTasksCount: 5,
      onTimePaymentRate: 100
    },
    matchScore: 90,
    whyMatch: '你高数成绩优秀且有辅导经验，一对一讲解任务非常合适！'
  },
  {
    id: 'task-5',
    title: '社团活动现场帮手（周六下午）',
    description: '社团举办校园音乐节，需要3名现场帮手协助布置场地、引导观众、维持秩序。时间：本周六下午2点到6点，地点：大礼堂广场。提供工作餐和社团纪念T恤。',
    budget: { min: 80, max: 100 },
    deadline: new Date(Date.now() + 5 * 24 * 60 * 60 * 1000).toISOString(),
    skills: ['活动组织', '沟通能力', '体力充沛'],
    category: '活动帮手',
    status: 'published',
    deliverables: ['现场服务4小时', '协助场地布置', '观众引导和秩序维护'],
    attachments: [],
    applicationCount: 20,
    poster: {
      id: 'user-105',
      name: '陈伟',
      avatar: '�',
      university: { name: '清华大学', verified: true },
      posterRating: 4.6,
      postedTasksCount: 15,
      onTimePaymentRate: 100
    },
    matchScore: 85,
    whyMatch: '你有活动组织经验，周六有空，还能领社团纪念T恤！'
  }
];

const AI_RESPONSES = [
  "I'll help you find the perfect connections! Can you tell me more about what kind of collaboration you're looking for?",
  "Great! Let me search for people who match your criteria. This might take a moment...",
  "Based on your profile and request, I found some excellent matches. Here are the top recommendations:",
  "Would you like me to refine these results or search for different criteria?"
];

export const ChatInterface = forwardRef<ChatInterfaceRef, ChatInterfaceProps>(({ 
  userProfile, 
  onShowHistory, 
  onShowNotifications, 
  onRequestWhisper, 
  addedContactIds, 
  unreadNotifications, 
  quotedFromNotification, 
  onClearQuotedNotification,
  singleCardInChat,
  onClearSingleCard
}, ref) => {
  const { t } = useLanguage();
  
  // 🔴 NEW: Role state for pivot
  const [currentRole, setCurrentRole] = useState<UserRole>('freelancer');
  
  // 🔴 NEW: File upload state
  const [uploadedFiles, setUploadedFiles] = useState<File[]>([]);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // 🆕 NEW: Task posting flow state machine
  const [taskPostingFlow, setTaskPostingFlow] = useState<{
    isActive: boolean;
    step: 'collecting-info' | 'confirm-task' | 'payment' | 'finding-freelancers' | 'completed';
    currentDraft: TaskDraft;
    fieldsCollected: Set<string>;
  }>({
    isActive: false,
    step: 'collecting-info',
    currentDraft: {
      isComplete: false
    },
    fieldsCollected: new Set()
  });
  
  const [messages, setMessages] = useState<Message[]>([]);
  const [inputValue, setInputValue] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [searchInside, setSearchInside] = useState(true);
  const chatCardsRef = useRef<ChatCardsRef>(null);
  const [showCardStack, setShowCardStack] = useState(false);
  const [currentRecommendations, setCurrentRecommendations] = useState<UserRecommendation[]>([]);
  const [showCards, setShowCards] = useState(false);
  const [cardsTriggerIndex, setCardsTriggerIndex] = useState<number | null>(null);
  const [messagesBottomMargin, setMessagesBottomMargin] = useState(0);
  const [isAnimatingUp, setIsAnimatingUp] = useState(false);
  const [isAnimatingDown, setIsAnimatingDown] = useState(false);
  const [scrollToCards, setScrollToCards] = useState(false);
  const [conversationState, setConversationState] = useState({
    lastQuery: '',
    availableContacts: [] as UserRecommendation[],
    shownContacts: [] as UserRecommendation[],
    currentIndex: 0
  });
  const [quotedContacts, setQuotedContacts] = useState<QuotedContact[]>([]);

  // Add state to track if waiting for single card setup
  const [pendingSingleCard, setPendingSingleCard] = useState<any>(null);

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const cardsRef = useRef<HTMLDivElement>(null);

  // 🔴 NEW: Get role-specific welcome message
  const getWelcomeMessage = (role: UserRole): string => {
    if (role === 'freelancer') {
      return `你好！我是你的接单助手 🤖

我可以帮你：
• 搜索适合你的任务
• 智能匹配高匹配度任务
• 管理订单和收益

试试说"找个设计的活儿"或"我想接PPT制作的单"`;
    } else {
      return `你好！我是你的任务助手 🤖

我可以帮你：
• 发布任务找人帮忙
• 完善任务需求
• 管理发布的任务

试试说"我想找人做海报"或"需要一个视频剪辑"`;
    }
  };

  // 🔴 NEW: Role change handler
  const handleRoleChange = (newRole: UserRole) => {
    setCurrentRole(newRole);
    
    // Clear current cards
    setShowCards(false);
    setCurrentRecommendations([]);
    setCardsTriggerIndex(null);
    setConversationState({
      lastQuery: '',
      availableContacts: [],
      shownContacts: [],
      currentIndex: 0
    });
    
    // Show toast notification
    toast.success(
      newRole === 'freelancer' 
        ? '✅ 已切换到接单模式，搜索任务吧！' 
        : '✅ 已切换到发单模式，搜索优质接单者',
      {
        duration: 2000,
      }
    );
  };

  // 🔴 NEW: File upload handlers
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []);
    
    // Validate file size (10MB limit)
    const validFiles = files.filter(file => {
      if (file.size > 10 * 1024 * 1024) {
        toast.error(`${file.name} 超过10MB限制`);
        return false;
      }
      return true;
    });
    
    if (validFiles.length > 0) {
      setUploadedFiles(prev => [...prev, ...validFiles]);
      toast.success(`已添加 ${validFiles.length} 个文件`, {
        icon: '📎',
        duration: 2000,
      });
    }
    
    // Reset input
    if (e.target) {
      e.target.value = '';
    }
  };

  const removeFile = (index: number) => {
    setUploadedFiles(prev => prev.filter((_, idx) => idx !== index));
  };

  // 🔴 NEW: Update welcome message when role changes (only if no messages yet)
  useEffect(() => {
    if (messages.length === 0) {
      // Only show welcome in console for now (can be displayed if needed)
      console.log('Welcome message:', getWelcomeMessage(currentRole));
    }
  }, [currentRole]);

  // 暴露重置方法给父组件
  useImperativeHandle(ref, () => ({
    resetLastSwipe: () => {
      console.log('🔄 ChatInterface: Calling resetLastSwipe on ChatCards');
      chatCardsRef.current?.resetLastSwipe();
    }
  }), []);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  const scrollToCardsPosition = () => {
    if (cardsRef.current) {
      const cardsElement = cardsRef.current;
      const container = cardsElement.closest('.overflow-y-auto');
      if (container) {
        const containerRect = container.getBoundingClientRect();
        const cardsRect = cardsElement.getBoundingClientRect();
        const targetScroll = container.scrollTop + (cardsRect.top - containerRect.top) - (containerRect.height / 2) + (cardsRect.height / 2);
        
        container.scrollTo({
          top: targetScroll,
          behavior: 'smooth'
        });
      }
    }
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  useEffect(() => {
    if (scrollToCards) {
      scrollToCardsPosition();
      setScrollToCards(false);
    }
  }, [scrollToCards]);

  // Handle quoted contact from notifications
  useEffect(() => {
    if (quotedFromNotification) {
      const newQuote: QuotedContact = {
        id: quotedFromNotification.id,
        name: quotedFromNotification.name
      };
      
      // Add to quoted contacts if not already quoted
      if (!quotedContacts.find(q => q.id === quotedFromNotification.id)) {
        setQuotedContacts(prev => [...prev, newQuote]);
      }
      
      // Clear the notification quote
      onClearQuotedNotification();
    }
  }, [quotedFromNotification, quotedContacts, onClearQuotedNotification]);

  // Handle single card in chat - force setup
  useEffect(() => {
    if (singleCardInChat) {
      // Clear any existing cards first
      setShowCards(false);
      setCurrentRecommendations([]);
      setCardsTriggerIndex(null);
      setPendingSingleCard(null);
      
      // Small delay to ensure state is cleared
      setTimeout(() => {
        const aiMessage: Message = {
          id: Date.now().toString(),
          type: 'ai',
          content: "Here's the original profile card you requested to review:",
          timestamp: new Date(),
        };
        
        setMessages(prev => [...prev, aiMessage]);
        setPendingSingleCard(singleCardInChat);
      }, 100);
    }
  }, [singleCardInChat]);

  // Set up single card after messages update
  useEffect(() => {
    if (pendingSingleCard && messages.length > 0) {
      const newIndex = messages.length - 1;
      
      setCurrentRecommendations([pendingSingleCard]);
      setShowCards(true);
      setCardsTriggerIndex(newIndex);
      setPendingSingleCard(null);
      
      // Trigger scroll to center
      setTimeout(() => {
        setScrollToCards(true);
      }, 300);
    }
  }, [messages, pendingSingleCard]);

  const generateMutualMatchExplanation = (recommendation: UserRecommendation, userQuery: string) => {
    const userSkills = userProfile.skills.join(', ') || 'technical skills';
    const userLocation = userProfile.location || 'your location';
    // Removed: userGoals (no longer in UserProfile)
    
    // Create personalized mutual matching explanations
    if (userQuery.toLowerCase().includes('co-founder')) {
      return `Perfect mutual match! ✨ You offer the ${userSkills} they need for their next venture, while they bring ${recommendation.skills.slice(0, 2).join(' and ')} expertise you're seeking. Both actively looking for co-founders with complementary skills.`;
    } else if (userQuery.toLowerCase().includes('mentor')) {
      return `Excellent mentoring match! 🎯 They're looking to mentor someone with your ${userSkills} background, while you gain from their ${recommendation.skills[0]} expertise.`;
    } else if (userQuery.toLowerCase().includes('investor')) {
      return `Strong investor-founder fit! 💰 Your ${userSkills} expertise matches their investment thesis, while their portfolio in ${recommendation.projects?.[0]?.title || 'relevant sectors'} aligns with your sector. Mutual interest in ${userLocation} market.`;
    } else {
      return `Great bidirectional match! 🤝 You complement each other's skills (your ${userSkills} + their ${recommendation.skills[0]}), share similar goals, and they're also looking for someone with your background in ${userLocation}.`;
    }
  };

  // 🆕 NEW: Extract task information from user message
  const extractTaskInfoFromMessage = (message: string): Partial<TaskDraft> => {
    const result: Partial<TaskDraft> = {};
    const lowerMsg = message.toLowerCase();
    
    // Extract title (simple heuristics)
    if (lowerMsg.includes('找人') || lowerMsg.includes('需要') || lowerMsg.includes('帮忙')) {
      const titleMatch = message.match(/(找人|需要|帮忙)(.{2,20})/);
      if (titleMatch) {
        result.title = titleMatch[2].trim();
      }
    }
    
    // 🔧 FIX: Don't automatically set description - let the calling code handle it
    // Only set description if it's a proper sentence (not just budget/deadline)
    // This will be handled by the smart field detection in the calling code
    
    // Extract budget (find numbers)
    const budgetMatch = message.match(/(\d+)[-~到至](\d+)|(\d+)元|(\d+)块/);
    if (budgetMatch) {
      if (budgetMatch[1] && budgetMatch[2]) {
        result.budget = { min: parseInt(budgetMatch[1]), max: parseInt(budgetMatch[2]) };
      } else {
        const amount = parseInt(budgetMatch[3] || budgetMatch[4]);
        result.budget = { min: Math.floor(amount * 0.8), max: amount };
      }
    }
    
    // Extract deadline
    const deadlinePatterns = [
      { pattern: /(\d+)天/, days: 1 },
      { pattern: /本周|这周/, days: 7 },
      { pattern: /下周/, days: 14 },
      { pattern: /(\d+)号/, days: 3 }
    ];
    for (const { pattern, days } of deadlinePatterns) {
      if (pattern.test(lowerMsg)) {
        const match = lowerMsg.match(pattern);
        let daysToAdd = days;
        if (match && match[1]) {
          daysToAdd = parseInt(match[1]);
        }
        result.deadline = new Date(Date.now() + daysToAdd * 24 * 60 * 60 * 1000).toISOString();
        break;
      }
    }
    
    // Extract skills (keyword matching)
    const skillKeywords = [
      { keywords: ['设计', 'ps', 'photoshop', '海报', '平面'], skill: '平面设计' },
      { keywords: ['视频', '剪辑', 'pr', '后期'], skill: '视频剪辑' },
      { keywords: ['代码', '编程', 'python', 'java', '开发'], skill: '编程开发' },
      { keywords: ['翻译', '英文', '英语'], skill: '翻译' },
      { keywords: ['文案', '写作'], skill: '文案写作' },
      { keywords: ['数据', '标注', '整理'], skill: '数据处理' },
      { keywords: ['签到', '代课'], skill: '校园跑腿' }
    ];
    
    const matchedSkills = [];
    for (const { keywords, skill } of skillKeywords) {
      if (keywords.some(kw => lowerMsg.includes(kw))) {
        matchedSkills.push(skill);
      }
    }
    if (matchedSkills.length > 0) {
      result.skills = matchedSkills;
      result.category = matchedSkills[0].includes('设计') || matchedSkills[0].includes('视频') 
        ? '创意设计' 
        : matchedSkills[0].includes('编程') 
        ? '技术开发' 
        : '校园帮助';
    }
    
    return result;
  };

  const simulateAIResponse = async (userMessage: string) => {
    setIsTyping(true);
    
    // Simulate thinking time
    await new Promise(resolve => setTimeout(resolve, 1500));
    
    let aiResponse = AI_RESPONSES[Math.floor(Math.random() * AI_RESPONSES.length)];
    let recommendations: UserRecommendation[] = [];
    let triggerIndex: number | null = null;

    const userMessageLower = userMessage.toLowerCase();

    // 🔴 NEW: Different logic based on role
    if (currentRole === 'freelancer') {
      // Freelancer mode - show tasks
      if (userMessageLower.includes('设计') || userMessageLower.includes('ps') || 
          userMessageLower.includes('海报') || userMessageLower.includes('平面')) {
        // Filter tasks that match design skills
        recommendations = MOCK_TASKS
          .filter((task: any) => task.skills.some((s: string) => 
            s.includes('设计') || s.includes('Photoshop')
          ))
          .map((task: any) => ({
            id: task.id,
            name: task.title,
            avatar: task.poster.avatar,
            location: '',
            bio: task.description,
            skills: task.skills,
            matchScore: task.matchScore,
            whyMatch: task.whyMatch,
            // Add task-specific fields
            _isTask: true,
            _taskData: task
          } as any));
        
        if (recommendations.length > 0) {
          aiResponse = "找到了一些适合你的设计任务！让我为你展示...";
          triggerIndex = messages.length;
        }
      } else if (userMessageLower.includes('python') || userMessageLower.includes('编程') ||
                 userMessageLower.includes('数据') || userMessageLower.includes('代码')) {
        recommendations = MOCK_TASKS
          .filter((task: any) => task.skills.some((s: string) => 
            s.includes('Python') || s.includes('编程') || s.includes('数据')
          ))
          .map((task: any) => ({
            id: task.id,
            name: task.title,
            avatar: task.poster.avatar,
            location: '',
            bio: task.description,
            skills: task.skills,
            matchScore: task.matchScore,
            whyMatch: task.whyMatch,
            _isTask: true,
            _taskData: task
          } as any));
        
        if (recommendations.length > 0) {
          aiResponse = "找到了一些编程相关的任务！让我为你展示...";
          triggerIndex = messages.length;
        }
      } else if (userMessageLower.includes('视频') || userMessageLower.includes('剪辑')) {
        recommendations = MOCK_TASKS
          .filter((task: any) => task.skills.some((s: string) => 
            s.includes('视频') || s.includes('剪辑')
          ))
          .map((task: any) => ({
            id: task.id,
            name: task.title,
            avatar: task.poster.avatar,
            location: '',
            bio: task.description,
            skills: task.skills,
            matchScore: task.matchScore,
            whyMatch: task.whyMatch,
            _isTask: true,
            _taskData: task
          } as any));
        
        if (recommendations.length > 0) {
          aiResponse = "找到了一些视频剪辑任务！让我为你展示...";
          triggerIndex = messages.length;
        }
      } else {
        // Show all tasks if no specific skill mentioned
        recommendations = MOCK_TASKS.map((task: any) => ({
          id: task.id,
          name: task.title,
          avatar: task.poster.avatar,
          location: '',
          bio: task.description,
          skills: task.skills,
          matchScore: task.matchScore,
          whyMatch: task.whyMatch,
          _isTask: true,
          _taskData: task
        } as any));
        
        if (recommendations.length > 0) {
          aiResponse = "找到了一些适合你的任务！让我为你展示...";
          triggerIndex = messages.length;
        }
      }
    } else {
      // 🆕 Poster mode - AI-guided task posting flow
      const { isActive, step, currentDraft, fieldsCollected } = taskPostingFlow;
      
      // 🆕 Check if user wants to post a task (trigger words)
      const taskPostingTriggers = ['找人', '需要', '帮忙', '做个', '制作', '设计', '视频', '海报', 
                                     '代课', '签到', '数据', '标注', '翻译', '文案', '代写'];
      const isTaskPostingRequest = taskPostingTriggers.some(trigger => userMessageLower.includes(trigger));
      
      if (isTaskPostingRequest && !isActive) {
        // 🆕 START: Begin task posting flow
        aiResponse = "好的！我来帮你发布这个任务 📝\n\n";
        
        // Save initial message as description
        let updatedDraft = {
          ...currentDraft,
          title: userMessage.substring(0, 30),
          description: userMessage,
        };
        let newFieldsCollected = new Set<string>(['description']);
        
        aiResponse += `我已经理解了你的需求。\n\n请告诉我：任务的预算范围是多少？（例如：100-200元）`;
        
        setTaskPostingFlow({
          isActive: true,
          step: 'collecting-info',
          currentDraft: updatedDraft,
          fieldsCollected: newFieldsCollected
        });
        
      } else if (isActive && step === 'collecting-info') {
        // 🆕 COLLECTING: Continue collecting task information - simple sequential flow
        let extracted = extractTaskInfoFromMessage(userMessage);
        let updatedDraft = { ...currentDraft, ...extracted };
        let newFieldsCollected = new Set<string>(fieldsCollected);
        
        // Simple sequential collection
        if (!newFieldsCollected.has('budget')) {
          // Collecting budget
          if (extracted.budget) {
            newFieldsCollected.add('budget');
            aiResponse = `好的，预算已记录 ✓\n\n请告诉我：任务的截止时间是什么时候？（例如：3天内、本周、下周一）`;
          } else {
            // Try to parse from message
            const budgetMatch = userMessage.match(/(\d+)/);
            if (budgetMatch) {
              const amount = parseInt(budgetMatch[1]);
              updatedDraft.budget = { min: Math.floor(amount * 0.8), max: amount };
              newFieldsCollected.add('budget');
              aiResponse = `好的，预算已记录 ✓\n\n请告诉我：任务的截止时间是什么时候？（例如：3天内、本周、下周一）`;
            } else {
              aiResponse = `请提供预算金额，例如："100元"或"100-200元"`;
            }
          }
        } else if (!newFieldsCollected.has('deadline')) {
          // Collecting deadline
          if (extracted.deadline) {
            newFieldsCollected.add('deadline');
            aiResponse = `好的，截止时间已记录 ✓\n\n最后，这个任务需要什么技能？（例如：设计、编程、视频剪辑等）`;
          } else {
            // Default to 7 days
            updatedDraft.deadline = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString();
            newFieldsCollected.add('deadline');
            aiResponse = `好的，截止时间已记录 ✓\n\n最后，这个任务需要什么技能？（例如：设计、编程、视频剪辑等）`;
          }
        } else if (!newFieldsCollected.has('skills')) {
          // Collecting skills
          if (extracted.skills && extracted.skills.length > 0) {
            newFieldsCollected.add('skills');
          } else {
            // Use user message as skill
            updatedDraft.skills = [userMessage];
            updatedDraft.category = '其他';
            newFieldsCollected.add('skills');
          }
          
          // All fields collected!
          updatedDraft.isComplete = true;
          setTaskPostingFlow({
            isActive: true,
            step: 'confirm-task',
            currentDraft: updatedDraft,
            fieldsCollected: newFieldsCollected
          });
          
          aiResponse = "太好了！任务信息已经完整 ✅\n\n让我为你生成任务预览，请查看并确认...";
          
          // Create task preview message
          setTimeout(() => {
            const taskPreviewMessage: Message = {
              id: (Date.now() + 1).toString(),
              type: 'ai',
              content: '',
              timestamp: new Date(),
              specialType: 'task-preview',
              taskData: updatedDraft
            };
            setMessages(prev => [...prev, taskPreviewMessage]);
            
            // Ask for confirmation
            setTimeout(() => {
              const confirmMessage: Message = {
                id: (Date.now() + 2).toString(),
                type: 'ai',
                content: "请查看上面的任务卡片，如果信息正确，回复「确认发布」；如果需要修改，告诉我需要改哪里~",
                timestamp: new Date()
              };
              setMessages(prev => [...prev, confirmMessage]);
            }, 500);
          }, 1000);
        }
        
        setTaskPostingFlow({
          isActive: true,
          step: 'collecting-info',
          currentDraft: updatedDraft,
          fieldsCollected: newFieldsCollected
        });
        
      } else if (isActive && step === 'confirm-task') {
        // 🆕 CONFIRM: User confirms or edits task
        if (userMessageLower.includes('确认') || userMessageLower.includes('发布') || 
            userMessageLower.includes('可以') || userMessageLower.includes('没问题')) {
          // Move to payment step
          setTaskPostingFlow({
            ...taskPostingFlow,
            step: 'payment'
          });
          
          aiResponse = "太好了！任务信息已确认 ✅\n\n接下来需要支付任务预算以托管资金...";
          
          // Create payment message
          setTimeout(() => {
            const paymentMessage: Message = {
              id: (Date.now() + 1).toString(),
              type: 'ai',
              content: '',
              timestamp: new Date(),
              specialType: 'task-payment',
              paymentData: {
                taskTitle: currentDraft.title || '任务',
                amount: currentDraft.budget?.max || 0,
                status: 'pending'
              }
            };
            setMessages(prev => [...prev, paymentMessage]);
          }, 1000);
          
        } else {
          // User wants to edit - extract what to change
          aiResponse = "好的，我来帮你修改。请告诉我具体要改哪个部分？";
        }
        
      } else if (isActive && step === 'payment') {
        // 🆕 PAYMENT: Handle payment confirmation (mock)
        if (userMessageLower.includes('支付') || userMessageLower.includes('付款') || 
            userMessageLower.includes('确认')) {
          // Simulate payment success
          setTaskPostingFlow({
            ...taskPostingFlow,
            step: 'finding-freelancers'
          });
          
          aiResponse = "支付成功！✅ 资金已托管到平台\n\n正在为你匹配最合适的接单者...";
          
          // Show freelancer recommendations
          setTimeout(() => {
            const matchedFreelancers = MOCK_RECOMMENDATIONS.slice(0, 3);
            const freelancerMessage: Message = {
              id: (Date.now() + 1).toString(),
              type: 'ai',
              content: `找到了 ${matchedFreelancers.length} 位高匹配度的接单者！让我为你展示...`,
              timestamp: new Date()
            };
            setMessages(prev => [...prev, freelancerMessage]);
            
            // Trigger freelancer cards
            triggerIndex = messages.length + 1;
            recommendations = matchedFreelancers.map(freelancer => ({
              ...freelancer,
              whyMatch: `完成率${Math.floor(Math.random() * 10 + 90)}%，擅长${currentDraft.skills?.[0] || '相关技能'}，平均响应时间2小时`
            }));
            
            setTimeout(() => {
              setConversationState({
                lastQuery: userMessage,
                availableContacts: recommendations,
                shownContacts: recommendations,
                currentIndex: 0
              });
              setCurrentRecommendations(recommendations);
              setShowCards(true);
              setCardsTriggerIndex(triggerIndex);
              setTimeout(() => setScrollToCards(true), 100);
              
              // Mark flow as completed
              setTaskPostingFlow({
                isActive: false,
                step: 'completed',
                currentDraft: { isComplete: false },
                fieldsCollected: new Set()
              });
            }, 1500);
          }, 1500);
        }
        
      } else {
        // Fallback: original freelancer search logic
        if (userMessageLower.includes('co-founder') || 
            userMessageLower.includes('startup') ||
            userMessageLower.includes('python') ||
            userMessageLower.includes('ai')) {
          recommendations = MOCK_RECOMMENDATIONS
            .filter(rec => !addedContactIds.has(rec.id))
            .map(rec => ({
              ...rec,
              whyMatch: generateMutualMatchExplanation(rec, userMessage)
            }));
          
          if (recommendations.length > 0) {
            aiResponse = "I found some excellent matches for you! Let me show them in an interactive format...";
            triggerIndex = messages.length;
          } else {
            aiResponse = "I've already shown you all the best matches for this type of search. Would you like to try a different query?";
          }
        }
      }
    }

    setIsTyping(false);
    
    const newMessage: Message = {
      id: Date.now().toString(),
      type: 'ai',
      content: aiResponse,
      timestamp: new Date(),
    };

    setMessages(prev => [...prev, newMessage]);

    if (triggerIndex !== null && recommendations.length > 0) {
      setConversationState({
        lastQuery: userMessage,
        availableContacts: recommendations,
        shownContacts: recommendations,
        currentIndex: 0
      });

      setTimeout(() => {
        // Show cards directly below last message
        setCurrentRecommendations(recommendations);
        setShowCards(true);
        setCardsTriggerIndex(triggerIndex);
        
        // Trigger scroll animation to center cards
        setTimeout(() => {
          setScrollToCards(true);
        }, 100);
      }, 1000);
    }
  };

  const handleSendMessage = async () => {
    if (!inputValue.trim() && quotedContacts.length === 0) return;

    // Build the message content with quoted contacts context
    let messageContent = inputValue;
    if (quotedContacts.length > 0) {
      const quotedNames = quotedContacts.map(q => q.name).join(', ');
      messageContent = quotedContacts.length === 1 
        ? `About ${quotedNames}: ${inputValue}`
        : `About ${quotedNames}: ${inputValue}`;
    }

    const userMessage: Message = {
      id: Date.now().toString(),
      type: 'user',
      content: messageContent,
      timestamp: new Date(),
    };

    setMessages(prev => [...prev, userMessage]);
    const messageToProcess = messageContent;
    setInputValue('');
    setQuotedContacts([]);

    await simulateAIResponse(messageToProcess);
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  const removeQuotedContact = (contactId: string) => {
    setQuotedContacts(prev => prev.filter(q => q.id !== contactId));
  };

  const formatTime = (date: Date) => {
    return date.toLocaleTimeString('en-US', { 
      hour: '2-digit', 
      minute: '2-digit',
      hour12: false 
    });
  };

  // Handle card stack actions - 🔴 UPDATED: Direct application for tasks
  const handleCardWhisper = async (contact: UserRecommendation) => {
    console.log('💬 ChatInterface handleCardWhisper:', contact.name);
    
    // 🔴 NEW: Check if this is a task (freelancer mode) or freelancer (poster mode)
    if (currentRole === 'freelancer' && (contact as any)._isTask) {
      // Freelancer swiping right on a task → Direct application
      console.log('📝 Applying for task:', contact.name);
      
      // Show success toast
      setTimeout(() => {
        toast.success('申请已提交！等待发单者回复', {
          duration: 3000,
        });
      }, 200);
      
      // TODO: Call API to submit application
      // await applyForTask({
      //   taskId: contact.id,
      //   message: generateApplicationMessage(userProfile, contact),
      //   quotedPrice: contact._taskData.budget.max,
      //   estimatedDays: estimateDays(contact._taskData)
      // });
      
    } else if (currentRole === 'poster') {
      // Poster swiping right on freelancer → Send invitation
      console.log('💌 Inviting freelancer:', contact.name);
      
      setTimeout(() => {
        toast.success('邀请已发送！', {
          duration: 2000,
        });
      }, 200);
      
      // TODO: Call API to send invitation
      
    } else {
      // Fallback to original whisper behavior (backward compatibility)
      setTimeout(() => {
        onRequestWhisper(contact);
      }, 200);
    }
  };

  const handleCardIgnore = (contact: UserRecommendation) => {
    // Just ignore, no action needed
  };

  const handleCardStackClose = () => {
    setShowCards(false);
    setCurrentRecommendations([]);
    setCardsTriggerIndex(null);
    if (onClearSingleCard) {
      onClearSingleCard();
    }
  };

  const beforeCards = cardsTriggerIndex !== null ? messages.slice(0, cardsTriggerIndex + 1) : messages;
  const afterCards = cardsTriggerIndex !== null ? messages.slice(cardsTriggerIndex + 1) : [];

  return (
    <div className="h-full flex flex-col bg-white">
      {/* Header - only show when there are messages */}
      {messages.length > 0 && (
        <div className="flex items-center justify-between p-4 border-b border-gray-200 bg-white">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-full flex items-center justify-center overflow-hidden">
              <img 
                src={logoIcon} 
                alt="Ques AI" 
                className="w-full h-full object-cover"
              />
            </div>
            <div>
              <h2 className="font-medium">{t('chat.appName')}</h2>
              <p className="text-xs text-gray-500">{t('chat.headerSubtitle')}</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button 
              onClick={() => setSearchInside(!searchInside)}
              className="flex items-center justify-center w-8 h-8 rounded-full border border-blue-200 bg-blue-50 text-blue-700 hover:bg-blue-100 transition-colors"
            >
              {searchInside ? (
                <School size={14} />
              ) : (
                <Globe size={14} />
              )}
            </button>
            <button 
              onClick={onShowNotifications} 
              className="p-1 hover:bg-gray-100 rounded relative"
            >
              <Bell size={20} className="text-gray-500" />
              {unreadNotifications > 0 && (
                <span className="absolute -top-1 -right-1 bg-red-500 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center">
                  {unreadNotifications > 9 ? '9+' : unreadNotifications}
                </span>
              )}
            </button>
            <button onClick={onShowHistory} className="p-1 hover:bg-gray-100 rounded">
              <History size={20} className="text-gray-500" />
            </button>
          </div>
        </div>
      )}




      {/* Initial State - centered icon (only when no messages) */}
      {messages.length === 0 && (
        <>
          {/* Header for initial state */}
          <div className="flex items-center justify-end p-4">
            <div className="flex items-center gap-2">
              <button 
                onClick={() => setSearchInside(!searchInside)}
                className="flex items-center justify-center w-8 h-8 rounded-full border border-blue-200 bg-blue-50 text-blue-700 hover:bg-blue-100 transition-colors"
              >
                {searchInside ? (
                  <School size={14} />
                ) : (
                  <Globe size={14} />
                )}
              </button>
              <button 
                onClick={onShowNotifications} 
                className="p-1 hover:bg-gray-100 rounded relative"
              >
                <Bell size={20} className="text-gray-500" />
                {unreadNotifications > 0 && (
                  <span className="absolute -top-1 -right-1 bg-red-500 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center">
                    {unreadNotifications > 9 ? '9+' : unreadNotifications}
                  </span>
                )}
              </button>
              <button onClick={onShowHistory} className="p-1 hover:bg-gray-100 rounded">
                <History size={20} className="text-gray-500" />
              </button>
            </div>
          </div>
          
          <div className="flex-1 flex flex-col items-center justify-center px-6">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
              className="text-center"
            >
              <div className="w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-6 shadow-lg overflow-hidden">
                <img 
                  src={logoIcon} 
                  alt="Ques AI Logo" 
                  className="w-full h-full object-cover"
                />
              </div>
              <h1 className="text-2xl mb-2 text-gray-800">{t('chat.appName')}</h1>
              <p className="text-gray-500 mb-4 whitespace-pre-line">{getWelcomeMessage(currentRole)}</p>
            </motion.div>
          </div>
        </>
      )}

      {/* Messages and Cards - show when there are messages or cards */}
      {(messages.length > 0 || showCards) && (
        <div className="flex-1 overflow-y-auto px-4 py-4">
          <div className="space-y-6">
            {/* Before Cards Messages */}
            <div className="w-full space-y-4">
              <AnimatePresence>
                {beforeCards.map((message) => (
                  <motion.div
                    key={message.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.3 }}
                    layout
                    className="mb-4"
                  >
                    {message.type === 'user' ? (
                      <div className="flex justify-end mb-3">
                        <div className="bg-blue-500 text-white rounded-2xl rounded-tr-md px-4 py-2 max-w-xs">
                          <p>{message.content}</p>
                          <p className="text-xs opacity-75 mt-1">{formatTime(message.timestamp)}</p>
                        </div>
                      </div>
                    ) : message.specialType === 'task-preview' && message.taskData ? (
                      // 🆕 Task Preview Card
                      <div className="flex justify-center mb-3">
                        <motion.div
                          initial={{ scale: 0.9, opacity: 0 }}
                          animate={{ scale: 1, opacity: 1 }}
                          className="bg-white border-2 border-blue-500 rounded-2xl p-5 max-w-md w-full shadow-lg"
                        >
                          <div className="flex items-center justify-between mb-3">
                            <h3 className="text-lg font-bold text-gray-800">📋 任务预览</h3>
                            <Badge variant="outline" className="bg-blue-50 text-blue-700">待确认</Badge>
                          </div>
                          
                          <div className="space-y-3">
                            {message.taskData.title && (
                              <div>
                                <p className="text-xs text-gray-500 mb-1">任务标题</p>
                                <p className="font-semibold text-gray-800">{message.taskData.title}</p>
                              </div>
                            )}
                            
                            {message.taskData.description && (
                              <div>
                                <p className="text-xs text-gray-500 mb-1">详细描述</p>
                                <p className="text-sm text-gray-700">{message.taskData.description}</p>
                              </div>
                            )}
                            
                            <div className="grid grid-cols-2 gap-3">
                              {message.taskData.budget && (
                                <div>
                                  <p className="text-xs text-gray-500 mb-1">预算范围</p>
                                  <p className="font-semibold text-green-600">
                                    ¥{message.taskData.budget.min}-{message.taskData.budget.max}
                                  </p>
                                </div>
                              )}
                              
                              {message.taskData.deadline && (
                                <div>
                                  <p className="text-xs text-gray-500 mb-1">截止时间</p>
                                  <p className="text-sm text-gray-700">
                                    {new Date(message.taskData.deadline).toLocaleDateString('zh-CN')}
                                  </p>
                                </div>
                              )}
                            </div>
                            
                            {message.taskData.skills && message.taskData.skills.length > 0 && (
                              <div>
                                <p className="text-xs text-gray-500 mb-1">所需技能</p>
                                <div className="flex flex-wrap gap-1">
                                  {message.taskData.skills.map((skill, idx) => (
                                    <Badge key={idx} variant="secondary" className="text-xs">
                                      {skill}
                                    </Badge>
                                  ))}
                                </div>
                              </div>
                            )}
                          </div>
                          
                          <div className="mt-4 pt-4 border-t border-gray-200 flex gap-2">
                            <Button 
                              variant="outline" 
                              size="sm" 
                              className="flex-1"
                              onClick={() => {
                                toast.info('编辑功能开发中...');
                              }}
                            >
                              修改
                            </Button>
                            <Button 
                              size="sm" 
                              className="flex-1 bg-blue-500 hover:bg-blue-600"
                              onClick={() => {
                                // Directly trigger payment flow
                                setTaskPostingFlow({
                                  ...taskPostingFlow,
                                  step: 'payment'
                                });
                                
                                // Show AI message
                                const aiMsg: Message = {
                                  id: Date.now().toString(),
                                  type: 'ai',
                                  content: "太好了！任务信息已确认 ✅\n\n接下来需要支付任务预算以托管资金...",
                                  timestamp: new Date()
                                };
                                setMessages(prev => [...prev, aiMsg]);
                                
                                // Show payment modal after delay
                                setTimeout(() => {
                                  const paymentMsg: Message = {
                                    id: (Date.now() + 1).toString(),
                                    type: 'ai',
                                    content: '',
                                    timestamp: new Date(),
                                    specialType: 'task-payment',
                                    paymentData: {
                                      taskTitle: message.taskData?.title || '任务',
                                      amount: message.taskData?.budget?.max || 0,
                                      status: 'pending'
                                    }
                                  };
                                  setMessages(prev => [...prev, paymentMsg]);
                                }, 1000);
                              }}
                            >
                              确认发布
                            </Button>
                          </div>
                        </motion.div>
                      </div>
                    ) : message.specialType === 'task-payment' && message.paymentData ? (
                      // 🆕 Payment Interface
                      <div className="flex justify-center mb-3">
                        <motion.div
                          initial={{ scale: 0.9, opacity: 0 }}
                          animate={{ scale: 1, opacity: 1 }}
                          className="bg-gradient-to-br from-green-50 to-blue-50 border-2 border-green-500 rounded-2xl p-5 max-w-md w-full shadow-lg"
                        >
                          <div className="text-center mb-4">
                            <h3 className="text-xl font-bold text-gray-800 mb-2">💳 支付任务预算</h3>
                            <p className="text-sm text-gray-600">资金将被平台托管，任务完成后释放</p>
                          </div>
                          
                          <div className="bg-white rounded-xl p-4 mb-4">
                            <div className="flex justify-between items-center mb-3">
                              <span className="text-gray-600">任务</span>
                              <span className="font-semibold">{message.paymentData.taskTitle}</span>
                            </div>
                            <div className="flex justify-between items-center">
                              <span className="text-gray-600">托管金额</span>
                              <span className="text-2xl font-bold text-green-600">¥{message.paymentData.amount}</span>
                            </div>
                          </div>
                          
                          <div className="space-y-2 mb-4">
                            <p className="text-xs text-gray-500 mb-2">选择支付方式</p>
                            <Button 
                              variant="outline" 
                              className="w-full justify-start gap-3 h-12 border-2 hover:border-green-500 hover:bg-green-50"
                              onClick={() => {
                                toast.success('支付成功！✅', { duration: 2000 });
                                
                                // Update flow state
                                setTaskPostingFlow({
                                  ...taskPostingFlow,
                                  step: 'finding-freelancers'
                                });
                                
                                // Show success message
                                setTimeout(() => {
                                  const successMsg: Message = {
                                    id: (Date.now() + 1).toString(),
                                    type: 'ai',
                                    content: "支付成功！✅ 资金已托管到平台\n\n正在为你匹配最合适的接单者...",
                                    timestamp: new Date()
                                  };
                                  setMessages(prev => [...prev, successMsg]);
                                  
                                  // Show freelancer recommendations
                                  setTimeout(() => {
                                    const matchedFreelancers = MOCK_RECOMMENDATIONS.slice(0, 3);
                                    const freelancerMsg: Message = {
                                      id: (Date.now() + 2).toString(),
                                      type: 'ai',
                                      content: `找到了 ${matchedFreelancers.length} 位高匹配度的接单者！让我为你展示...`,
                                      timestamp: new Date()
                                    };
                                    setMessages(prev => [...prev, freelancerMsg]);
                                    
                                    // Trigger freelancer cards
                                    const triggerIdx = messages.length + 2;
                                    const recommendations = matchedFreelancers.map(freelancer => ({
                                      ...freelancer,
                                      whyMatch: `完成率${Math.floor(Math.random() * 10 + 90)}%，擅长相关技能，平均响应时间2小时`
                                    }));
                                    
                                    setTimeout(() => {
                                      setConversationState({
                                        lastQuery: '推荐接单者',
                                        availableContacts: recommendations,
                                        shownContacts: recommendations,
                                        currentIndex: 0
                                      });
                                      setCurrentRecommendations(recommendations);
                                      setShowCards(true);
                                      setCardsTriggerIndex(triggerIdx);
                                      setTimeout(() => setScrollToCards(true), 100);
                                      
                                      // Mark flow as completed
                                      setTaskPostingFlow({
                                        isActive: false,
                                        step: 'completed',
                                        currentDraft: { isComplete: false },
                                        fieldsCollected: new Set()
                                      });
                                    }, 1500);
                                  }, 1500);
                                }, 500);
                              }}
                            >
                              <span className="text-2xl">💚</span>
                              <span className="font-semibold">微信支付</span>
                            </Button>
                            <Button 
                              variant="outline" 
                              className="w-full justify-start gap-3 h-12 border-2 hover:border-blue-500 hover:bg-blue-50"
                              onClick={() => {
                                toast.success('支付成功！✅', { duration: 2000 });
                                
                                // Same logic as WeChat pay
                                setTaskPostingFlow({
                                  ...taskPostingFlow,
                                  step: 'finding-freelancers'
                                });
                                
                                setTimeout(() => {
                                  const successMsg: Message = {
                                    id: (Date.now() + 1).toString(),
                                    type: 'ai',
                                    content: "支付成功！✅ 资金已托管到平台\n\n正在为你匹配最合适的接单者...",
                                    timestamp: new Date()
                                  };
                                  setMessages(prev => [...prev, successMsg]);
                                  
                                  setTimeout(() => {
                                    const matchedFreelancers = MOCK_RECOMMENDATIONS.slice(0, 3);
                                    const freelancerMsg: Message = {
                                      id: (Date.now() + 2).toString(),
                                      type: 'ai',
                                      content: `找到了 ${matchedFreelancers.length} 位高匹配度的接单者！让我为你展示...`,
                                      timestamp: new Date()
                                    };
                                    setMessages(prev => [...prev, freelancerMsg]);
                                    
                                    const triggerIdx = messages.length + 2;
                                    const recommendations = matchedFreelancers.map(freelancer => ({
                                      ...freelancer,
                                      whyMatch: `完成率${Math.floor(Math.random() * 10 + 90)}%，擅长相关技能，平均响应时间2小时`
                                    }));
                                    
                                    setTimeout(() => {
                                      setConversationState({
                                        lastQuery: '推荐接单者',
                                        availableContacts: recommendations,
                                        shownContacts: recommendations,
                                        currentIndex: 0
                                      });
                                      setCurrentRecommendations(recommendations);
                                      setShowCards(true);
                                      setCardsTriggerIndex(triggerIdx);
                                      setTimeout(() => setScrollToCards(true), 100);
                                      
                                      setTaskPostingFlow({
                                        isActive: false,
                                        step: 'completed',
                                        currentDraft: { isComplete: false },
                                        fieldsCollected: new Set()
                                      });
                                    }, 1500);
                                  }, 1500);
                                }, 500);
                              }}
                            >
                              <span className="text-2xl">💙</span>
                              <span className="font-semibold">支付宝</span>
                            </Button>
                          </div>
                          
                          <p className="text-xs text-center text-gray-500">
                            🔒 支付安全由平台保障
                          </p>
                        </motion.div>
                      </div>
                    ) : (
                      <div className="flex justify-start mb-3">
                        <div className="bg-gray-100 rounded-2xl rounded-tl-md px-4 py-2 max-w-xs">
                          <p className="text-gray-800 whitespace-pre-line">{message.content}</p>
                          <p className="text-xs text-gray-500 mt-1">{formatTime(message.timestamp)}</p>
                        </div>
                      </div>
                    )}
                  </motion.div>
                ))}
              </AnimatePresence>
            </div>

            {/* Cards Display Area - appears below last message, then scrolls into center */}
            <AnimatePresence>
              {showCards && cardsTriggerIndex !== null && (
                <motion.div
                  ref={cardsRef}
                  layout
                  initial={{ opacity: 0, y: 50, scale: 0.95 }}
                  animate={{ opacity: 1, y: 0, scale: 1 }}
                  exit={{ opacity: 0, y: 50, scale: 0.95 }}
                  transition={{ duration: 0.4 }}
                  className="flex justify-center w-full my-6"
                >
                  <ChatCards
                    ref={chatCardsRef}
                    profiles={currentRecommendations}
                    onSwipeLeft={handleCardIgnore}
                    onSwipeRight={handleCardWhisper}
                    onAllCardsFinished={handleCardStackClose}
                    currentRole={currentRole}
                  />
                </motion.div>
              )}
            </AnimatePresence>

            {/* After Cards Messages */}
            <div className="w-full space-y-4">
            <AnimatePresence>
              {afterCards.map((message) => (
                <motion.div
                  key={message.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.3 }}
                  layout
                    className="mb-4"
                >
                  {message.type === 'user' ? (
                      <div className="flex justify-end mb-3">
                      <div className="bg-blue-500 text-white rounded-2xl rounded-tr-md px-4 py-2 max-w-xs">
                        <p>{message.content}</p>
                        <p className="text-xs opacity-75 mt-1">{formatTime(message.timestamp)}</p>
                      </div>
                    </div>
                  ) : message.specialType === 'task-preview' && message.taskData ? (
                    // 🆕 Task Preview Card
                    <div className="flex justify-center mb-3">
                      <motion.div
                        initial={{ scale: 0.9, opacity: 0 }}
                        animate={{ scale: 1, opacity: 1 }}
                        className="bg-white border-2 border-blue-500 rounded-2xl p-5 max-w-md w-full shadow-lg"
                      >
                        <div className="flex items-center justify-between mb-3">
                          <h3 className="text-lg font-bold text-gray-800">📋 任务预览</h3>
                          <Badge variant="outline" className="bg-blue-50 text-blue-700">待确认</Badge>
                        </div>
                        
                        <div className="space-y-3">
                          {message.taskData.title && (
                            <div>
                              <p className="text-xs text-gray-500 mb-1">任务标题</p>
                              <p className="font-semibold text-gray-800">{message.taskData.title}</p>
                            </div>
                          )}
                          
                          {message.taskData.description && (
                            <div>
                              <p className="text-xs text-gray-500 mb-1">详细描述</p>
                              <p className="text-sm text-gray-700">{message.taskData.description}</p>
                            </div>
                          )}
                          
                          <div className="grid grid-cols-2 gap-3">
                            {message.taskData.budget && (
                              <div>
                                <p className="text-xs text-gray-500 mb-1">预算范围</p>
                                <p className="font-semibold text-green-600">
                                  ¥{message.taskData.budget.min}-{message.taskData.budget.max}
                                </p>
                              </div>
                            )}
                            
                            {message.taskData.deadline && (
                              <div>
                                <p className="text-xs text-gray-500 mb-1">截止时间</p>
                                <p className="text-sm text-gray-700">
                                  {new Date(message.taskData.deadline).toLocaleDateString('zh-CN')}
                                </p>
                              </div>
                            )}
                          </div>
                          
                          {message.taskData.skills && message.taskData.skills.length > 0 && (
                            <div>
                              <p className="text-xs text-gray-500 mb-1">所需技能</p>
                              <div className="flex flex-wrap gap-1">
                                {message.taskData.skills.map((skill, idx) => (
                                  <Badge key={idx} variant="secondary" className="text-xs">
                                    {skill}
                                  </Badge>
                                ))}
                              </div>
                            </div>
                          )}
                        </div>
                        
                        <div className="mt-4 pt-4 border-t border-gray-200 flex gap-2">
                          <Button 
                            variant="outline" 
                            size="sm" 
                            className="flex-1"
                            onClick={() => setInputValue("修改")}
                          >
                            修改
                          </Button>
                          <Button 
                            size="sm" 
                            className="flex-1 bg-blue-500 hover:bg-blue-600"
                            onClick={() => {
                              setInputValue("确认发布");
                              handleSendMessage();
                            }}
                          >
                            确认发布
                          </Button>
                        </div>
                      </motion.div>
                    </div>
                  ) : message.specialType === 'task-payment' && message.paymentData ? (
                    // 🆕 Payment Interface
                    <div className="flex justify-center mb-3">
                      <motion.div
                        initial={{ scale: 0.9, opacity: 0 }}
                        animate={{ scale: 1, opacity: 1 }}
                        className="bg-gradient-to-br from-green-50 to-blue-50 border-2 border-green-500 rounded-2xl p-5 max-w-md w-full shadow-lg"
                      >
                        <div className="text-center mb-4">
                          <h3 className="text-xl font-bold text-gray-800 mb-2">💳 支付任务预算</h3>
                          <p className="text-sm text-gray-600">资金将被平台托管，任务完成后释放</p>
                        </div>
                        
                        <div className="bg-white rounded-xl p-4 mb-4">
                          <div className="flex justify-between items-center mb-3">
                            <span className="text-gray-600">任务</span>
                            <span className="font-semibold">{message.paymentData.taskTitle}</span>
                          </div>
                          <div className="flex justify-between items-center">
                            <span className="text-gray-600">托管金额</span>
                            <span className="text-2xl font-bold text-green-600">¥{message.paymentData.amount}</span>
                          </div>
                        </div>
                        
                        <div className="space-y-2 mb-4">
                          <p className="text-xs text-gray-500 mb-2">选择支付方式</p>
                          <Button 
                            variant="outline" 
                            className="w-full justify-start gap-3 h-12 border-2 hover:border-green-500 hover:bg-green-50"
                            onClick={() => {
                              toast.success('正在跳转微信支付...');
                              setTimeout(() => {
                                setInputValue("支付完成");
                                handleSendMessage();
                              }, 1500);
                            }}
                          >
                            <span className="text-2xl">💚</span>
                            <span className="font-semibold">微信支付</span>
                          </Button>
                          <Button 
                            variant="outline" 
                            className="w-full justify-start gap-3 h-12 border-2 hover:border-blue-500 hover:bg-blue-50"
                            onClick={() => {
                              toast.success('正在跳转支付宝...');
                              setTimeout(() => {
                                setInputValue("支付完成");
                                handleSendMessage();
                              }, 1500);
                            }}
                          >
                            <span className="text-2xl">💙</span>
                            <span className="font-semibold">支付宝</span>
                          </Button>
                        </div>
                        
                        <p className="text-xs text-center text-gray-500">
                          🔒 支付安全由平台保障
                        </p>
                      </motion.div>
                    </div>
                  ) : (
                      <div className="flex justify-start mb-3">
                      <div className="bg-gray-100 rounded-2xl rounded-tl-md px-4 py-2 max-w-xs">
                        <p className="text-gray-800 whitespace-pre-line">{message.content}</p>
                        <p className="text-xs text-gray-500 mt-1">{formatTime(message.timestamp)}</p>
                      </div>
                    </div>
                  )}
                </motion.div>
              ))}
            </AnimatePresence>
            </div>

            {/* Typing Indicator */}
            {isTyping && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="flex justify-start mt-4"
              >
                <div className="bg-gray-100 rounded-2xl rounded-tl-md px-4 py-2">
                  <div className="flex space-x-1">
                    <motion.div
                      animate={{ scale: [1, 1.2, 1] }}
                      transition={{ duration: 0.6, repeat: Infinity, delay: 0 }}
                      className="w-2 h-2 bg-gray-400 rounded-full"
                    />
                    <motion.div
                      animate={{ scale: [1, 1.2, 1] }}
                      transition={{ duration: 0.6, repeat: Infinity, delay: 0.2 }}
                      className="w-2 h-2 bg-gray-400 rounded-full"
                    />
                    <motion.div
                      animate={{ scale: [1, 1.2, 1] }}
                      transition={{ duration: 0.6, repeat: Infinity, delay: 0.4 }}
                      className="w-2 h-2 bg-gray-400 rounded-full"
                    />
                  </div>
                </div>
              </motion.div>
            )}
          </div>

          <div ref={messagesEndRef} />
        </div>
      )}

      {/* Quoted Contacts Display */}
      {quotedContacts.length > 0 && (
        <div className="px-4 py-2 border-t border-gray-200">
          <div className="flex flex-wrap gap-2">
            {quotedContacts.map(contact => (
              <div key={contact.id} className="flex items-center gap-2 bg-blue-50 text-blue-700 px-3 py-1 rounded-full text-sm">
                <span>{contact.name}</span>
                <button
                  onClick={() => removeQuotedContact(contact.id)}
                  className="hover:bg-blue-200 rounded-full p-0.5"
                >
                  ×
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Suggestion Bubbles - only show in initial state - 🔴 UPDATED FOR PIVOT */}
      {messages.length === 0 && (
        <div className="px-4 pb-3">
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.3 }}
            className="flex flex-wrap gap-2 justify-center"
          >
            {currentRole === 'freelancer' ? (
              // Freelancer suggestions
              <>
                <button
                  onClick={() => {
                    setInputValue("找个设计的活儿");
                    setTimeout(() => handleSendMessage(), 100);
                  }}
                  className="bg-blue-50 hover:bg-blue-100 text-blue-700 px-3 py-2 rounded-full text-sm transition-colors border border-blue-200"
                >
                  找设计任务
                </button>
                <button
                  onClick={() => {
                    setInputValue("有什么PS的单吗");
                    setTimeout(() => handleSendMessage(), 100);
                  }}
                  className="bg-green-50 hover:bg-green-100 text-green-700 px-3 py-2 rounded-full text-sm transition-colors border border-green-200"
                >
                  PS修图
                </button>
                <button
                  onClick={() => {
                    setInputValue("我想接视频剪辑的单");
                    setTimeout(() => handleSendMessage(), 100);
                  }}
                  className="bg-purple-50 hover:bg-purple-100 text-purple-700 px-3 py-2 rounded-full text-sm transition-colors border border-purple-200"
                >
                  视频剪辑
                </button>
                <button
                  onClick={() => {
                    setInputValue("找PPT制作的任务");
                    setTimeout(() => handleSendMessage(), 100);
                  }}
                  className="bg-orange-50 hover:bg-orange-100 text-orange-700 px-3 py-2 rounded-full text-sm transition-colors border border-orange-200"
                >
                  PPT制作
                </button>
              </>
            ) : (
              // Poster suggestions
              <>
                <button
                  onClick={() => {
                    setInputValue("我想找人做海报");
                    handleSendMessage();
                  }}
                  className="bg-blue-50 hover:bg-blue-100 text-blue-700 px-3 py-2 rounded-full text-sm transition-colors border border-blue-200"
                >
                  找人做海报
                </button>
                <button
                  onClick={() => setInputValue("需要一个视频剪辑")}
                  className="bg-green-50 hover:bg-green-100 text-green-700 px-3 py-2 rounded-full text-sm transition-colors border border-green-200"
                >
                  视频剪辑师
                </button>
                <button
                  onClick={() => setInputValue("招聘Python开发")}
                  className="bg-purple-50 hover:bg-purple-100 text-purple-700 px-3 py-2 rounded-full text-sm transition-colors border border-purple-200"
                >
                  Python开发
                </button>
                <button
                  onClick={() => setInputValue("找个帮忙写文案的")}
                  className="bg-orange-50 hover:bg-orange-100 text-orange-700 px-3 py-2 rounded-full text-sm transition-colors border border-orange-200"
                >
                  文案撰写
                </button>
              </>
            )}
          </motion.div>
        </div>
      )}

      {/* Role Switcher + File Upload - above input */}
      <div className="px-4 py-2 bg-gray-50 border-t border-gray-200 flex items-center justify-between">
        {/* Left: Role Switch + File Upload */}
        <div className="flex items-center gap-3">
          <Label className="text-sm text-gray-600">模式</Label>
          <div className="flex items-center gap-2">
            <span className={`text-xs ${currentRole === 'freelancer' ? 'font-medium text-blue-600' : 'text-gray-400'}`}>
              接单
            </span>
            <Switch
              checked={currentRole === 'poster'}
              onCheckedChange={(checked: boolean) => {
                handleRoleChange(checked ? 'poster' : 'freelancer');
              }}
            />
            <span className={`text-xs ${currentRole === 'poster' ? 'font-medium text-blue-600' : 'text-gray-400'}`}>
              发单
            </span>
          </div>
          
          {/* File Upload Button */}
          <Button
            variant="outline"
            size="sm"
            className="h-8 gap-1.5"
            onClick={() => fileInputRef.current?.click()}
          >
            <Paperclip size={14} />
            <span className="text-xs">上传文件</span>
          </Button>
          <input
            ref={fileInputRef}
            type="file"
            multiple
            accept="image/*,.pdf,.doc,.docx"
            className="hidden"
            onChange={handleFileUpload}
          />
          
          {/* Uploaded Files Preview */}
          {uploadedFiles.length > 0 && (
            <div className="flex gap-1">
              {uploadedFiles.map((file, idx) => (
                <Badge key={idx} variant="secondary" className="text-xs px-2 py-0.5 gap-1">
                  📎 {file.name.slice(0, 10)}{file.name.length > 10 ? '...' : ''}
                  <X 
                    size={12} 
                    className="cursor-pointer hover:text-red-600" 
                    onClick={() => removeFile(idx)}
                  />
                </Badge>
              ))}
            </div>
          )}
        </div>
        
        {/* Right: Clear Chat Button */}
        <Button 
          variant="ghost" 
          size="sm"
          className="h-8 w-8 p-0"
          onClick={() => {
            setMessages([]);
            setShowCards(false);
            setCurrentRecommendations([]);
            setCardsTriggerIndex(null);
            setUploadedFiles([]);
            toast.success('对话已清空');
          }}
        >
          <Trash2 size={14} />
        </Button>
      </div>

      {/* Input Area */}
      <div className="p-4 border-t border-gray-200 bg-white">
        <div className="flex items-center gap-2">
          {/* Input with Send Button */}
          <div className="flex-1 relative">
            <Input
              value={inputValue}
              onChange={(e) => setInputValue(e.target.value)}
              onKeyPress={handleKeyPress}
              placeholder={currentRole === 'freelancer' ? '找任务...' : '找人帮忙...'}
              className="pr-12 rounded-full"
            />
            <Button
              onClick={handleSendMessage}
              disabled={!inputValue.trim() && quotedContacts.length === 0}
              size="sm"
              className="absolute right-1 top-1/2 transform -translate-y-1/2 rounded-full w-8 h-8 p-0"
            >
              <Send size={14} />
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
});

ChatInterface.displayName = 'ChatInterface';
