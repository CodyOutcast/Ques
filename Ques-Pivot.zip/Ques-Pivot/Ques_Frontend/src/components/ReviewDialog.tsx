import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from './ui/dialog';
import { Button } from './ui/button';
import { Star } from 'lucide-react';

interface ReviewDialogProps {
  isOpen: boolean;
  onClose: () => void;
  orderId: string;
  partnerName: string;
  onSubmit: (rating: number) => void;
}

export function ReviewDialog({ 
  isOpen, 
  onClose, 
  orderId, 
  partnerName,
  onSubmit 
}: ReviewDialogProps) {
  const [rating, setRating] = useState(0);
  const [hoveredRating, setHoveredRating] = useState(0);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = async () => {
    if (rating === 0) return;
    
    setIsSubmitting(true);
    try {
      await onSubmit(rating);
      onClose();
    } catch (error) {
      console.error('Failed to submit review:', error);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>评价 {partnerName}</DialogTitle>
        </DialogHeader>
        
        <div className="py-6">
          <p className="text-center text-gray-600 mb-6">
            为本次合作打分
          </p>
          
          {/* ✅ 极简5星评分 - 无文字评价 */}
          <div className="flex justify-center gap-3 mb-8">
            {[1, 2, 3, 4, 5].map(star => (
              <motion.button
                key={star}
                whileHover={{ scale: 1.2 }}
                whileTap={{ scale: 0.9 }}
                onClick={() => setRating(star)}
                onMouseEnter={() => setHoveredRating(star)}
                onMouseLeave={() => setHoveredRating(0)}
                className="focus:outline-none"
              >
                <Star
                  size={40}
                  className={`transition-colors ${
                    star <= (hoveredRating || rating)
                      ? 'fill-orange-400 text-orange-400'
                      : 'text-gray-300'
                  }`}
                />
              </motion.button>
            ))}
          </div>
          
          {rating > 0 && (
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className="text-center mb-4"
            >
              <p className="text-2xl font-bold text-orange-500">
                {rating === 5 && '非常满意 🎉'}
                {rating === 4 && '很满意 😊'}
                {rating === 3 && '满意 👍'}
                {rating === 2 && '一般 😐'}
                {rating === 1 && '不满意 😞'}
              </p>
            </motion.div>
          )}
        </div>
        
        <div className="flex gap-3">
          <Button
            variant="outline"
            onClick={onClose}
            className="flex-1"
            disabled={isSubmitting}
          >
            取消
          </Button>
          <Button
            onClick={handleSubmit}
            disabled={rating === 0 || isSubmitting}
            className="flex-1"
          >
            {isSubmitting ? '提交中...' : '提交评价'}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
