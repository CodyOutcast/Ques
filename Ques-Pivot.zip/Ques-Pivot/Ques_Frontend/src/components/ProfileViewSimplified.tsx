import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Button } from './ui/button';
import { Card } from './ui/card';
import { Badge } from './ui/badge';
import { Edit, Star, CheckCircle, FileText, Settings } from 'lucide-react';
import type { UserProfile } from '../App';
import { useLanguage } from '../contexts';

interface ProfileViewProps {
  userProfile: UserProfile;
  onUpdate: (profile: UserProfile) => void;
}

export function ProfileView({ userProfile, onUpdate }: ProfileViewProps) {
  const { t } = useLanguage();
  const [isEditing, setIsEditing] = useState(false);

  // Calculate age from birthday
  const getAge = (birthday: string) => {
    if (!birthday) return '';
    const birthDate = new Date(birthday);
    const today = new Date();
    let age = today.getFullYear() - birthDate.getFullYear();
    const monthDiff = today.getMonth() - birthDate.getMonth();
    if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birthDate.getDate())) {
      age--;
    }
    return age;
  };

  return (
    <div className="h-full overflow-y-auto bg-gray-50 pb-20">
      {/* Header Section */}
      <div className="bg-white p-6 border-b">
        <div className="flex flex-col items-center">
          {/* Avatar */}
          <div className="relative mb-4">
            <div className="w-24 h-24 rounded-full bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center text-4xl overflow-hidden">
              {userProfile.profilePhoto ? (
                <img src={userProfile.profilePhoto} alt={userProfile.name} className="w-full h-full object-cover" />
              ) : (
                <span className="text-white">👤</span>
              )}
            </div>
            <button 
              onClick={() => setIsEditing(true)}
              className="absolute bottom-0 right-0 w-8 h-8 bg-blue-500 rounded-full flex items-center justify-center text-white shadow-lg"
            >
              <Edit size={16} />
            </button>
          </div>

          {/* Name & Basic Info */}
          <h1 className="text-2xl font-bold mb-1">{userProfile.name || '未设置姓名'}</h1>
          <p className="text-gray-500 text-sm mb-1">
            {getAge(userProfile.birthday) && `${getAge(userProfile.birthday)}岁`}
            {userProfile.gender && ` · ${userProfile.gender}`}
          </p>
          <p className="text-gray-500 text-sm mb-3">{userProfile.location || '未设置位置'}</p>
          
          {/* One-sentence intro */}
          {userProfile.oneSentenceIntro && (
            <p className="text-center text-gray-700 text-sm max-w-md mb-4">
              {userProfile.oneSentenceIntro}
            </p>
          )}

          {/* ✅ Minimalist Stats - 3 horizontal metrics */}
          <div className="grid grid-cols-3 gap-4 w-full max-w-md mt-4">
            <div className="text-center">
              <div className="flex items-center justify-center gap-1 mb-1">
                <Star className="w-4 h-4 text-orange-500" />
                <span className="text-2xl font-bold text-orange-500">
                  {userProfile.rating?.toFixed(1) || '0.0'}
                </span>
              </div>
              <p className="text-xs text-gray-500">综合评分</p>
            </div>
            
            <div className="text-center border-x border-gray-200">
              <div className="flex items-center justify-center gap-1 mb-1">
                <CheckCircle className="w-4 h-4 text-green-500" />
                <span className="text-2xl font-bold text-green-500">
                  {userProfile.completedTasks || 0}
                </span>
              </div>
              <p className="text-xs text-gray-500">完成任务</p>
            </div>
            
            <div className="text-center">
              <div className="flex items-center justify-center gap-1 mb-1">
                <FileText className="w-4 h-4 text-blue-500" />
                <span className="text-2xl font-bold text-blue-500">
                  {userProfile.postedTasks || 0}
                </span>
              </div>
              <p className="text-xs text-gray-500">发布任务</p>
            </div>
          </div>
        </div>
      </div>

      {/* Skills Section */}
      {userProfile.skills && userProfile.skills.length > 0 && (
        <Card className="m-4 p-4">
          <h3 className="font-semibold mb-3 flex items-center gap-2">
            <span>💼</span>
            <span>擅长领域</span>
          </h3>
          <div className="flex flex-wrap gap-2">
            {userProfile.skills.map((skill, index) => (
              <Badge key={index} variant="secondary">
                {skill}
              </Badge>
            ))}
          </div>
        </Card>
      )}

      {/* Portfolio/Projects Section */}
      {userProfile.projects && userProfile.projects.length > 0 && (
        <Card className="m-4 p-4">
          <h3 className="font-semibold mb-3 flex items-center gap-2">
            <span>📁</span>
            <span>作品集</span>
          </h3>
          <div className="space-y-3">
            {userProfile.projects.map((project, index) => (
              <div key={index} className="border-b last:border-b-0 pb-3 last:pb-0">
                <div className="flex items-start justify-between mb-1">
                  <h4 className="font-semibold text-sm">{project.title}</h4>
                  <Badge variant="outline" className="text-xs">{project.role}</Badge>
                </div>
                <p className="text-xs text-gray-600 mb-2">{project.description}</p>
                {project.referenceLinks && project.referenceLinks.length > 0 && (
                  <div className="flex flex-wrap gap-2">
                    {project.referenceLinks.map((link, linkIndex) => (
                      <a
                        key={linkIndex}
                        href={link}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-xs text-blue-500 hover:underline"
                      >
                        查看作品 →
                      </a>
                    ))}
                  </div>
                )}
              </div>
            ))}
          </div>
        </Card>
      )}

      {/* University Section */}
      {userProfile.university && (
        <Card className="m-4 p-4">
          <h3 className="font-semibold mb-3 flex items-center gap-2">
            <span>🎓</span>
            <span>教育背景</span>
          </h3>
          <div className="flex items-center justify-between">
            <span className="text-sm">{userProfile.university.name}</span>
            {userProfile.university.verified && (
              <Badge variant="default" className="text-xs">
                <CheckCircle className="w-3 h-3 mr-1" />
                已认证
              </Badge>
            )}
          </div>
        </Card>
      )}

      {/* Hobbies Section */}
      {userProfile.hobbies && userProfile.hobbies.length > 0 && (
        <Card className="m-4 p-4">
          <h3 className="font-semibold mb-3 flex items-center gap-2">
            <span>❤️</span>
            <span>兴趣爱好</span>
          </h3>
          <div className="flex flex-wrap gap-2">
            {userProfile.hobbies.map((hobby, index) => (
              <Badge key={index} variant="outline">
                {hobby}
              </Badge>
            ))}
          </div>
        </Card>
      )}

      {/* Languages Section */}
      {userProfile.languages && userProfile.languages.length > 0 && (
        <Card className="m-4 p-4">
          <h3 className="font-semibold mb-3 flex items-center gap-2">
            <span>🌍</span>
            <span>语言能力</span>
          </h3>
          <div className="flex flex-wrap gap-2">
            {userProfile.languages.map((language, index) => (
              <Badge key={index} variant="outline">
                {language}
              </Badge>
            ))}
          </div>
        </Card>
      )}

      {/* Edit Button at Bottom */}
      <div className="fixed bottom-20 left-0 right-0 p-4 bg-gradient-to-t from-gray-50 to-transparent">
        <Button
          onClick={() => {
            // Navigate to edit profile - will be implemented later
            console.log('Edit profile');
          }}
          className="w-full"
          variant="outline"
        >
          <Settings className="w-4 h-4 mr-2" />
          编辑个人资料
        </Button>
      </div>
    </div>
  );
}
