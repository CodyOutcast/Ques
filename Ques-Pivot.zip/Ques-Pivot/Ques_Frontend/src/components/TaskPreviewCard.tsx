import React from 'react';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from './ui/avatar';
import { Clock, DollarSign, Users, Edit, RefreshCw, Check } from 'lucide-react';
import type { Task } from '../types/pivot';
import { useLanguage } from '../contexts/LanguageContext';

interface TaskPreviewCardProps {
  task: Partial<Task>;
  mode: 'preview' | 'draft' | 'published';
  onEdit?: () => void;
  onPublish?: () => void;
  onRegenerate?: () => void;
}

export const TaskPreviewCard: React.FC<TaskPreviewCardProps> = ({
  task,
  mode,
  onEdit,
  onPublish,
  onRegenerate,
}) => {
  const { t } = useLanguage();

  const formatDeadline = (deadline?: string) => {
    if (!deadline) return '未设置';
    const now = new Date();
    const end = new Date(deadline);
    const diff = end.getTime() - now.getTime();
    const days = Math.floor(diff / (1000 * 60 * 60 * 24));
    const hours = Math.floor((diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
    
    if (days > 0) {
      return `${days}天${hours}小时`;
    } else if (hours > 0) {
      return `${hours}小时`;
    } else {
      return '即将截止';
    }
  };

  return (
    <Card className="p-4 space-y-4 max-w-md mx-auto border-2 border-orange-200 bg-orange-50">
      {/* Header with mode badge */}
      <div className="flex items-center justify-between">
        <Badge variant={mode === 'published' ? 'default' : 'secondary'} className="text-sm">
          {mode === 'preview' && '📝 任务预览'}
          {mode === 'draft' && '✏️ 任务草稿'}
          {mode === 'published' && '✅ 已发布'}
        </Badge>
        {mode === 'published' && task.applicationCount !== undefined && (
          <div className="flex items-center gap-1 text-sm text-gray-600">
            <Users className="w-4 h-4" />
            <span>{task.applicationCount} 人申请</span>
          </div>
        )}
      </div>

      {/* Task Title */}
      <div>
        <h3 className="text-xl font-bold text-gray-900">{task.title || '未命名任务'}</h3>
        {task.category && (
          <Badge variant="outline" className="mt-2">
            {task.category}
          </Badge>
        )}
      </div>

      {/* Budget */}
      {task.budget && (
        <div className="flex items-center gap-2 bg-white p-3 rounded-lg">
          <DollarSign className="w-5 h-5 text-orange-500" />
          <div className="flex-1">
            <p className="text-sm text-gray-500">预算</p>
            <p className="text-xl font-bold text-orange-600">
              ¥{task.budget.min} - ¥{task.budget.max}
            </p>
          </div>
        </div>
      )}

      {/* Deadline */}
      {task.deadline && (
        <div className="flex items-center gap-2 bg-white p-3 rounded-lg">
          <Clock className="w-5 h-5 text-red-500" />
          <div className="flex-1">
            <p className="text-sm text-gray-500">截止时间</p>
            <p className="text-base font-semibold text-red-600">
              还剩 {formatDeadline(task.deadline)}
            </p>
          </div>
        </div>
      )}

      {/* Required Skills */}
      {task.skills && task.skills.length > 0 && (
        <div>
          <p className="text-sm font-medium text-gray-700 mb-2">所需技能</p>
          <div className="flex flex-wrap gap-2">
            {task.skills.map((skill, index) => (
              <Badge key={index} variant="secondary" className="bg-blue-100 text-blue-700">
                {skill}
              </Badge>
            ))}
          </div>
        </div>
      )}

      {/* Task Description */}
      {task.description && (
        <div>
          <p className="text-sm font-medium text-gray-700 mb-2">任务描述</p>
          <p className="text-sm text-gray-600 leading-relaxed bg-white p-3 rounded-lg">
            {task.description}
          </p>
        </div>
      )}

      {/* Deliverables */}
      {task.deliverables && task.deliverables.length > 0 && (
        <div>
          <p className="text-sm font-medium text-gray-700 mb-2">交付要求</p>
          <ul className="list-disc list-inside space-y-1 text-sm text-gray-600 bg-white p-3 rounded-lg">
            {task.deliverables.map((item, index) => (
              <li key={index}>{item}</li>
            ))}
          </ul>
        </div>
      )}

      {/* Attachments Preview */}
      {task.attachments && task.attachments.length > 0 && (
        <div>
          <p className="text-sm font-medium text-gray-700 mb-2">参考图片 ({task.attachments.length})</p>
          <div className="grid grid-cols-2 gap-2">
            {task.attachments.slice(0, 4).map((attachment, index) => (
              <div
                key={attachment.id}
                className="aspect-square rounded-lg bg-gray-200 overflow-hidden"
              >
                <img
                  src={attachment.url}
                  alt={`参考图 ${index + 1}`}
                  className="w-full h-full object-cover"
                />
              </div>
            ))}
          </div>
          {task.attachments.length > 4 && (
            <p className="text-xs text-gray-500 mt-2">还有 {task.attachments.length - 4} 张图片</p>
          )}
        </div>
      )}

      {/* Poster Info (if available) */}
      {task.poster && (
        <div className="bg-white p-3 rounded-lg border border-gray-200">
          <p className="text-sm font-medium text-gray-700 mb-2">发单者信息</p>
          <div className="flex items-center gap-3">
            <Avatar>
              <AvatarImage src={task.poster.avatar} />
              <AvatarFallback>{task.poster.name[0]}</AvatarFallback>
            </Avatar>
            <div className="flex-1">
              <p className="font-medium text-gray-900">{task.poster.name}</p>
              <p className="text-sm text-gray-500">{task.poster.university.name}</p>
              <div className="flex gap-2 mt-1">
                <Badge variant="outline" className="text-xs">
                  ★ {task.poster.posterRating.toFixed(1)}
                </Badge>
                <Badge variant="outline" className="text-xs">
                  发单 {task.poster.postedTasksCount}次
                </Badge>
                <Badge variant="outline" className="text-xs">
                  按时付款 {task.poster.onTimePaymentRate}%
                </Badge>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Action Buttons */}
      {mode === 'preview' && (
        <div className="flex gap-2 pt-2">
          {onRegenerate && (
            <Button variant="outline" className="flex-1" onClick={onRegenerate}>
              <RefreshCw className="w-4 h-4 mr-2" />
              重新生成
            </Button>
          )}
          {onEdit && (
            <Button variant="outline" className="flex-1" onClick={onEdit}>
              <Edit className="w-4 h-4 mr-2" />
              编辑
            </Button>
          )}
          {onPublish && (
            <Button className="flex-1 bg-orange-500 hover:bg-orange-600" onClick={onPublish}>
              <Check className="w-4 h-4 mr-2" />
              发布任务
            </Button>
          )}
        </div>
      )}

      {mode === 'published' && (
        <div className="bg-green-50 border border-green-200 rounded-lg p-3 text-center">
          <p className="text-sm text-green-700 font-medium">
            ✅ 任务已发布！等待接单者申请
          </p>
        </div>
      )}
    </Card>
  );
};

export default TaskPreviewCard;
