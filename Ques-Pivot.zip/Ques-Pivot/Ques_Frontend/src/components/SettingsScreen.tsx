import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Button } from './ui/button';
import { Card } from './ui/card';
import { Switch } from './ui/switch';
import { Separator } from './ui/separator';
import { Badge } from './ui/badge';
import { Input } from './ui/input';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from './ui/dialog';
import { useLanguage } from '../contexts/LanguageContext';

import { 
  Bell, 
  MessageCircle,
  CreditCard, 
  FileText,
  LogOut, 
  Trash2,
  Globe,
  Moon,
  Sun
} from 'lucide-react';

interface SettingsScreenProps {
  currentPlan?: 'basic' | 'pro';
  whispersLeft?: number;
  onPlanChange?: (plan: 'basic' | 'pro') => void;
}

export function SettingsScreen({ 
  currentPlan = 'basic', 
  whispersLeft = 3,
  onPlanChange
}: SettingsScreenProps) {
  const { language, setLanguage, t } = useLanguage();
  
  const [notifications, setNotifications] = useState({
    whisperRequests: true,
  });

  const [theme, setTheme] = useState<'light' | 'dark'>('light');

  const [wechatId, setWechatId] = useState(() => {
    // 从localStorage加载保存的微信ID
    return localStorage.getItem('user_wechat_id') || 'your_wechat_id';
  });
  const settingSections = [
    {
      title: t('settings.language.title'),
      icon: Globe,
      description: t('settings.language.description'),
      content: (
        <div className="space-y-3">
          {/* English Option */}
          <div 
            className={`p-4 rounded-lg border-2 cursor-pointer transition-all ${
              language === 'en' 
                ? 'border-blue-500 bg-blue-50' 
                : 'border-gray-200 hover:border-gray-300'
            }`}
            onClick={() => {
              setLanguage('en');
            }}
          >
            <div className="flex items-center justify-between">
              <div>
                <h4 className="font-medium">{t('settings.language.english')}</h4>
                <p className="text-xs text-gray-500">{t('settings.language.englishDesc')}</p>
              </div>
              {language === 'en' && (
                <Badge variant="default" className="text-xs">{t('settings.language.current')}</Badge>
              )}
            </div>
          </div>

          {/* Chinese Option */}
          <div 
            className={`p-4 rounded-lg border-2 cursor-pointer transition-all ${
              language === 'zh' 
                ? 'border-blue-500 bg-blue-50' 
                : 'border-gray-200 hover:border-gray-300'
            }`}
            onClick={() => {
              setLanguage('zh');
            }}
          >
            <div className="flex items-center justify-between">
              <div>
                <h4 className="font-medium">{t('settings.language.chinese')}</h4>
                <p className="text-xs text-gray-500">{t('settings.language.chineseDesc')}</p>
              </div>
              {language === 'zh' && (
                <Badge variant="default" className="text-xs">{t('settings.language.current')}</Badge>
              )}
            </div>
          </div>
        </div>
      )
    },
    {
      title: t('settings.appearance.title'),
      icon: Moon,
      description: t('settings.appearance.description'),
      content: (
        <div className="space-y-3">
          {/* Light Mode Option */}
          <div 
            className={`p-4 rounded-lg border-2 cursor-pointer transition-all ${
              theme === 'light' 
                ? 'border-blue-500 bg-blue-50' 
                : 'border-gray-200 hover:border-gray-300'
            }`}
            onClick={() => {
              setTheme('light');
            }}
          >
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <Sun size={20} className="text-yellow-500" />
                <div>
                  <h4 className="font-medium">{t('settings.appearance.lightMode')}</h4>
                  <p className="text-xs text-gray-500">{t('settings.appearance.lightModeDesc')}</p>
                </div>
              </div>
              {theme === 'light' && (
                <Badge variant="default" className="text-xs">{t('settings.appearance.current')}</Badge>
              )}
            </div>
          </div>

          {/* Dark Mode Option */}
          <div 
            className={`p-4 rounded-lg border-2 cursor-pointer transition-all ${
              theme === 'dark' 
                ? 'border-blue-500 bg-blue-50' 
                : 'border-gray-200 hover:border-gray-300'
            }`}
            onClick={() => {
              setTheme('dark');
            }}
          >
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <Moon size={20} className="text-indigo-500" />
                <div>
                  <h4 className="font-medium">{t('settings.appearance.darkMode')}</h4>
                  <p className="text-xs text-gray-500">{t('settings.appearance.darkModeDesc')}</p>
                </div>
              </div>
              {theme === 'dark' && (
                <Badge variant="default" className="text-xs">{t('settings.appearance.current')}</Badge>
              )}
            </div>
          </div>
        </div>
      )
    },
    {
      title: t('settings.whispers.title'),
      icon: MessageCircle,
      description: t('settings.whispers.description'),
      content: (
        <div className="space-y-4">
          <div>
            <h4 className="text-sm font-medium mb-2">{t('settings.whispers.wechatTitle')}</h4>
            <p className="text-xs text-gray-500 mb-3">
              {t('settings.whispers.wechatDesc')}
            </p>
            <Input
              placeholder={t('settings.whispers.wechatPlaceholder')}
              value={wechatId}
              onChange={(e) => {
                const newWechatId = e.target.value;
                setWechatId(newWechatId);
                // 立即保存到localStorage
                localStorage.setItem('user_wechat_id', newWechatId);
              }}
            />
          </div>

          <div className="p-3 bg-blue-50 rounded-lg">
            <div className="flex items-center justify-between mb-1">
              <span className="text-sm font-medium">{t('settings.whispers.usageTitle')}</span>
              <Badge variant={currentPlan === 'pro' ? 'default' : 'secondary'}>
                {currentPlan === 'pro' ? t('settings.whispers.proPlan') : t('settings.whispers.basicPlan')}
              </Badge>
            </div>
            <p className="text-xs text-gray-600">
              {`${whispersLeft} ${t('settings.whispers.whispersRemaining')}`}
            </p>
          </div>
        </div>
      )
    },
    {
      title: t('settings.payment.title'),
      icon: CreditCard,
      description: t('settings.payment.description'),
      content: (
        <div className="space-y-4">
          {/* Whispers Status */}
          <div className="bg-gray-50 rounded-lg p-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="flex items-center gap-2">
                  <span className="text-sm font-medium">{t('settings.payment.whispersLeft')}</span>
                  <span className="text-sm font-medium text-purple-600">
                    {whispersLeft}
                  </span>
                  {whispersLeft <= 2 && (
                    <Badge variant="destructive" className="text-xs">{t('settings.payment.low')}</Badge>
                  )}
                </div>

                <div className="w-16 bg-gray-200 rounded-full h-1.5">
                  <div 
                    className="bg-purple-500 h-1.5 rounded-full transition-all duration-300"
                    style={{ width: `${Math.min((whispersLeft / 50) * 100, 100)}%` }}
                  />
                </div>
              </div>
            </div>
          </div>
        </div>
      )
    },
    {
      title: t('settings.notifications.title'),
      icon: Bell,
      description: t('settings.notifications.description'),
      content: (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <span className="text-sm font-medium">{t('settings.notifications.whisperRequests')}</span>
              <p className="text-xs text-gray-500">{t('settings.notifications.whisperRequestsDesc')}</p>
            </div>
            <Switch 
              checked={notifications.whisperRequests}
              onCheckedChange={(checked: boolean) => setNotifications(prev => ({ ...prev, whisperRequests: checked }))}
            />
          </div>
        </div>
      )
    },
    {
      title: t('settings.terms.title'),
      icon: FileText,
      description: t('settings.terms.description'),
      content: (
        <div className="space-y-3">
          <Button variant="ghost" className="w-full justify-start p-0 h-auto">
            <div className="text-left">
              <p className="text-sm font-medium">{t('settings.terms.termsOfService')}</p>
              <p className="text-xs text-gray-500">{t('settings.terms.termsDesc')}</p>
            </div>
          </Button>
          
          <Separator />
          
          <Button variant="ghost" className="w-full justify-start p-0 h-auto">
            <div className="text-left">
              <p className="text-sm font-medium">{t('settings.terms.privacyPolicy')}</p>
              <p className="text-xs text-gray-500">{t('settings.terms.privacyDesc')}</p>
            </div>
          </Button>
          
          <Separator />
          
          <Button variant="ghost" className="w-full justify-start p-0 h-auto">
            <div className="text-left">
              <p className="text-sm font-medium">{t('settings.terms.dataProtection')}</p>
              <p className="text-xs text-gray-500">{t('settings.terms.dataProtectionDesc')}</p>
            </div>
          </Button>
          
          <Separator />
          
          <Button variant="ghost" className="w-full justify-start p-0 h-auto">
            <div className="text-left">
              <p className="text-sm font-medium">{t('settings.terms.communityGuidelines')}</p>
              <p className="text-xs text-gray-500">{t('settings.terms.communityDesc')}</p>
            </div>
          </Button>
        </div>
      )
    }
  ];

  return (
    <div className="h-full overflow-y-auto bg-gray-50">
      {/* Header */}
      <div className="bg-white p-4 border-b border-gray-200 sticky top-0 z-10">
        <h1 className="text-xl font-medium">{t('settings.title')}</h1>
        <p className="text-sm text-gray-500">{t('settings.subtitle')}</p>
      </div>

      <div className="p-4 space-y-4">

        {/* Settings Sections */}
        {settingSections.map((section, index) => (
          <motion.div
            key={section.title}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.3, delay: index * 0.1 }}
          >
            <Card className="p-4">
              <div className="flex items-center gap-3 mb-3">
                <section.icon size={20} className="text-gray-600" />
                <div>
                  <h3 className="font-medium">{section.title}</h3>
                  <p className="text-xs text-gray-500">{section.description}</p>
                </div>
              </div>
              {section.content}
            </Card>
          </motion.div>
        ))}

        {/* Account Actions */}
        <Card className="p-4">
          <h3 className="font-medium mb-3">{t('settings.account.title')}</h3>
          <div className="space-y-3">
            <Button variant="outline" className="w-full justify-center gap-2">
              <LogOut size={16} />
              {t('settings.account.signOut')}
            </Button>
            
            <Button variant="destructive" className="w-full justify-center gap-2">
              <Trash2 size={16} />
              {t('settings.account.deleteAccount')}
            </Button>
          </div>
          
          <div className="mt-4 p-3 bg-yellow-50 rounded-lg">
            <p className="text-xs text-yellow-700">
              <strong>{t('settings.account.dataNotice')}</strong> {t('settings.account.dataNoticeText')}
            </p>
          </div>
        </Card>

        {/* Safe area for bottom navigation */}
        <div className="h-20"></div>
      </div>
    </div>
  );
}