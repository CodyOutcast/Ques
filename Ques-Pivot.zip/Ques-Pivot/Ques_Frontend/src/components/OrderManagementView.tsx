import React, { useState } from 'react';
import { Card } from './ui/card';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { ClipboardList, Clock, DollarSign, Star, CheckCircle, AlertCircle, MessageCircle, ChevronRight } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { OrderDetailView } from './OrderDetailView';
import { ReviewDialog } from './ReviewDialog';

interface Order {
  id: string;
  title: string;
  description: string;
  status: 'pending' | 'in_progress' | 'submitted' | 'completed' | 'cancelled';
  amount: number;
  deadline: string;
  partner: { 
    id: string;
    name: string; 
    avatar: string;
    rating?: number;
  };
  createdAt: string;
  submittedAt?: string;
  completedAt?: string;
  skills: string[];
  attachments?: { name: string; url: string }[];
}

interface OrderManagementViewProps {
  // Future: user profile, orders data
}

export function OrderManagementView({ }: OrderManagementViewProps) {
  const [activeTab, setActiveTab] = useState<'received' | 'posted'>('received');
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null);
  const [showReviewDialog, setShowReviewDialog] = useState(false);
  const [reviewingOrder, setReviewingOrder] = useState<Order | null>(null);
  
  // Mock data - 高校线下任务场景
  const mockOrders: Order[] = [
    {
      id: '1',
      title: '帮忙代签到（本周两次）',
      description: '微积分早八课，周三和周五需要帮忙签到。理科楼A301，7:50前到即可',
      status: 'in_progress',
      amount: 40,
      deadline: '2025-10-25',
      partner: { 
        id: 'user1',
        name: '张小明', 
        avatar: '👨‍💻',
        rating: 4.8
      },
      createdAt: '2025-10-20',
      skills: ['同校学生', '早起', '守时'],
      attachments: []
    },
    {
      id: '2',
      title: '论文数据标注（500条）',
      description: '毕业论文需要标注500条文本数据（情感分析），已提供详细指南',
      status: 'submitted',
      amount: 100,
      deadline: '2025-10-23',
      partner: { 
        id: 'user2',
        name: '李华', 
        avatar: '📚',
        rating: 4.9
      },
      createdAt: '2025-10-18',
      submittedAt: '2025-10-22',
      skills: ['数据标注', '细心认真', '中文阅读'],
      attachments: [
        { name: '标注结果.xlsx', url: '#' }
      ]
    },
    {
      id: '3',
      title: '高数作业辅导（一对一）',
      description: '需要高数学霸讲解本周作业15道题，多元函数微积分部分',
      status: 'completed',
      amount: 80,
      deadline: '2025-10-15',
      partner: { 
        id: 'user3',
        name: '王芳', 
        avatar: '�',
        rating: 5.0
      },
      createdAt: '2025-10-10',
      submittedAt: '2025-10-14',
      completedAt: '2025-10-15',
      skills: ['高等数学', '一对一辅导', '讲解能力'],
      attachments: []
    },
    {
      id: '4',
      title: '活动现场帮手（周六下午）',
      description: '社团音乐节需要3名现场帮手，协助布置场地和引导观众',
      status: 'pending',
      amount: 90,
      deadline: '2025-10-27',
      partner: { 
        id: 'user4',
        name: '赵敏', 
        avatar: '🎤',
        rating: 4.7
      },
      createdAt: '2025-10-21',
      skills: ['活动组织', '沟通能力', '体力充沛'],
      attachments: []
    }
  ];
  
  const getStatusConfig = (status: string) => {
    const statusMap: Record<string, { 
      label: string; 
      variant: 'default' | 'secondary' | 'outline' | 'destructive';
      color: string;
      icon: any;
    }> = {
      'pending': { 
        label: '待接单', 
        variant: 'outline',
        color: 'text-gray-500',
        icon: Clock
      },
      'in_progress': { 
        label: '进行中', 
        variant: 'default',
        color: 'text-blue-500',
        icon: Clock
      },
      'submitted': { 
        label: '待验收', 
        variant: 'secondary',
        color: 'text-orange-500',
        icon: AlertCircle
      },
      'completed': { 
        label: '已完成', 
        variant: 'outline',
        color: 'text-green-500',
        icon: CheckCircle
      },
      'cancelled': { 
        label: '已取消', 
        variant: 'destructive',
        color: 'text-red-500',
        icon: AlertCircle
      }
    };
    
    return statusMap[status] || statusMap['pending'];
  };
  
  const handleAcceptOrder = (order: Order) => {
    // TODO: Call API to accept order
    console.log('Accept order:', order.id);
    alert('订单验收通过！');
  };
  
  const handleReportOrder = (order: Order) => {
    // TODO: Call API to report order
    console.log('Report order:', order.id);
    alert('举报已提交，我们会尽快处理');
  };
  
  const handleReviewOrder = (order: Order) => {
    setReviewingOrder(order);
    setShowReviewDialog(true);
  };
  
  const handleSubmitReview = (rating: number) => {
    // TODO: Call API to submit review
    console.log('Submit review:', reviewingOrder?.id, 'Rating:', rating);
    setShowReviewDialog(false);
    setReviewingOrder(null);
    alert('评价已提交！');
  };
  
  const handleContactPartner = (partnerId: string) => {
    // TODO: Navigate to message conversation
    console.log('Contact partner:', partnerId);
    alert('即将跳转到消息界面');
  };
  
  return (
    <div className="h-full flex flex-col bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b px-4 py-4">
        <h1 className="text-xl font-semibold">任务管理</h1>
      </div>
      
      {/* Tab Switcher */}
      <div className="bg-white border-b px-4 py-2 flex gap-2">
        <Button
          variant={activeTab === 'received' ? 'default' : 'outline'}
          size="sm"
          onClick={() => setActiveTab('received')}
          className="flex-1"
        >
          我接的单
        </Button>
        <Button
          variant={activeTab === 'posted' ? 'default' : 'outline'}
          size="sm"
          onClick={() => setActiveTab('posted')}
          className="flex-1"
        >
          我发的单
        </Button>
      </div>
      
      {/* Orders List */}
      <div className="flex-1 overflow-y-auto p-4 space-y-3">
        {mockOrders.length === 0 ? (
          <div className="text-center py-12">
            <ClipboardList className="w-16 h-16 mx-auto text-gray-300 mb-4" />
            <p className="text-gray-500">
              {activeTab === 'received' ? '还没有接单哦' : '还没有发布任务'}
            </p>
          </div>
        ) : (
          mockOrders.map((order, index) => {
            const statusConfig = getStatusConfig(order.status);
            const StatusIcon = statusConfig.icon;
            
            return (
              <motion.div
                key={order.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
              >
                <Card className="p-4 hover:shadow-md transition-shadow">
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <h3 className="font-semibold text-lg">{order.title}</h3>
                        <Badge variant={statusConfig.variant} className="flex items-center gap-1">
                          <StatusIcon className="w-3 h-3" />
                          {statusConfig.label}
                        </Badge>
                      </div>
                      <p className="text-sm text-gray-600 line-clamp-2 mb-2">
                        {order.description}
                      </p>
                      <div className="flex items-center gap-2 text-sm">
                        <div className="w-6 h-6 rounded-full flex items-center justify-center bg-gray-100">
                          {order.partner.avatar}
                        </div>
                        <span className="text-gray-600">{order.partner.name}</span>
                        {order.partner.rating && (
                          <div className="flex items-center gap-1 text-yellow-500">
                            <Star className="w-3 h-3 fill-current" />
                            <span className="text-xs">{order.partner.rating}</span>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                  
                  {/* Skills */}
                  <div className="flex flex-wrap gap-1 mb-3">
                    {order.skills.map(skill => (
                      <Badge key={skill} variant="outline" className="text-xs">
                        {skill}
                      </Badge>
                    ))}
                  </div>
                  
                  {/* Amount and Deadline */}
                  <div className="flex items-center gap-4 text-sm text-gray-600 mb-3">
                    <div className="flex items-center gap-1">
                      <DollarSign className="w-4 h-4" />
                      <span className="font-semibold text-orange-500">¥{order.amount}</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <Clock className="w-4 h-4" />
                      <span>截止: {order.deadline}</span>
                    </div>
                  </div>
                  
                  {/* Action Buttons */}
                  <div className="flex gap-2">
                    <Button 
                      variant="outline" 
                      size="sm" 
                      className="flex-1"
                      onClick={() => setSelectedOrder(order)}
                    >
                      查看详情
                      <ChevronRight className="w-4 h-4 ml-1" />
                    </Button>
                    
                    <Button 
                      variant="ghost" 
                      size="sm"
                      onClick={() => handleContactPartner(order.partner.id)}
                    >
                      <MessageCircle className="w-4 h-4" />
                    </Button>
                    
                    {/* Status-specific actions */}
                    {order.status === 'submitted' && activeTab === 'posted' && (
                      <Button 
                        variant="default" 
                        size="sm"
                        onClick={() => handleAcceptOrder(order)}
                        className="bg-green-600 hover:bg-green-700"
                      >
                        验收
                      </Button>
                    )}
                    
                    {order.status === 'completed' && (
                      <Button 
                        variant="outline" 
                        size="sm"
                        onClick={() => handleReviewOrder(order)}
                      >
                        <Star className="w-4 h-4" />
                      </Button>
                    )}
                  </div>
                </Card>
              </motion.div>
            );
          })
        )}
      </div>
      
      {/* Order Detail Modal */}
      <AnimatePresence>
        {selectedOrder && (
          <OrderDetailView
            orderId={selectedOrder.id}
            onBack={() => setSelectedOrder(null)}
          />
        )}
      </AnimatePresence>
      
      {/* Review Dialog */}
      {showReviewDialog && reviewingOrder && (
        <ReviewDialog
          orderId={reviewingOrder.id}
          isOpen={showReviewDialog}
          onClose={() => {
            setShowReviewDialog(false);
            setReviewingOrder(null);
          }}
          onSubmit={handleSubmitReview}
          partnerName={reviewingOrder.partner.name}
        />
      )}
    </div>
  );
}
