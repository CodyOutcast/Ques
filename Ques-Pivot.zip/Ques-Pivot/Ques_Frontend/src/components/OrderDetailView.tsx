import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { 
  ArrowLeft, 
  User, 
  FileText, 
  DollarSign, 
  Clock, 
  CheckCircle,
  AlertTriangle,
  Download,
  ExternalLink
} from 'lucide-react';
import { ReviewDialog } from './ReviewDialog';

interface OrderDetailViewProps {
  orderId: string;
  onBack: () => void;
}

export function OrderDetailView({ orderId, onBack }: OrderDetailViewProps) {
  const [showReviewDialog, setShowReviewDialog] = useState(false);
  
  // Mock data - will be replaced with API
  const order = {
    id: orderId,
    taskTitle: 'PPT模板设计',
    status: 'submitted' as const,
    amount: 150,
    deadline: '2025-10-25',
    createdAt: '2025-10-20',
    description: '需要一套商务风格的PPT模板，包含封面、目录、内容页等',
    skills: ['PPT设计', 'Photoshop', '平面设计'],
    partner: {
      id: 'user1',
      name: '张三',
      avatar: '👨‍💻',
      rating: 4.8,
      completedTasks: 23
    },
    deliverables: [
      {
        id: '1',
        filename: 'business_template_v1.pptx',
        url: '#',
        uploadedAt: '2025-10-23 14:30'
      },
      {
        id: '2',
        filename: 'preview_images.zip',
        url: '#',
        uploadedAt: '2025-10-23 14:32'
      }
    ],
    isFreelancer: false // Current user role in this order
  };
  
  const getStatusBadge = (status: string) => {
    const statusMap: Record<string, { label: string; variant: any; color: string }> = {
      'pending_payment': { label: '待支付', variant: 'secondary', color: 'text-orange-600' },
      'in_progress': { label: '进行中', variant: 'default', color: 'text-blue-600' },
      'submitted': { label: '待验收', variant: 'default', color: 'text-purple-600' },
      'completed': { label: '已完成', variant: 'outline', color: 'text-green-600' },
      'disputed': { label: '申诉中', variant: 'destructive', color: 'text-red-600' }
    };
    
    const config = statusMap[status] || { label: '未知', variant: 'outline', color: 'text-gray-600' };
    return <Badge variant={config.variant} className={config.color}>{config.label}</Badge>;
  };
  
  const handleApprove = () => {
    // API call to approve order
    console.log('Approving order:', orderId);
    setShowReviewDialog(true);
  };
  
  const handleReport = () => {
    // Navigate to report page
    console.log('Report order:', orderId);
  };
  
  const handleReviewSubmit = (rating: number) => {
    // API call to submit review
    console.log('Submitting review:', { orderId, rating });
  };
  
  return (
    <div className="h-full flex flex-col bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b px-4 py-3 flex items-center gap-3">
        <button onClick={onBack} className="p-1">
          <ArrowLeft className="w-5 h-5" />
        </button>
        <div className="flex-1">
          {getStatusBadge(order.status)}
          <h1 className="text-lg font-semibold mt-1">{order.taskTitle}</h1>
        </div>
      </div>
      
      {/* Content */}
      <div className="flex-1 overflow-y-auto p-4 space-y-3 pb-24">
        {/* Task Info Card */}
        <Card className="p-4">
          <div className="flex items-start gap-3 mb-3">
            <div className="w-10 h-10 rounded-full bg-blue-100 flex items-center justify-center flex-shrink-0">
              <FileText className="w-5 h-5 text-blue-600" />
            </div>
            <div className="flex-1">
              <h3 className="font-semibold mb-1">任务信息</h3>
              <p className="text-sm text-gray-600 mb-3">{order.description}</p>
              
              <div className="flex flex-wrap gap-2 mb-3">
                {order.skills.map((skill, index) => (
                  <Badge key={index} variant="secondary" className="text-xs">
                    {skill}
                  </Badge>
                ))}
              </div>
              
              <div className="grid grid-cols-2 gap-3 text-sm">
                <div className="flex items-center gap-2">
                  <DollarSign className="w-4 h-4 text-gray-400" />
                  <span className="text-gray-600">金额:</span>
                  <span className="font-semibold text-orange-600">¥{order.amount}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Clock className="w-4 h-4 text-gray-400" />
                  <span className="text-gray-600">截止:</span>
                  <span className="font-semibold">{order.deadline}</span>
                </div>
              </div>
            </div>
          </div>
        </Card>
        
        {/* Partner Info Card */}
        <Card 
          className="p-4 cursor-pointer hover:shadow-md transition-shadow"
          onClick={() => console.log('View partner profile')}
        >
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-full bg-gray-100 flex items-center justify-center text-2xl">
              {order.partner.avatar}
            </div>
            <div className="flex-1">
              <div className="flex items-center gap-2 mb-1">
                <h3 className="font-semibold">{order.partner.name}</h3>
                <Badge variant="outline" className="text-xs">
                  {order.isFreelancer ? '发单者' : '接单者'}
                </Badge>
              </div>
              <div className="flex items-center gap-3 text-xs text-gray-500">
                <span>⭐ {order.partner.rating.toFixed(1)}</span>
                <span>✅ {order.partner.completedTasks}单</span>
              </div>
            </div>
            <ExternalLink className="w-4 h-4 text-gray-400" />
          </div>
        </Card>
        
        {/* Deliverables Card (if submitted) */}
        {order.status === 'submitted' && order.deliverables.length > 0 && (
          <Card className="p-4">
            <div className="flex items-start gap-3">
              <div className="w-10 h-10 rounded-full bg-green-100 flex items-center justify-center flex-shrink-0">
                <CheckCircle className="w-5 h-5 text-green-600" />
              </div>
              <div className="flex-1">
                <h3 className="font-semibold mb-3">交付物</h3>
                <div className="space-y-2">
                  {order.deliverables.map(file => (
                    <div 
                      key={file.id}
                      className="flex items-center justify-between p-3 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors"
                    >
                      <div className="flex-1">
                        <p className="text-sm font-medium">{file.filename}</p>
                        <p className="text-xs text-gray-500 mt-1">{file.uploadedAt}</p>
                      </div>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => console.log('Download', file.id)}
                      >
                        <Download className="w-4 h-4" />
                      </Button>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </Card>
        )}
      </div>
      
      {/* ✅ 极简验收流程: 只有"验收通过"和"举报"两个按钮 */}
      {order.status === 'submitted' && !order.isFreelancer && (
        <div className="fixed bottom-0 left-0 right-0 bg-white border-t p-4 pb-safe flex gap-3">
          <Button 
            variant="default"
            className="flex-1"
            onClick={handleApprove}
          >
            <CheckCircle className="w-4 h-4 mr-2" />
            验收通过
          </Button>
          
          <Button 
            variant="outline"
            onClick={handleReport}
          >
            <AlertTriangle className="w-4 h-4 mr-2" />
            举报
          </Button>
        </div>
      )}
      
      {/* Review Dialog */}
      <ReviewDialog
        isOpen={showReviewDialog}
        onClose={() => setShowReviewDialog(false)}
        orderId={order.id}
        partnerName={order.partner.name}
        onSubmit={handleReviewSubmit}
      />
    </div>
  );
}
