/**
 * NotificationPanel - 任务申请通知面板
 * 
 * 适配说明：已从"好友请求"改为"任务申请通知"
 * 
 * 三种通知类型：
 * 1. poster_receives_application - 发单者收到接单者的申请（待处理）
 *    - 显示"接受申请"和"拒绝"按钮
 *    - 可点击查看申请者完整档案
 * 
 * 2. freelancer_receives_invitation - 接单者收到发单者的邀请（待处理）
 *    - 显示"接受邀请"和"拒绝"按钮
 *    - 可点击查看发单者档案和任务详情
 * 
 * 3. freelancer_accepted - 接单者的申请被发单者接受（通知）
 *    - 显示"联系对方"按钮，跳转到消息页面
 *    - 可点击查看任务发布者档案和任务详情
 * 
 * API集成说明：
 * - onAcceptApplication: 接受申请/邀请的API调用
 *   示例: POST /api/tasks/{taskId}/applications/{applicationId}/accept
 * - onQuoteContact: 联系对方，应跳转到消息页面
 *   示例: navigate(`/messages/${conversationId}`)
 * 
 * 数据来源：
 * - friendRequests数组应从 GET /api/notifications/task-applications 获取
 * - 每个通知包含申请者/发单者信息、任务信息、申请留言等
 * 
 * Mock Data示例见文件末尾
 */

import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Quote, User, Copy, MessageCircle, Check, Eye, Gift, Share2, ChevronDown, ChevronUp, MessageSquare, CheckCircle, XCircle, FileText } from 'lucide-react';
import { Button } from './ui/button';
import { Card } from './ui/card';
import { toast } from 'sonner';
import { useLanguage } from '../contexts/LanguageContext';
import { WhisperMessageDialog } from './WhisperMessageDialog';
import { calculateAge } from '../utils/dateUtils';

// 任务申请通知类型
export type ApplicationType = 
  | 'poster_receives_application'  // 发单者收到接单者的申请
  | 'freelancer_receives_invitation' // 接单者收到发单者的邀请
  | 'freelancer_accepted';           // 接单者的申请被接受

// 任务申请通知接口（适配pivot）
export interface TaskApplicationNotification {
  id: string;
  name: string; // 申请者或发单者姓名
  birthday: string;
  gender: string;
  avatar: string;
  location: string;
  hobbies: string[];
  languages: string[];
  skills: string[];
  resources: string[];
  projects: { 
    title: string; 
    role: string; 
    description: string; 
    referenceLinks: string[] 
  }[];
  institutions: { 
    name: string; 
    role: string; 
    description: string; 
    verified: boolean;
  }[];
  university?: {
    name: string;
    verified: boolean;
  };
  bio: string;
  oneSentenceIntro?: string;
  requestedAt: Date;
  
  // 任务相关字段
  applicationType: ApplicationType; // 通知类型
  taskId: string; // 任务ID
  taskTitle: string; // 任务标题
  taskDescription?: string; // 任务描述
  taskBudget?: number; // 任务预算
  applicationMessage?: string; // 申请留言
  wechatId?: string; // 微信号（接受后显示）
  
  // 统计数据
  completionRate?: number; // 完成率
  rating?: number; // 评分
  completedTasks?: number; // 完成任务数
}

// 为了向后兼容，保留FriendRequest类型别名
export type FriendRequest = TaskApplicationNotification;

interface NotificationPanelProps {
  isOpen: boolean;
  onClose: () => void;
  friendRequests: FriendRequest[];
  onQuoteContact: (contact: FriendRequest) => void;
  onRemoveRequest: (requestId: string) => void;
  onAddToHistory: (request: FriendRequest, message?: string) => void;
  onViewOriginalCard?: (contact: FriendRequest) => void;
  onGiftReceives?: (recipientName: string, amount: number) => void;
  whispersLeft?: number;
  onWhisperSent?: () => void;
  // 新增任务相关回调
  onAcceptApplication?: (applicationId: string, taskId: string) => Promise<void>;
  onViewTaskDetail?: (taskId: string) => void;
}

export function NotificationPanel({ 
  isOpen, 
  onClose, 
  friendRequests, 
  onQuoteContact,
  onRemoveRequest,
  onAddToHistory,
  onViewOriginalCard,
  onGiftReceives,
  whispersLeft = 0,
  onWhisperSent,
  onAcceptApplication,
  onViewTaskDetail
}: NotificationPanelProps) {
  const { t } = useLanguage();
  const [selectedCardId, setSelectedCardId] = useState<string | null>(null);
  
  // Debug: Log notifications to verify fields
  useEffect(() => {
    if (friendRequests.length > 0) {
      console.log('Task Application Notifications:', friendRequests.map(r => ({ 
        name: r.name, 
        applicationType: r.applicationType,
        taskTitle: r.taskTitle,
        hasMessage: !!r.applicationMessage
      })));
    }
  }, [friendRequests]);
  const [animatingRequests, setAnimatingRequests] = useState<Set<string>>(new Set());
  const [copiedIds, setCopiedIds] = useState<Set<string>>(new Set());
  const [viewingProfile, setViewingProfile] = useState<FriendRequest | null>(null);
  const [showFullProfile, setShowFullProfile] = useState(false);
  const [showGiftModal, setShowGiftModal] = useState(false);
  const [selectedForGift, setSelectedForGift] = useState<FriendRequest | null>(null);
  const [giftAmount, setGiftAmount] = useState('');
  const [showWhisperDialog, setShowWhisperDialog] = useState(false);
  const [pendingWhisperRequest, setPendingWhisperRequest] = useState<FriendRequest | null>(null);

  const formatTimeAgo = (date: Date) => {
    const now = new Date();
    const diffInHours = Math.floor((now.getTime() - date.getTime()) / (1000 * 60 * 60));
    
    if (diffInHours < 1) return t('notifications.justNow');
    if (diffInHours < 24) return `${diffInHours}${t('notifications.hoursAgo')}`;
    const diffInDays = Math.floor(diffInHours / 24);
    return `${diffInDays}${t('notifications.daysAgo')}`;
  };

  const handleCardClick = (requestId: string) => {
    setSelectedCardId(selectedCardId === requestId ? null : requestId);
  };

  const handleQuoteContact = (request: FriendRequest) => {
    onQuoteContact(request);
    setSelectedCardId(null);
  };

  const handleCopyWechatId = (wechatId: string, name: string, requestId: string) => {
    navigator.clipboard.writeText(wechatId);
    toast.success(`${t('notifications.copied')} ${name}'s WeChat ID`);
    
    // Add copy animation
    setCopiedIds(prev => new Set(prev).add(requestId));
    setTimeout(() => {
      setCopiedIds(prev => {
        const newSet = new Set(prev);
        newSet.delete(requestId);
        return newSet;
      });
    }, 1000);
  };

  const handleWhisperBack = (request: FriendRequest) => {
    // Show whisper dialog before sending
    setPendingWhisperRequest(request);
    setShowWhisperDialog(true);
  };

  const handleAcceptApplication = async (request: TaskApplicationNotification) => {
    // Accept the task application
    if (!onAcceptApplication) {
      toast.error('接受申请功能未配置');
      return;
    }

    try {
      setAnimatingRequests(prev => new Set(prev).add(request.id));
      
      // 调用API接受申请
      await onAcceptApplication(request.id, request.taskId);
      
      setTimeout(() => {
        toast.success(`已接受 ${request.name} 的申请`, {
          description: '任务已确认，请在消息中与对方沟通详情'
        });
        
        // Add to contact history/order list
        onAddToHistory(request, '申请已接受');
        
        setAnimatingRequests(prev => {
          const newSet = new Set(prev);
          newSet.delete(request.id);
          return newSet;
        });
        
        onRemoveRequest(request.id);
      }, 2500);
    } catch (error) {
      setAnimatingRequests(prev => {
        const newSet = new Set(prev);
        newSet.delete(request.id);
        return newSet;
      });
      toast.error('接受申请失败', {
        description: error instanceof Error ? error.message : '请稍后重试'
      });
    }
  };

  const handleViewTask = (request: TaskApplicationNotification) => {
    // 查看任务详情
    if (onViewTaskDetail) {
      onViewTaskDetail(request.taskId);
      setSelectedCardId(null);
    } else {
      // Fallback: 使用现有的查看档案功能
      toast.info(`任务: ${request.taskTitle}`, {
        description: '点击查看完整任务详情'
      });
      onQuoteContact(request);
      setSelectedCardId(null);
    }
  };

  const handleWhisperSend = (message: string) => {
    if (!pendingWhisperRequest) return;

    // Check if user has whispers left
    if (whispersLeft <= 0) {
      toast.error('You have no whispers left this month. Please upgrade to Pro or wait for next month.');
      setShowWhisperDialog(false);
      setPendingWhisperRequest(null);
      return;
    }

    // Decrease whisper count
    onWhisperSent?.();
    console.log('💬 Whisper back sent! Whispers left:', whispersLeft - 1);

    // Add to animating requests set to trigger animation
    setAnimatingRequests(prev => new Set(prev).add(pendingWhisperRequest.id));
    setShowWhisperDialog(false);
    
    // Wait for animation to complete, then remove the request permanently
    setTimeout(() => {
      toast.success(`${t('notifications.whisperBackSuccess')} ${pendingWhisperRequest.name}`);
      
      // Add to contact history before removing (with message)
      onAddToHistory(pendingWhisperRequest, message);
      
      // Remove from animating set and remove from requests list
      setAnimatingRequests(prev => {
        const newSet = new Set(prev);
        newSet.delete(pendingWhisperRequest.id);
        return newSet;
      });
      
      // Remove the request from the parent state
      onRemoveRequest(pendingWhisperRequest.id);
      setPendingWhisperRequest(null);
    }, 2500);
  };

  const handleWhisperDialogClose = () => {
    setShowWhisperDialog(false);
    setPendingWhisperRequest(null);
  };

  const handleViewOriginalCard = (request: FriendRequest) => {
    setViewingProfile(request);
    setSelectedCardId(null);
    setShowFullProfile(false);
  };

  const closeProfileView = () => {
    setViewingProfile(null);
    setShowFullProfile(false);
  };

  const toggleExtendedProfile = () => {
    setShowFullProfile(!showFullProfile);
  };

  const handleShareProfile = () => {
    if (viewingProfile) {
      console.log('Sharing profile:', viewingProfile.name);
    }
  };

  const openGiftModal = (request: FriendRequest) => {
    setSelectedForGift(request);
    setGiftAmount('');
    setShowGiftModal(true);
  };

  const handleGiftConfirm = () => {
    if (selectedForGift && giftAmount && onGiftReceives) {
      const amount = parseInt(giftAmount);
      if (amount > 0) {
        onGiftReceives(selectedForGift.name, amount);
        setShowGiftModal(false);
        setSelectedForGift(null);
        setGiftAmount('');
      }
    }
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/20 z-50"
            onClick={onClose}
          />
          
          {/* Panel */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 20 }}
            transition={{ duration: 0.3 }}
            className="fixed inset-x-4 top-16 bottom-20 bg-white rounded-lg shadow-2xl z-50 flex flex-col max-w-sm mx-auto"
          >
            {/* Header */}
            <div className="flex items-center justify-between p-4 border-b border-gray-200">
              <h2 className="text-lg font-medium">任务申请通知</h2>
              <Button 
                variant="ghost" 
                size="sm"
                onClick={onClose}
                className="h-8 w-8 p-0"
              >
                <X size={16} />
              </Button>
            </div>

            {/* Content */}
            <div className="flex-1 overflow-y-auto" onClick={() => setSelectedCardId(null)}>
              {friendRequests.length === 0 ? (
                <div className="flex flex-col items-center justify-center h-full text-center px-6">
                  <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mb-4">
                    <FileText size={24} className="text-gray-400" />
                  </div>
                  <h3 className="text-base font-medium text-gray-600 mb-2">暂无通知</h3>
                  <p className="text-sm text-gray-500">
                    当有人申请你的任务或接受你的申请时，会在这里显示
                  </p>
                </div>
              ) : (
                <div className="p-3 space-y-2">
                  <AnimatePresence mode="popLayout">
                    {friendRequests.map((request) => (
                      <motion.div
                        key={request.id}
                        layout
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ 
                          opacity: animatingRequests.has(request.id) ? [1, 1, 0] : 1, 
                          y: animatingRequests.has(request.id) ? [0, 0, 20] : 0,
                          scale: animatingRequests.has(request.id) ? [1, 0.95, 0.8] : 1
                        }}
                        exit={{ opacity: 0, y: -10, scale: 0.95 }}
                        transition={{ 
                          duration: animatingRequests.has(request.id) ? 2.5 : 0.3, 
                          times: animatingRequests.has(request.id) ? [0, 0.6, 1] : undefined,
                          ease: "easeInOut",
                          layout: { duration: 0.3, ease: "easeInOut" }
                        }}
                        className="relative"
                      >
                        <Card 
                          className={`p-3 hover:shadow-md transition-all cursor-pointer relative overflow-hidden ${
                            selectedCardId === request.id ? 'blur-sm' : ''
                          } ${animatingRequests.has(request.id) ? 'opacity-50' : ''}`}
                          onClick={(e) => {
                            e.stopPropagation();
                            if (!animatingRequests.has(request.id)) {
                              handleCardClick(request.id);
                            }
                          }}
                        >
                          {/* Blur overlay with checkmark for animating requests */}
                          <AnimatePresence>
                            {animatingRequests.has(request.id) && (
                              <motion.div
                                initial={{ opacity: 0 }}
                                animate={{ opacity: 1 }}
                                exit={{ opacity: 0 }}
                                transition={{ duration: 0.3 }}
                                className="absolute inset-0 bg-white/90 flex items-center justify-center z-20"
                                style={{ 
                                  backdropFilter: 'blur(4px)',
                                  WebkitBackdropFilter: 'blur(4px)'
                                }}
                              >
                                <motion.div
                                  initial={{ scale: 0, rotate: 0 }}
                                  animate={{ scale: 1, rotate: 360 }}
                                  transition={{ 
                                    duration: 0.6,
                                    ease: "easeOut"
                                  }}
                                  className="w-12 h-12 bg-blue-500 rounded-full flex items-center justify-center shadow-2xl"
                                >
                                  <Check size={20} className="text-white" />
                                </motion.div>
                              </motion.div>
                            )}
                          </AnimatePresence>
                          
                          <div className="text-center">
                            {/* Profile Picture */}
                            <div className="w-12 h-12 bg-gray-200 rounded-full flex items-center justify-center text-lg mx-auto mb-2">
                              {request.avatar}
                            </div>
                            
                            {/* Name and Time */}
                            <div className="flex items-center justify-center gap-2 mb-1">
                              <h3 className="text-sm font-medium">{request.name}</h3>
                              <span className="text-xs text-gray-500">
                                {formatTimeAgo(request.requestedAt)}
                              </span>
                            </div>
                            
                            {/* Task Title and Type Badge */}
                            <div className="mb-2">
                              <div className="flex items-center justify-center gap-2 mb-1">
                                <FileText size={12} className="text-blue-600" />
                                <p className="text-xs font-medium text-gray-700">{request.taskTitle}</p>
                              </div>
                              <div className="inline-flex items-center gap-1 px-2 py-1 rounded-full text-xs font-medium" 
                                style={{
                                  backgroundColor: 
                                    request.applicationType === 'poster_receives_application' ? '#FEF3C7' :
                                    request.applicationType === 'freelancer_receives_invitation' ? '#FECACA' :
                                    '#DBEAFE',
                                  color: 
                                    request.applicationType === 'poster_receives_application' ? '#92400E' :
                                    request.applicationType === 'freelancer_receives_invitation' ? '#991B1B' :
                                    '#1E40AF'
                                }}
                              >
                                {request.applicationType === 'poster_receives_application' 
                                  ? '🔔 待处理申请'
                                  : request.applicationType === 'freelancer_receives_invitation'
                                  ? '📨 收到邀请'
                                  : '✅ 申请已接受'
                                }
                              </div>
                            </div>
                            
                            {/* Application Message Section */}
                            {request.applicationMessage && (
                              <div className="bg-blue-50 border border-blue-200 rounded-lg p-2 mb-2">
                                <div className="flex items-start gap-2">
                                  <MessageSquare size={14} className="text-blue-600 mt-0.5 flex-shrink-0" />
                                  <div className="flex-1 min-w-0">
                                    <p className="text-xs text-blue-600 mb-1 font-medium">
                                      {request.applicationType === 'poster_receives_application' 
                                        ? `${request.name} 的申请留言`
                                        : request.applicationType === 'freelancer_receives_invitation'
                                        ? `${request.name} 邀请你`
                                        : `${request.name} 说`
                                      }
                                    </p>
                                    <p className="text-xs text-blue-900 leading-relaxed break-words">{request.applicationMessage}</p>
                                  </div>
                                </div>
                              </div>
                            )}
                            
                            {/* Task Budget (if available) */}
                            {request.taskBudget && (
                              <div className="bg-green-50 rounded-lg p-2 mb-2">
                                <p className="text-xs text-gray-500 mb-1">任务预算</p>
                                <p className="text-sm font-medium text-green-700">¥{request.taskBudget}</p>
                              </div>
                            )}
                            
                            {/* User Stats (显示对方统计) */}
                            {(request.completionRate !== undefined || request.rating !== undefined || request.completedTasks !== undefined) && (
                              <div className="flex items-center justify-center gap-4 text-xs text-gray-600 mb-2">
                                {request.completionRate !== undefined && (
                                  <div className="flex items-center gap-1">
                                    <span>完成率:</span>
                                    <span className="font-semibold text-green-600">{request.completionRate}%</span>
                                  </div>
                                )}
                                {request.rating !== undefined && (
                                  <div className="flex items-center gap-1">
                                    <span>评分:</span>
                                    <span className="font-semibold text-yellow-600">{request.rating}/5</span>
                                  </div>
                                )}
                                {request.completedTasks !== undefined && (
                                  <div className="flex items-center gap-1">
                                    <span>已完成:</span>
                                    <span className="font-semibold text-blue-600">{request.completedTasks}单</span>
                                  </div>
                                )}
                              </div>
                            )}
                            
                            {/* Action Buttons */}
                            <div className="flex gap-2">
                              {request.applicationType === 'poster_receives_application' ? (
                                // 发单者看到申请 - 显示接受/拒绝按钮
                                <>
                                  <Button
                                    variant="default"
                                    size="sm"
                                    className={`flex-1 h-8 text-xs transition-all duration-300 bg-green-500 hover:bg-green-600 ${
                                      animatingRequests.has(request.id) 
                                        ? 'bg-green-600' 
                                        : ''
                                    }`}
                                    disabled={animatingRequests.has(request.id)}
                                    onClick={(e: React.MouseEvent) => {
                                      e.stopPropagation();
                                      handleAcceptApplication(request);
                                    }}
                                  >
                                    <CheckCircle size={12} className="mr-1" />
                                    {animatingRequests.has(request.id) ? '处理中...' : '接受申请'}
                                  </Button>
                                  <Button
                                    variant="outline"
                                    size="sm"
                                    className="flex-1 h-8 text-xs border-red-200 text-red-600 hover:bg-red-50"
                                    onClick={(e: React.MouseEvent) => {
                                      e.stopPropagation();
                                      onRemoveRequest(request.id);
                                      toast.success('已拒绝申请');
                                    }}
                                  >
                                    <XCircle size={12} className="mr-1" />
                                    拒绝
                                  </Button>
                                </>
                              ) : request.applicationType === 'freelancer_receives_invitation' ? (
                                // 接单者收到邀请 - 显示接受/拒绝按钮
                                <>
                                  <Button
                                    variant="default"
                                    size="sm"
                                    className={`flex-1 h-8 text-xs transition-all duration-300 bg-green-500 hover:bg-green-600 ${
                                      animatingRequests.has(request.id) 
                                        ? 'bg-green-600' 
                                        : ''
                                    }`}
                                    disabled={animatingRequests.has(request.id)}
                                    onClick={(e: React.MouseEvent) => {
                                      e.stopPropagation();
                                      handleAcceptApplication(request);
                                    }}
                                  >
                                    <CheckCircle size={12} className="mr-1" />
                                    {animatingRequests.has(request.id) ? '处理中...' : '接受邀请'}
                                  </Button>
                                  <Button
                                    variant="outline"
                                    size="sm"
                                    className="flex-1 h-8 text-xs border-red-200 text-red-600 hover:bg-red-50"
                                    onClick={(e: React.MouseEvent) => {
                                      e.stopPropagation();
                                      onRemoveRequest(request.id);
                                      toast.success('已拒绝邀请');
                                    }}
                                  >
                                    <XCircle size={12} className="mr-1" />
                                    拒绝
                                  </Button>
                                </>
                              ) : (
                                // 申请被接受 - 显示联系对方按钮（跳转到消息页面）
                                <Button
                                  variant="default"
                                  size="sm"
                                  className="flex-1 h-8 text-xs bg-blue-500 hover:bg-blue-600"
                                  onClick={(e: React.MouseEvent) => {
                                    e.stopPropagation();
                                    onQuoteContact(request);
                                  }}
                                >
                                  <MessageCircle size={12} className="mr-1" />
                                  联系对方
                                </Button>
                              )}
                            </div>
                          </div>
                        </Card>
                        
                        {/* Floating Action Buttons */}
                        {selectedCardId === request.id && !animatingRequests.has(request.id) && (
                          <motion.div
                            initial={{ opacity: 0, scale: 0.8 }}
                            animate={{ opacity: 1, scale: 1 }}
                            className="absolute inset-0 flex items-center justify-center z-10 bg-black/20 backdrop-blur-sm rounded-lg"
                            onClick={() => setSelectedCardId(null)}
                          >
                            <div className="flex gap-3" onClick={(e: React.MouseEvent) => e.stopPropagation()}>
                              {/* View Original Card Button */}
                              {onViewOriginalCard && (
                                <Button
                                  size="lg"
                                  variant="outline"
                                  className="rounded-full w-14 h-14 p-0 bg-white hover:bg-purple-50 shadow-lg border-purple-200"
                                  onClick={(e: React.MouseEvent) => {
                                    e.stopPropagation();
                                    handleViewOriginalCard(request);
                                  }}
                                >
                                  <Eye size={18} className="text-purple-600" />
                                </Button>
                              )}
                              
                              {/* Contact Button (formerly Quote) */}
                              <Button
                                size="lg"
                                className="rounded-full w-14 h-14 p-0 bg-blue-500 hover:bg-blue-600 shadow-lg"
                                onClick={(e: React.MouseEvent) => {
                                  e.stopPropagation();
                                  handleQuoteContact(request);
                                }}
                              >
                                <MessageCircle size={18} />
                              </Button>
                              
                              {/* Remove Button */}
                              <Button
                                size="lg"
                                variant="outline"
                                className="rounded-full w-14 h-14 p-0 bg-white hover:bg-gray-50 shadow-lg border-gray-200"
                                onClick={(e: React.MouseEvent) => {
                                  e.stopPropagation();
                                  onRemoveRequest(request.id);
                                  setSelectedCardId(null);
                                }}
                              >
                                <X size={18} className="text-gray-600" />
                              </Button>
                            </div>
                          </motion.div>
                        )}
                      </motion.div>
                    ))}
                  </AnimatePresence>
                </div>
              )}
            </div>
          </motion.div>

          {/* Profile Card Modal */}
          <AnimatePresence>
            {viewingProfile && (
              <>
                {/* Modal Backdrop */}
                <motion.div
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50"
                  style={{ zIndex: 120 }}
                  onClick={closeProfileView}
                />
                
                {/* Profile Card */}
                <motion.div
                  initial={{ opacity: 0, scale: 0.9, y: 20 }}
                  animate={{ opacity: 1, scale: 1, y: 0 }}
                  exit={{ opacity: 0, scale: 0.9, y: 20 }}
                  transition={{ duration: 0.3, ease: "easeInOut" }}
                  className="fixed inset-0 flex items-center justify-center z-50 p-4"
                  style={{ zIndex: 130 }}
                  onClick={closeProfileView}
                >
                  <div
                    className="relative bg-white rounded-2xl shadow-xl border border-gray-100 overflow-hidden"
                    style={{ width: '300px', height: '400px' }}
                    onClick={(e) => e.stopPropagation()}
                  >
                    <AnimatePresence mode="wait">
                      {!showFullProfile ? (
                        /* Collapsed Card View */
                        <motion.div
                          key="collapsed"
                          initial={{ opacity: 0 }}
                          animate={{ opacity: 1 }}
                          exit={{ opacity: 0 }}
                          transition={{ duration: 0.3, ease: "easeInOut" }}
                          className="relative w-full h-full"
                        >
                          {/* Profile Background */}
                          <div className="relative w-full h-full flex items-center justify-center">
                            <div className="text-9xl select-none" style={{ fontSize: '12rem', lineHeight: '1' }}>
                              {viewingProfile.avatar}
                            </div>
                            <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-transparent to-transparent" />
                          </div>

                          {/* Bottom content area */}
                          <div className="absolute bottom-0 left-0 right-0 p-6 text-white z-30">
                            <div className="flex items-center justify-between mb-2">
                              <h2 className="text-lg font-bold">
                                {viewingProfile.name}
                              </h2>
                              <div className="flex gap-2 relative z-50">
                                <button
                                  onClick={handleShareProfile}
                                  className="p-2 bg-white/20 backdrop-blur-sm rounded-full hover:bg-white/30 transition-colors relative z-50"
                                >
                                  <Share2 size={16} />
                                </button>
                                <button
                                  onClick={toggleExtendedProfile}
                                  className="p-2 bg-blue-500 rounded-full hover:bg-blue-600 transition-colors relative z-50"
                                >
                                  <ChevronDown size={16} />
                                </button>
                              </div>
                            </div>
                            <p className="text-white/90 text-xs line-clamp-1 mb-3">
                              {viewingProfile.oneSentenceIntro || viewingProfile.bio}
                            </p>
                            
                            {/* User Stats - integrated as last line in collapsed view */}
                            <div className="absolute bottom-4 left-0 right-0 px-6 text-white text-xs z-40">
                              <div className="flex items-center justify-between">
                                <div className="flex items-center gap-3">
                                  {viewingProfile.completionRate !== undefined && (
                                    <div className="flex items-center gap-1">
                                      <span className="font-medium">完成率:</span>
                                      <span className="font-bold">{viewingProfile.completionRate}%</span>
                                    </div>
                                  )}
                                  {viewingProfile.rating !== undefined && (
                                    <div className="flex items-center gap-1">
                                      <span className="font-medium">评分:</span>
                                      <span className="font-bold">{viewingProfile.rating}/5</span>
                                    </div>
                                  )}
                                </div>
                              </div>
                            </div>
                          </div>
                        </motion.div>
                      ) : (
                        /* Expanded Card View */
                        <motion.div
                          key="expanded"
                          initial={{ opacity: 0 }}
                          animate={{ opacity: 1 }}
                          exit={{ opacity: 0 }}
                          transition={{ duration: 0.3, ease: "easeInOut" }}
                          className="relative w-full h-full flex flex-col"
                        >
                          {/* Header with avatar and basic info */}
                          <div className="bg-gray-50 p-4 border-b border-gray-200 flex-shrink-0 relative" style={{ height: '80px' }}>
                            <div className="flex items-center justify-between h-full">
                              <div className="flex items-center gap-3">
                                <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center text-2xl">
                                  {viewingProfile.avatar}
                                </div>
                                <div>
                                  <h3 className="font-semibold text-gray-900">{viewingProfile.name}</h3>
                                  <p className="text-sm text-gray-600">{viewingProfile.location} • {calculateAge(viewingProfile.birthday)}岁</p>
                                </div>
                              </div>
                              <div className="flex gap-2 relative z-50">
                                <button
                                  onClick={handleShareProfile}
                                  className="p-2 bg-white rounded-full shadow-sm hover:bg-gray-50 transition-colors relative z-50"
                                >
                                  <Share2 size={16} className="text-gray-600" />
                                </button>
                                <button
                                  onClick={toggleExtendedProfile}
                                  className="p-2 bg-blue-500 rounded-full hover:bg-blue-600 transition-colors relative z-50"
                                >
                                  <ChevronUp size={16} className="text-white" />
                                </button>
                              </div>
                            </div>
                          </div>

                          {/* Scrollable Content */}
                          <div 
                            className="flex-1 overflow-y-auto" 
                            style={{ height: 'calc(400px - 80px)' }}
                          >
                            <div className="p-4 space-y-4">
                              {/* Resources */}
                              <div>
                                <h4 className="font-semibold text-gray-900 text-sm mb-2">Resources</h4>
                                <div className="flex flex-wrap gap-1">
                                  {viewingProfile.resources.map((resource, index) => (
                                    <span key={index} className="px-2 py-1 bg-green-100 text-green-800 rounded-full text-xs">
                                      {resource}
                                    </span>
                                  ))}
                                </div>
                              </div>

                              {/* Skills */}
                              <div>
                                <h4 className="font-semibold text-gray-900 text-sm mb-2">Skills</h4>
                                <div className="flex flex-wrap gap-1">
                                  {viewingProfile.skills.map((skill, index) => (
                                    <span key={index} className="px-2 py-1 bg-blue-100 text-blue-800 rounded-full text-xs">
                                      {skill}
                                    </span>
                                  ))}
                                </div>
                              </div>

                              {/* Languages & Hobbies */}
                              <div className="grid grid-cols-2 gap-3">
                                <div>
                                  <h4 className="font-semibold text-gray-900 text-sm mb-2">Languages</h4>
                                  <div className="flex flex-wrap gap-1 overflow-x-hidden min-w-0">
                                    {viewingProfile.languages.map((language, index) => (
                                      <span key={index} className="px-2 py-1 bg-purple-100 text-purple-800 rounded-full text-xs max-w-full whitespace-normal break-all">
                                        {language}
                                      </span>
                                    ))}
                                  </div>
                                </div>
                                <div>
                                  <h4 className="font-semibold text-gray-900 text-sm mb-2">Hobbies</h4>
                                  <div className="flex flex-wrap gap-1 overflow-x-hidden min-w-0">
                                    {viewingProfile.hobbies.map((hobby, index) => (
                                      <span key={index} className="px-2 py-1 bg-pink-100 text-pink-800 rounded-full text-xs max-w-full whitespace-normal break-all">
                                        {hobby}
                                      </span>
                                    ))}
                                  </div>
                                </div>
                              </div>

                              {/* Projects */}
                              {viewingProfile.projects.length > 0 && (
                                <div>
                                  <h4 className="font-semibold text-gray-900 text-sm mb-2">Projects</h4>
                                  <div className="space-y-3">
                                    {viewingProfile.projects.map((project, index) => (
                                      <div key={index} className="bg-gray-50 rounded-lg p-3 border border-gray-200">
                                        <h5 className="font-medium text-gray-900 text-xs mb-1">{project.title}</h5>
                                        <p className="text-blue-600 text-xs mb-1">{project.role}</p>
                                        <p className="text-gray-700 text-xs mb-2 leading-relaxed">{project.description}</p>
                                        {project.referenceLinks.length > 0 && (
                                          <div className="space-y-1">
                                            {project.referenceLinks.map((link, linkIndex) => (
                                              <a 
                                                key={linkIndex} 
                                                href={link} 
                                                className="text-xs text-blue-500 block hover:underline break-all"
                                                target="_blank" 
                                                rel="noopener noreferrer"
                                              >
                                                {link}
                                              </a>
                                            ))}
                                          </div>
                                        )}
                                      </div>
                                    ))}
                                  </div>
                                </div>
                              )}

                              {/* User Stats */}
                              <div className="bg-gradient-to-r from-blue-50 to-indigo-50 rounded-lg p-3 border border-blue-200">
                                <h4 className="font-semibold text-gray-900 text-sm mb-3">接单统计</h4>
                                <div className="grid grid-cols-3 gap-3 text-center">
                                  {viewingProfile.completedTasks !== undefined && (
                                    <div>
                                      <p className="text-xs text-gray-600">已完成</p>
                                      <p className="text-lg font-bold text-blue-600">{viewingProfile.completedTasks}</p>
                                    </div>
                                  )}
                                  {viewingProfile.completionRate !== undefined && (
                                    <div>
                                      <p className="text-xs text-gray-600">完成率</p>
                                      <p className="text-lg font-bold text-green-600">{viewingProfile.completionRate}%</p>
                                    </div>
                                  )}
                                  {viewingProfile.rating !== undefined && (
                                    <div>
                                      <p className="text-xs text-gray-600">评分</p>
                                      <p className="text-lg font-bold text-yellow-600">{viewingProfile.rating}/5</p>
                                    </div>
                                  )}
                                </div>
                              </div>

                              {/* Institutions */}
                              {viewingProfile.institutions.length > 0 && (
                                <div>
                                  <h4 className="font-semibold text-gray-900 text-sm mb-2">Institutions</h4>
                                  <div className="space-y-3">
                                    {viewingProfile.institutions.map((institution, index) => (
                                      <div key={index} className="bg-gray-50 rounded-lg p-3 border border-gray-200">
                                        <h5 className="font-medium text-gray-900 text-xs mb-1">{institution.name}</h5>
                                        <p className="text-blue-600 text-xs mb-1">{institution.role}</p>
                                        <p className="text-gray-700 text-xs">{institution.description}</p>
                                      </div>
                                    ))}
                                  </div>
                                </div>
                              )}

                              {/* University */}
                              {viewingProfile.university && (
                                <div>
                                  <h4 className="font-semibold text-gray-900 text-sm mb-2">University</h4>
                                  <div className="bg-gradient-to-r from-blue-50 to-indigo-50 rounded-lg p-3 border border-blue-200">
                                    <div className="flex items-start justify-between gap-2 mb-1">
                                      <h5 className="font-medium text-gray-900 text-xs leading-tight flex-1 min-w-0 pr-2">
                                        {viewingProfile.university.name}
                                      </h5>
                                      {viewingProfile.university.verified && (
                                        <span className="text-blue-600 text-xs font-medium bg-blue-100 px-2 py-1 rounded-full whitespace-nowrap flex-shrink-0 flex items-center gap-1">
                                          <span>🎓</span>
                                          <span>Verified</span>
                                        </span>
                                      )}
                                    </div>
                                    <p className="text-blue-700 text-xs">Current University</p>
                                  </div>
                                </div>
                              )}
                            </div>
                          </div>
                        </motion.div>
                      )}
                    </AnimatePresence>
                  </div>
                </motion.div>
              </>
            )}
          </AnimatePresence>
        </>
      )}
      
      {/* Gift Modal */}
      <AnimatePresence>
        {showGiftModal && selectedForGift && (
          <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4" style={{ zIndex: 140 }}>
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-white rounded-2xl p-6 w-full max-w-sm"
            >
              <h3 className="font-semibold text-gray-900 mb-4">Gift Receives to {selectedForGift.name}</h3>
              <p className="text-sm text-gray-600 mb-4">How many receives would you like to send?</p>
              <div className="flex gap-2 mb-6">
                <input
                  type="number"
                  value={giftAmount}
                  onChange={(e) => setGiftAmount(e.target.value)}
                  min="1"
                  max="100"
                  className="flex-1 px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="Enter amount"
                />
              </div>
              <div className="flex gap-3">
                <button
                  onClick={() => setShowGiftModal(false)}
                  className="flex-1 px-4 py-2 bg-gray-100 rounded-lg hover:bg-gray-200 transition-colors"
                >
                  Cancel
                </button>
                <button
                  onClick={handleGiftConfirm}
                  disabled={!giftAmount || parseInt(giftAmount) < 1}
                  className="flex-1 px-4 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  Send Gift
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Whisper Message Dialog */}
      {pendingWhisperRequest && (
        <WhisperMessageDialog
          isOpen={showWhisperDialog}
          recipientName={pendingWhisperRequest.name}
          recipientAvatar={pendingWhisperRequest.avatar}
          onClose={handleWhisperDialogClose}
          onSend={handleWhisperSend}
        />
      )}
    </AnimatePresence>
  );
}

/**
 * ============================================================================
 * Mock Data 示例
 * ============================================================================
 * 
 * 用于测试的Mock数据，展示两种通知类型
 */

export const mockNotifications: TaskApplicationNotification[] = [
  // 示例1: 发单者收到接单者的申请
  {
    id: 'notif_1',
    name: '张小明',
    birthday: '2000-05-15',
    gender: 'male',
    avatar: '👨‍💻',
    location: '北京市海淀区',
    hobbies: ['编程', '设计', '摄影'],
    languages: ['中文', 'English'],
    skills: ['Python', 'React', 'UI设计', 'Figma'],
    resources: [],
    projects: [
      {
        title: '校园外卖小程序',
        role: '全栈开发',
        description: '独立开发的校园外卖平台，日活500+',
        referenceLinks: ['https://github.com/example']
      }
    ],
    institutions: [],
    university: {
      name: '清华大学',
      verified: true
    },
    bio: '计算机系大三学生，熟悉Web开发和UI设计',
    oneSentenceIntro: '全栈开发 + UI设计，接单经验丰富',
    requestedAt: new Date(Date.now() - 2 * 60 * 60 * 1000), // 2小时前
    
    // 任务相关
    applicationType: 'poster_receives_application',
    taskId: 'task_101',
    taskTitle: '帮忙设计一个活动海报',
    taskDescription: '学生会需要一张音乐节宣传海报',
    taskBudget: 150,
    applicationMessage: '你好！我之前设计过类似的海报，可以在2天内完成。我的作品集在profile里可以看到，风格偏年轻化和现代感。',
    
    // 统计数据
    completionRate: 95,
    rating: 4.8,
    completedTasks: 23
  },
  
  // 示例2: 发单者收到另一个接单者的申请
  {
    id: 'notif_2',
    name: '李晓红',
    birthday: '2001-08-20',
    gender: 'female',
    avatar: '👩‍🎨',
    location: '北京市朝阳区',
    hobbies: ['插画', '设计', '音乐'],
    languages: ['中文'],
    skills: ['Photoshop', 'Illustrator', '手绘'],
    resources: [],
    projects: [
      {
        title: '社团宣传物料设计',
        role: '视觉设计师',
        description: '为多个社团设计海报和周边',
        referenceLinks: []
      }
    ],
    institutions: [],
    university: {
      name: '北京大学',
      verified: true
    },
    bio: '美术学院学生，擅长海报设计',
    oneSentenceIntro: '专业海报设计师，风格多样',
    requestedAt: new Date(Date.now() - 30 * 60 * 1000), // 30分钟前
    
    applicationType: 'poster_receives_application',
    taskId: 'task_101',
    taskTitle: '帮忙设计一个活动海报',
    taskBudget: 150,
    applicationMessage: '我是美术学院的，经常帮社团设计海报！可以给你看看我之前做的作品～价格可以优惠到120元！',
    
    completionRate: 100,
    rating: 5.0,
    completedTasks: 15
  },
  
  // 示例3: 接单者收到发单者的邀请
  {
    id: 'notif_3',
    name: '王教授',
    birthday: '1985-03-10',
    gender: 'male',
    avatar: '👨‍🏫',
    location: '北京市海淀区',
    hobbies: ['学术研究', '教学'],
    languages: ['中文', 'English'],
    skills: [],
    resources: [],
    projects: [],
    institutions: [
      {
        name: '清华大学计算机系',
        role: '副教授',
        description: '研究方向：人工智能',
        verified: true
      }
    ],
    bio: '计算机系副教授',
    oneSentenceIntro: '需要帮助整理课题组数据',
    requestedAt: new Date(Date.now() - 45 * 60 * 1000), // 45分钟前
    
    applicationType: 'freelancer_receives_invitation',
    taskId: 'task_202',
    taskTitle: '帮忙整理实验数据（Python）',
    taskDescription: '需要处理一批实验数据，要求会Python和数据分析',
    taskBudget: 300,
    applicationMessage: '你好！看了你的档案，Python和数据分析能力很强。我这里有批实验数据需要处理，工作量大概2-3天，预算300元。有兴趣的话可以详细聊聊～',
    
    completionRate: 98,
    rating: 4.9,
    completedTasks: 8
  },
  
  // 示例4: 接单者的申请被接受（通知）
  {
    id: 'notif_4',
    name: '陈同学',
    birthday: '2002-11-05',
    gender: 'female',
    avatar: '👧',
    location: '北京市海淀区',
    hobbies: ['学习', '社交'],
    languages: ['中文'],
    skills: [],
    resources: [],
    projects: [],
    institutions: [],
    university: {
      name: '北京师范大学',
      verified: true
    },
    bio: '大二学生，课余时间充裕',
    oneSentenceIntro: '可以帮忙代取快递、占座等',
    requestedAt: new Date(Date.now() - 5 * 60 * 1000), // 5分钟前
    
    applicationType: 'freelancer_accepted',
    taskId: 'task_303',
    taskTitle: '明天早上帮忙占个图书馆座位',
    taskBudget: 20,
    applicationMessage: '太好了！我接受你的申请。明早7点图书馆见，帮我占3楼靠窗位置，拍照确认后我就转账给你～',
    
    completionRate: 100,
    rating: 5.0,
    completedTasks: 42
  },
  
  // 示例5: 接单者收到另一个邀请
  {
    id: 'notif_5',
    name: '赵老板',
    birthday: '1990-07-22',
    gender: 'male',
    avatar: '👨‍💼',
    location: '北京市朝阳区',
    hobbies: ['创业', '摄影'],
    languages: ['中文', 'English'],
    skills: [],
    resources: [],
    projects: [],
    institutions: [
      {
        name: '某创业公司',
        role: 'CEO',
        description: '互联网创业者',
        verified: false
      }
    ],
    bio: '创业者，经常需要各种帮助',
    oneSentenceIntro: '需要活动摄影师',
    requestedAt: new Date(Date.now() - 15 * 60 * 1000), // 15分钟前
    
    applicationType: 'freelancer_receives_invitation',
    taskId: 'task_404',
    taskTitle: '公司年会摄影（本周六）',
    taskDescription: '公司年会需要摄影师，时间3小时左右',
    taskBudget: 500,
    applicationMessage: '看了你的作品集，拍的很专业！这周六我们公司年会，需要拍摄3小时，预算500元。器材我们可以提供，感兴趣的话联系我吧～',
    
    completionRate: 85,
    rating: 4.3,
    completedTasks: 12
  }
];

/**
 * 使用示例：
 * 
 * import { NotificationPanel, mockNotifications } from './NotificationPanel';
 * import { useNavigate } from 'react-router-dom';
 * 
 * function App() {
 *   const navigate = useNavigate();
 *   const [notifications, setNotifications] = useState(mockNotifications);
 *   
 *   return (
 *     <NotificationPanel
 *       isOpen={showPanel}
 *       onClose={() => setShowPanel(false)}
 *       friendRequests={notifications}
 *       
 *       // 接受申请/邀请
 *       onAcceptApplication={async (appId, taskId) => {
 *         await api.acceptApplication(appId, taskId);
 *         setNotifications(prev => prev.filter(n => n.id !== appId));
 *       }}
 *       
 *       // 拒绝申请/邀请
 *       onRemoveRequest={(id) => {
 *         setNotifications(prev => prev.filter(n => n.id !== id));
 *       }}
 *       
 *       // 联系对方 - 跳转到消息页面
 *       onQuoteContact={(request) => {
 *         // 根据对方ID创建或获取会话ID
 *         const conversationId = request.id; // 或通过API获取
 *         navigate(`/messages/${conversationId}`);
 *       }}
 *       
 *       // 添加到历史记录（订单列表）
 *       onAddToHistory={(request, message) => {
 *         console.log('Added to history:', request, message);
 *       }}
 *       
 *       // 查看完整档案（点击卡片弹出的View Profile按钮）
 *       onViewOriginalCard={(request) => {
 *         // 显示完整档案弹窗，包括任务详情
 *       }}
 *     />
 *   );
 * }
 */