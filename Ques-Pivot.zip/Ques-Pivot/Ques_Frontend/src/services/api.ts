/**
 * API Services for Campus Task Platform
 * 校园任务平台 API 服务
 */

const API_BASE_URL = (import.meta as any).env?.VITE_API_BASE_URL || '/api';

// Helper function for API calls
async function apiCall<T>(
  endpoint: string,
  options: RequestInit = {}
): Promise<T> {
  const response = await fetch(`${API_BASE_URL}${endpoint}`, {
    ...options,
    headers: {
      'Content-Type': 'application/json',
      ...options.headers,
    },
  });

  if (!response.ok) {
    throw new Error(`API Error: ${response.statusText}`);
  }

  return response.json();
}

// ==================== Task APIs ====================

export interface TaskSearchParams {
  query?: string;
  skills?: string[];
  budgetMin?: number;
  budgetMax?: number;
  category?: string;
  location?: string;
}

export async function searchTasks(params: TaskSearchParams) {
  const queryString = new URLSearchParams(params as any).toString();
  return apiCall(`/tasks/search?${queryString}`, { method: 'GET' });
}

export async function getTaskById(taskId: string) {
  return apiCall(`/tasks/${taskId}`, { method: 'GET' });
}

export async function createTask(taskData: any) {
  return apiCall('/tasks/create', {
    method: 'POST',
    body: JSON.stringify(taskData),
  });
}

export async function publishTask(taskId: string) {
  return apiCall(`/tasks/${taskId}/publish`, { method: 'POST' });
}

// ==================== Application APIs ====================

export interface TaskApplicationData {
  taskId: string;
  message: string;
  quotedPrice?: number;
  estimatedDays?: number;
}

export async function applyForTask(data: TaskApplicationData) {
  return apiCall('/applications/create', {
    method: 'POST',
    body: JSON.stringify(data),
  });
}

export async function getMyApplications() {
  return apiCall('/applications/my-applications', { method: 'GET' });
}

export async function acceptApplication(applicationId: string) {
  return apiCall(`/applications/${applicationId}/accept`, { method: 'POST' });
}

export async function rejectApplication(applicationId: string) {
  return apiCall(`/applications/${applicationId}/reject`, { method: 'POST' });
}

// ==================== Freelancer APIs ====================

export interface FreelancerSearchParams {
  query?: string;
  skills?: string[];
  minRating?: number;
  minCompletionRate?: number;
  location?: string;
}

export async function searchFreelancers(params: FreelancerSearchParams) {
  const queryString = new URLSearchParams(params as any).toString();
  return apiCall(`/freelancers/search?${queryString}`, { method: 'GET' });
}

export async function inviteFreelancer(data: {
  freelancerId: string;
  taskId: string;
  message: string;
}) {
  return apiCall('/invitations/create', {
    method: 'POST',
    body: JSON.stringify(data),
  });
}

// ==================== Order APIs ====================

export async function getMyOrders(role?: 'freelancer' | 'poster' | 'all') {
  return apiCall(`/orders/my-orders?role=${role || 'all'}`, { method: 'GET' });
}

export async function getOrderById(orderId: string) {
  return apiCall(`/orders/${orderId}`, { method: 'GET' });
}

export async function payOrder(orderId: string, paymentMethod: string) {
  return apiCall(`/orders/${orderId}/pay`, {
    method: 'POST',
    body: JSON.stringify({ paymentMethod }),
  });
}

export async function submitDeliverables(orderId: string, data: {
  files: File[];
  message: string;
}) {
  const formData = new FormData();
  data.files.forEach(file => formData.append('files', file));
  formData.append('message', data.message);

  return fetch(`${API_BASE_URL}/orders/${orderId}/submit`, {
    method: 'POST',
    body: formData,
  }).then(res => res.json());
}

export async function approveOrder(orderId: string) {
  return apiCall(`/orders/${orderId}/approve`, { method: 'POST' });
}

export async function reportOrder(orderId: string, reason: string) {
  return apiCall(`/orders/${orderId}/report`, {
    method: 'POST',
    body: JSON.stringify({ reason }),
  });
}

// ==================== Review APIs ====================

export interface ReviewData {
  orderId: string;
  overallRating: number; // 1-5
  comment?: string;
}

export async function submitReview(data: ReviewData) {
  return apiCall('/reviews/create', {
    method: 'POST',
    body: JSON.stringify(data),
  });
}

export async function getReviewsForUser(userId: string) {
  return apiCall(`/reviews/user/${userId}`, { method: 'GET' });
}

// ==================== Wallet APIs ====================

export async function getWallet() {
  return apiCall('/wallet/balance', { method: 'GET' });
}

export async function getTransactions(limit?: number) {
  return apiCall(`/wallet/transactions?limit=${limit || 50}`, { method: 'GET' });
}

export async function requestWithdrawal(amount: number, bankAccount: string) {
  return apiCall('/wallet/withdraw', {
    method: 'POST',
    body: JSON.stringify({ amount, bankAccount }),
  });
}

export async function depositFunds(amount: number, paymentMethod: string) {
  return apiCall('/wallet/deposit', {
    method: 'POST',
    body: JSON.stringify({ amount, paymentMethod }),
  });
}

// ==================== Chat/Message APIs ====================

export async function getConversations() {
  return apiCall('/messages/conversations', { method: 'GET' });
}

export async function getMessages(conversationId: string, limit?: number) {
  return apiCall(`/messages/${conversationId}?limit=${limit || 50}`, {
    method: 'GET',
  });
}

export async function sendMessage(conversationId: string, content: string) {
  return apiCall('/messages/send', {
    method: 'POST',
    body: JSON.stringify({ conversationId, content }),
  });
}

// ==================== User Profile APIs ====================

export async function getUserProfile(userId?: string) {
  const endpoint = userId ? `/users/${userId}` : '/users/me';
  return apiCall(endpoint, { method: 'GET' });
}

export async function updateUserProfile(profileData: any) {
  return apiCall('/users/me', {
    method: 'PUT',
    body: JSON.stringify(profileData),
  });
}

// ==================== AI Assistant APIs ====================

export async function chatWithAI(message: string, context?: any) {
  return apiCall('/ai/chat', {
    method: 'POST',
    body: JSON.stringify({ message, context }),
  });
}

export async function generateTaskFromConversation(conversationHistory: any[]) {
  return apiCall('/ai/generate-task', {
    method: 'POST',
    body: JSON.stringify({ conversationHistory }),
  });
}
