// Pivot Types for Campus Task Platform
// 校园任务平台类型定义

import type { ReactNode } from 'react';

export type UserRole = 'freelancer' | 'poster';

// Task related types
export interface Task {
  id: string;
  title: string;
  description: string; // 对应原bio字段
  budget: {
    min: number;
    max: number;
  };
  deadline: string; // ISO date string
  skills: string[]; // 所需技能
  category?: string; // 任务类型（设计类、编程类等）
  status: 'draft' | 'published' | 'in_progress' | 'completed' | 'cancelled';
  deliverables?: string[]; // 交付要求
  attachments: TaskAttachment[]; // 参考图/附件
  applicationCount?: number; // 申请人数
  
  // Poster info
  poster: {
    id: string;
    name: string;
    avatar: string;
    university: {
      name: string;
      verified: boolean;
    };
    posterRating: number; // 发单者评分
    postedTasksCount: number; // 历史发单数
    onTimePaymentRate: number; // 按时付款率
  };
  
  createdAt: string;
  updatedAt: string;
}

export interface TaskAttachment {
  id: string;
  type: 'reference' | 'requirement'; // 参考图 or 需求文档
  url: string;
  filename?: string;
}

// Updated UserRecommendation for Freelancer mode
export interface FreelancerProfile {
  id: string;
  name: string;
  age: string;
  gender: string;
  avatar: string;
  location: string;
  hobbies: string[];
  languages: string[];
  skills: string[]; // 擅长技能
  bio: string; // 个人简介
  oneSentenceIntro?: string;
  
  // Portfolio (复用projects)
  portfolios: {
    title: string;
    role: string;
    description: string;
    referenceLinks: string[];
  }[];
  
  institutions: {
    name: string;
    role: string;
    description: string;
    verified: boolean;
  }[];
  
  university?: {
    name: string;
    verified: boolean;
  };
  
  // New stats for freelancers
  completionRate: number; // 完成率 0-100
  averageRating: number; // 平均评分 0-5
  completedTasksCount: number; // 完成任务数
  responseTimeMinutes: number; // 平均响应时间（分钟）
  
  // Optional matching fields
  matchScore?: number;
  whyMatch?: string;
}

// Order/Contract types
export interface Order {
  id: string;
  taskId: string;
  taskTitle: string;
  freelancerId: string;
  freelancerName: string;
  posterId: string;
  posterName: string;
  partnerAvatar: string; // 对方头像
  partnerName: string; // 对方昵称
  amount: number; // 总金额
  platformFee: number; // 平台抽成（10%）
  status: 'pending_payment' | 'in_progress' | 'submitted' | 'completed' | 'disputed' | 'cancelled';
  createdAt: string;
  paidAt?: string;
  submittedAt?: string;
  completedAt?: string;
  deadline: string;
}

export type OrderStatus = Order['status'];

// Review/Rating types
export interface Review {
  id: string;
  orderId: string;
  reviewerId: string;
  reviewerName: string;
  revieweeId: string;
  revieweeName: string;
  overallRating: number; // 1-5
  qualityRating?: number;
  communicationRating?: number;
  timelinessRating?: number;
  comment: string;
  createdAt: string;
}

// Wallet types
export interface Wallet {
  userId: string;
  balance: number;
  frozenAmount: number; // 冻结金额（进行中的订单）
  totalEarnings: number;
  totalSpending: number;
}

// Chat message with embedded component support
export interface ChatMessage {
  id: string;
  type: 'user' | 'ai';
  content: string;
  timestamp: Date;
  component?: ReactNode; // 用于嵌入TaskPreviewCard等组件
}

// Intent detection for AI
export type AIIntent = 
  | 'search_tasks'      // 搜索任务（接单者）
  | 'search_freelancers' // 搜索接单者（发单者）
  | 'create_task'       // 发布任务
  | 'view_orders'       // 查看订单
  | 'general_chat';     // 普通对话

// AI Response with intent
export interface AIResponse {
  intent: AIIntent;
  reply: string;
  data?: {
    tasks?: Task[];
    freelancers?: FreelancerProfile[];
    taskDraft?: Partial<Task>;
  };
}
