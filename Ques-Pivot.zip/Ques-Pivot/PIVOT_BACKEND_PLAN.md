# Ques Pivot 后端实施方案 v2.0
## 校园任务平台后端架构设计

**核心定位**：AI驱动的校园版Upwork，支持任务发布、接单、支付托管、验收评价

**🎓 产品定位 - 高校线下任务场景**：

专注于**大学校园内的线下单次任务**，解决同学之间的互助需求。核心场景包括：

1. **课程学习辅助** - 课程辅导、作业答疑、代签到、代做笔记
2. **学术科研支持** - 导师助理、数据标注、文献整理、问卷发放
3. **校园活动帮手** - 社团活动人手、迎新志愿者、摄影摄像、场地布置
4. **生活便利服务** - 代取快递、占座位、失物寻找、拼车拼单
5. **技能外包任务** - PPT制作、海报设计、视频剪辑、代码调试

**特点**：
- ✅ **校内认证**：仅限同校学生，基于university字段验证
- ✅ **线下为主**：任务多需面对面完成，location字段支持地理匹配
- ✅ **小额高频**：单笔金额¥30-300，支持微信支付分账
- ✅ **技术含量适中**：大学生可完成的单次任务，skills标签匹配
- ✅ **时间灵活**：契合课余时间，deadline和response_time管理

**后端关键支持**：
- 🔍 任务搜索支持skills + location双重过滤
- 📍 同校学生优先推荐（university匹配）
- ⏰ 任务截止时间提醒（24小时定时任务）
- 💰 小额支付优化（微信支付分账10%抽成）
- ⭐ 快速评价系统（简化为5星评分）

**✅ 已确认的关键决策**（基于PIVOT_UNCERTAINTIES.md）：
- ✅ 微信支付分账（10%平台抽成）- 商户号待提供
- ✅ 7天未验收自动确认完成
- ✅ Report按钮申诉机制（平台审核）
- ✅ 任务发布后禁止修改（仅可删除）
- ✅ 响应时间 = 任务发布→首个申请的时间间隔
- ✅ 保持腾讯云VectorDB + COS
- ✅ 固定10%抽成比例
- ✅ 记录任务浏览历史（新增task_views表）
- ✅ 24小时截止提醒（定时任务）
- ❌ 删除matchScore和whyMatch字段（前端不再使用）

---

## 🎯 后端核心变化

### 原系统架构
- 用户档案匹配系统
- Whisper匿名消息
- Receives虚拟货币管理
- 会员订阅系统（Basic/Pro）

### 新系统架构
- 双角色用户系统（接单者/发单者）
- 任务发布与匹配系统
- 支付托管与结算系统（10%平台抽成）
- 订单状态流转与验收系统
- 评价与stat统计系统

---

## 📊 数据库表结构调整

### 1️⃣ **保留并修改的表**

#### `users` 表
**保留字段**：
```sql
id, phone, wechat_openid, wechat_id, created_at, updated_at
```

**无需修改**，继续作为用户基础表

---

#### `user_profiles` 表
**保留字段**：
```sql
id, user_id, name, avatar, birthday, gender, location,
one_sentence_intro, bio, created_at, updated_at
```

**修改字段**：
```sql
-- 删除字段
❌ DROP COLUMN goals;
❌ DROP COLUMN demands;
❌ DROP COLUMN resources;

-- 新增字段（接单者stat）
➕ ALTER TABLE user_profiles ADD COLUMN completion_rate DECIMAL(5,2) DEFAULT 100.00; -- 完成率
➕ ALTER TABLE user_profiles ADD COLUMN average_rating DECIMAL(3,2) DEFAULT 5.00; -- 平均评分
➕ ALTER TABLE user_profiles ADD COLUMN completed_tasks_count INT DEFAULT 0; -- 完成任务数
➕ ALTER TABLE user_profiles ADD COLUMN response_time_minutes INT DEFAULT 60; -- 平均响应时间(分钟)

-- 新增字段（发单者stat）
➕ ALTER TABLE user_profiles ADD COLUMN posted_tasks_count INT DEFAULT 0; -- 发布任务数
➕ ALTER TABLE user_profiles ADD COLUMN on_time_payment_rate DECIMAL(5,2) DEFAULT 100.00; -- 按时付款率
➕ ALTER TABLE user_profiles ADD COLUMN poster_rating DECIMAL(3,2) DEFAULT 5.00; -- 发单者评分
```

**说明**：
- `bio` 字段复用：接单者 = 个人介绍，任务 = 任务描述
- stat字段自动计算，通过订单系统触发器更新

---

#### `user_projects` 表（改名为 `portfolios`）
```sql
-- 重命名表
RENAME TABLE user_projects TO portfolios;

-- 保留字段
id, user_id, title, role, description, reference_links, created_at

-- 说明：
-- 接单者：存储作品集
-- 发单者发布任务时：复用此表存储任务参考图（task_id关联）
```

---

#### `skills` 相关表
**保留不变**：
```sql
user_skills (user_id, skill_name)
```

**说明**：
- 接单者：存储个人技能
- 发单者发布任务时：存储任务所需技能（通过task_id关联）

---

### 2️⃣ **删除的表**

```sql
❌ DROP TABLE user_quotas; -- Receives配额表
❌ DROP TABLE memberships; -- Pro会员表
❌ DROP TABLE membership_transactions; -- 会员交易表
❌ DROP TABLE whispers; -- Whisper消息表（改用普通chat）
```

---

### 3️⃣ **新增的表**

#### `tasks` 表（核心新表）
```sql
CREATE TABLE tasks (
    id BIGSERIAL PRIMARY KEY,
    poster_id BIGINT NOT NULL REFERENCES users(id),  -- 发单者ID
    title VARCHAR(200) NOT NULL,                      -- 任务标题
    description TEXT NOT NULL,                        -- 任务描述(复用profile.bio概念)
    budget_min DECIMAL(10,2),                         -- 预算下限
    budget_max DECIMAL(10,2),                         -- 预算上限
    final_amount DECIMAL(10,2),                       -- 最终确认金额
    deadline TIMESTAMP,                               -- 截止时间
    location VARCHAR(200),                            -- 任务地点
    status VARCHAR(50) NOT NULL DEFAULT 'draft',      -- 任务状态
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    published_at TIMESTAMP,                           -- 发布时间
    completed_at TIMESTAMP,                           -- 完成时间
    
    -- AI生成的嵌入向量（用于匹配）
    embedding_vector vector(1024),                    -- Dense向量
    sparse_vector jsonb,                              -- Sparse向量（BM25）
    
    -- 统计字段
    view_count INT DEFAULT 0,                         -- 查看次数
    application_count INT DEFAULT 0,                  -- 申请人数
    
    INDEX idx_poster_id (poster_id),
    INDEX idx_status (status),
    INDEX idx_published_at (published_at)
);

-- 任务状态枚举
-- 'draft'      : 草稿（AI生成，未发布）
-- 'published'  : 已发布（等待接单）
-- 'in_progress': 进行中（已确认接单者）
-- 'reviewing'  : 待验收
-- 'completed'  : 已完成
-- 'cancelled'  : 已取消
-- 'disputed'   : 有争议
```

---

#### `task_skills` 表（任务所需技能）
```sql
CREATE TABLE task_skills (
    task_id BIGINT REFERENCES tasks(id) ON DELETE CASCADE,
    skill_name VARCHAR(100),
    PRIMARY KEY (task_id, skill_name)
);
```

---

#### `task_attachments` 表（任务参考图/附件）
```sql
CREATE TABLE task_attachments (
    id BIGSERIAL PRIMARY KEY,
    task_id BIGINT NOT NULL REFERENCES tasks(id) ON DELETE CASCADE,
    file_url TEXT NOT NULL,                          -- 文件URL
    file_type VARCHAR(50),                           -- 文件类型(image/pdf/doc)
    description TEXT,                                -- 文件说明
    uploaded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    INDEX idx_task_id (task_id)
);
```

---

#### `task_applications` 表（任务申请记录）
```sql
CREATE TABLE task_applications (
    id BIGSERIAL PRIMARY KEY,
    task_id BIGINT NOT NULL REFERENCES tasks(id),
    freelancer_id BIGINT NOT NULL REFERENCES users(id), -- 申请者ID
    message TEXT,                                        -- 申请留言（AI生成）
    quoted_price DECIMAL(10,2),                          -- 报价
    estimated_days INT,                                  -- 预计完成天数
    status VARCHAR(50) DEFAULT 'pending',                -- 申请状态
    applied_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    responded_at TIMESTAMP,                              -- 发单者回复时间
    
    UNIQUE (task_id, freelancer_id),  -- 每人只能申请一次
    INDEX idx_task_id (task_id),
    INDEX idx_freelancer_id (freelancer_id),
    INDEX idx_status (status)
);

-- 申请状态枚举
-- 'pending'  : 待回复
-- 'accepted' : 已接受（进入订单流程）
-- 'rejected' : 已拒绝
-- 'withdrawn': 已撤回
```

---

#### `orders` 表（订单表，任务确认后生成）
```sql
CREATE TABLE orders (
    id BIGSERIAL PRIMARY KEY,
    task_id BIGINT NOT NULL REFERENCES tasks(id),
    poster_id BIGINT NOT NULL REFERENCES users(id),      -- 发单者
    freelancer_id BIGINT NOT NULL REFERENCES users(id),  -- 接单者
    amount DECIMAL(10,2) NOT NULL,                       -- 订单金额
    platform_fee DECIMAL(10,2) NOT NULL,                 -- 平台抽成(10%)
    freelancer_income DECIMAL(10,2) NOT NULL,            -- 接单者实际收入
    status VARCHAR(50) NOT NULL DEFAULT 'pending_payment',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    paid_at TIMESTAMP,                                   -- 支付时间
    submitted_at TIMESTAMP,                              -- 提交作品时间
    completed_at TIMESTAMP,                              -- 验收通过时间
    cancelled_at TIMESTAMP,
    
    -- 支付信息
    payment_method VARCHAR(50),                          -- 支付方式
    transaction_id VARCHAR(200),                         -- 第三方交易ID
    
    INDEX idx_task_id (task_id),
    INDEX idx_poster_id (poster_id),
    INDEX idx_freelancer_id (freelancer_id),
    INDEX idx_status (status)
);

-- 订单状态流转
-- 'pending_payment' : 待支付（发单者需支付）
-- 'paid'            : 已支付（平台托管）
-- 'in_progress'     : 进行中（接单者工作）
-- 'submitted'       : 已提交（等待验收）
-- 'reviewing'       : 验收中（发单者审核）
-- 'completed'       : 已完成（款项释放给接单者）
-- 'refund_requested': 申请退款
-- 'refunded'        : 已退款
-- 'disputed'        : 有争议（需客服介入）
-- 'cancelled'       : 已取消
```

---

#### `order_deliverables` 表（交付物）
```sql
CREATE TABLE order_deliverables (
    id BIGSERIAL PRIMARY KEY,
    order_id BIGINT NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
    file_url TEXT NOT NULL,                           -- 交付文件URL
    file_type VARCHAR(50),
    description TEXT,
    uploaded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    INDEX idx_order_id (order_id)
);
```

---

#### `reviews` 表（评价表）- 简化版
```sql
CREATE TABLE reviews (
    id BIGSERIAL PRIMARY KEY,
    order_id BIGINT NOT NULL REFERENCES orders(id),
    reviewer_id BIGINT NOT NULL REFERENCES users(id),   -- 评价者
    reviewee_id BIGINT NOT NULL REFERENCES users(id),   -- 被评价者
    role VARCHAR(20) NOT NULL,                          -- 'freelancer' or 'poster'
    
    -- ✅ 简化评分系统：仅保留单一5星评分（根据前端用户决策5.3）
    rating INT NOT NULL CHECK (rating BETWEEN 1 AND 5), -- 1-5星评分
    
    -- ⚠️ 可选字段（后续版本可能添加）
    comment TEXT,                                        -- 评价内容（可选，暂不启用）
    
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    UNIQUE (order_id, reviewer_id),  -- 每个订单每人只能评价一次
    INDEX idx_order_id (order_id),
    INDEX idx_reviewee_id (reviewee_id),
    INDEX idx_rating (rating)
);
```

**说明**：
- ✅ 删除了 `quality_rating`, `speed_rating`, `communication_rating` 分项评分
- ✅ 删除了 `overall_rating` 自动计算字段
- ✅ 简化为单一 `rating` 字段（1-5星）
- ✅ `comment` 字段保留但标记为可选，前端暂不显示输入框
- ✅ 符合前端极简评价设计：仅5星评分，无文字评价
```

---

#### `transactions` 表（资金流水）
```sql
CREATE TABLE transactions (
    id BIGSERIAL PRIMARY KEY,
    order_id BIGINT REFERENCES orders(id),
    user_id BIGINT NOT NULL REFERENCES users(id),
    type VARCHAR(50) NOT NULL,                          -- 交易类型
    amount DECIMAL(10,2) NOT NULL,                      -- 金额
    balance_after DECIMAL(10,2),                        -- 交易后余额
    description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    INDEX idx_user_id (user_id),
    INDEX idx_order_id (order_id),
    INDEX idx_created_at (created_at)
);

-- 交易类型枚举
-- 'payment'    : 发单者支付
-- 'income'     : 接单者收入
-- 'fee'        : 平台抽成
-- 'refund'     : 退款
-- 'withdrawal' : 提现
```

---

#### `user_wallets` 表（用户钱包）
```sql
CREATE TABLE user_wallets (
    user_id BIGINT PRIMARY KEY REFERENCES users(id),
    balance DECIMAL(10,2) DEFAULT 0.00,                 -- 可用余额
    frozen_amount DECIMAL(10,2) DEFAULT 0.00,           -- 冻结金额（进行中订单）
    total_income DECIMAL(10,2) DEFAULT 0.00,            -- 累计收入
    total_expense DECIMAL(10,2) DEFAULT 0.00,           -- 累计支出
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

---

## 🔄 API接口设计

### 1️⃣ **任务相关接口**

#### 发布任务（AI对话生成）
```
POST /api/tasks/create-from-conversation
```

**请求体**：
```json
{
  "conversation_id": "conv_123",           // AI对话ID
  "ai_generated_draft": {                  // AI生成的任务草稿（高校线下场景）
    "title": "帮忙早八课程签到（本周三次）",
    "description": "微积分早八课，本周三、周五需要代签到两次。教室在理科楼A301，早上7:50前到即可。要求同校学生，可以提供学生证照片核实身份。",
    "budget_min": 30,
    "budget_max": 50,
    "deadline": "2025-10-25T07:50:00Z",
    "location": "清华大学理科楼A301",
    "skills_required": ["同校学生", "早起", "守时"],
    "reference_images": []
  },
  "user_modifications": {                  // 用户修改（可选）
    "budget_max": 60,
    "description": "微积分早八课，本周三、周五需要代签到两次。教室在理科楼A301，早上7:50前到即可。要求同校学生，可以提供学生证照片核实身份。完成后微信发送签到照片确认。"
  }
}
```

**响应**：
```json
{
  "task_id": 12345,
  "status": "draft",  // 草稿状态，未发布
  "preview_url": "/tasks/12345/preview"
}
```

---

#### 发布任务（确认后）
```
POST /api/tasks/{task_id}/publish
```

**说明**：将draft状态改为published，开始接收申请

---

#### 搜索任务（AI匹配）
```
POST /api/tasks/search
```

**请求体**：
```json
{
  "user_role": "freelancer",               // 角色：接单者
  "query": "找个帮忙签到的活儿",           // 自然语言查询（高校场景）
  "filters": {
    "location": "清华大学",
    "budget_min": 20,
    "budget_max": 100,
    "deadline_within_days": 3,
    "university": "清华大学"               // 同校过滤
  }
}
```

**响应**：
```json
{
  "tasks": [
    {
      "id": 12345,
      "title": "帮忙早八课程签到（本周三次）",
      "poster": {
        "id": 67890,
        "name": "张小明",
        "avatar": "https://...",
        "university": "清华大学",
        "verified": true,
        "poster_rating": 4.8,
        "posted_tasks_count": 12,
        "on_time_payment_rate": 100
      },
      "budget": "¥30-50",
      "deadline": "还剩2天",
      "location": "清华大学理科楼A301",
      "skills_required": ["同校学生", "早起", "守时"],
      "description": "微积分早八课，本周三、周五需要代签到两次。教室在理科楼A301，早上7:50前到即可...",
      "reference_images": [],
      "view_count": 8,
      "application_count": 5,
      "category": "校园帮助"
    },
    {
      "id": 12346,
      "title": "毕业论文数据标注（500条）",
      "poster": {
        "id": 67891,
        "name": "李华",
        "avatar": "https://...",
        "university": "清华大学",
        "verified": true,
        "poster_rating": 4.9,
        "posted_tasks_count": 23,
        "on_time_payment_rate": 95
      },
      "budget": "¥80-120",
      "deadline": "还剩4天",
      "location": "清华大学（线上完成）",
      "skills_required": ["数据标注", "细心认真", "中文阅读理解"],
      "description": "需要标注500条文本数据用于毕业论文实验，内容是情感分析...",
      "reference_images": [],
      "view_count": 15,
      "application_count": 6,
      "category": "学术辅助"
    }
  ]
}
```

**❌ v2.0删除**：删除 `match_score` 和 `why_match` 字段，前端不再显示匹配度和推荐理由

---

#### 申请任务
```
POST /api/tasks/{task_id}/apply
```

**请求体**：
```json
{
  "message": "您好！看到您发布的任务...",  // AI生成的申请消息
  "quoted_price": 120,                    // 报价
  "estimated_days": 3                     // 预计完成天数
}
```

---

### 2️⃣ **接单者推荐接口**（发单者视角）

#### 搜索接单者
```
POST /api/freelancers/search
```

**请求体**：
```json
{
  "user_role": "poster",
  "query": "找个PS高手",
  "task_id": 12345,  // 可选，关联到具体任务
  "filters": {
    "skills": ["PS", "平面设计"],
    "min_completion_rate": 90,
    "min_rating": 4.5
  }
}
```

**响应**：
```json
{
  "freelancers": [
    {
      "id": 111,
      "name": "李四",
      "avatar": "https://...",
      "university": "北京大学",
      "one_sentence_intro": "5年设计经验，专注扁平化设计",
      "skills": ["PS", "AI", "平面设计"],
      "portfolios": [
        {
          "title": "品牌海报设计",
          "images": ["url1", "url2"],
          "description": "为XX品牌设计的系列海报..."
        }
      ],
      "stats": {
        "completion_rate": 95,
        "average_rating": 4.9,
        "completed_tasks_count": 23,
        "response_time": "1小时内"
      },
      "match_score": 92,
      "why_match": "该学生擅长扁平插画，作品风格符合你的需求..."
    }
  ]
}
```

---

### 3️⃣ **订单流程接口**

#### 确认合作并创建订单
```
POST /api/orders/create
```

**请求体**：
```json
{
  "application_id": 456,  // 接受的申请ID
  "final_amount": 120     // 最终确认的金额
}
```

**响应**：
```json
{
  "order_id": 789,
  "status": "pending_payment",
  "amount": 120,
  "platform_fee": 12,      // 10%抽成
  "freelancer_income": 108,
  "payment_qr_code": "https://..."  // 支付二维码
}
```

---

#### 支付订单
```
POST /api/orders/{order_id}/pay
```

**请求体**：
```json
{
  "payment_method": "wechat",     // 微信支付
  "return_url": "/orders/789"     // 支付成功后跳转
}
```

**说明**：
- 调用微信支付/支付宝SDK
- 款项进入平台托管账户
- 订单状态 → `paid`

---

#### 提交交付物
```
POST /api/orders/{order_id}/submit
```

**请求体**：
```json
{
  "files": ["url1", "url2"],  // 交付文件URL
  "message": "已完成，请查收"
}
```

**订单状态**：`in_progress` → `submitted`

---

#### 验收通过（极简流程）
```
POST /api/orders/{order_id}/approve
```

**说明**：
- ✅ 发单者点击"验收通过"按钮
- ✅ 订单状态 → `completed`
- ✅ 触发款项结算（微信支付分账）：
  - 接单者钱包余额 + 实际收入（90%）
  - 平台收入 + 平台抽成（10%）
  - 更新接单者stat（完成率、完成任务数、average_rating）
- ✅ 发送完成通知给双方
- ✅ 7天未验收自动执行此逻辑（定时任务）

---

#### 举报订单（Report按钮）
```
POST /api/orders/{order_id}/report
```

**请求体**：
```json
{
  "reason": "质量不符合要求" | "未按时完成" | "沟通不畅" | "其他",
  "description": "详细描述问题...",
  "evidence_urls": ["https://...", "https://..."]  // 截图或文件证据
}
```

**说明**：
- ✅ 订单状态 → `disputed`（有争议）
- ✅ 冻结款项，等待平台人工审核
- ✅ 发送通知给平台客服和对方
- ✅ 平台在3个工作日内介入处理
- ✅ 根据审核结果：验收通过 或 退款

**❌ 删除的接口**：
- ❌ `POST /api/orders/{order_id}/request-revision` - 申请修改（简化流程，不需要）
- ❌ `POST /api/orders/{order_id}/cancel` - 申请取消（通过举报处理）

---

### 4️⃣ **评价接口** - 简化版

#### 提交评价（仅5星评分）
```
POST /api/reviews/create
```

**请求体**：
```json
{
  "order_id": 789,
  "rating": 5  // ✅ 简化为单一评分（1-5星）
  // ❌ 删除 quality_rating, speed_rating, communication_rating
  // ❌ 删除 comment 字段（前端不显示输入框）
}
```

**后端处理**：
- ✅ 存储单一rating值（1-5星）
- ✅ 更新被评价者的average_rating（所有评价的平均值）
- ✅ 双方评价完成后，订单进入最终完成状态
- ✅ 触发stat更新（completion_rate, average_rating等）

**说明**：根据前端用户决策5.3，评价系统简化为仅5星评分，无文字评价和分项评分。

---

### 5️⃣ **Stat统计接口**

#### 获取接单者stat
```
GET /api/users/{user_id}/freelancer-stats
```

**响应**：
```json
{
  "completion_rate": 95.5,
  "average_rating": 4.8,
  "completed_tasks_count": 23,
  "response_time_minutes": 60,
  "total_income": 2580.00,
  "this_month_income": 1280.00
}
```

---

#### 获取发单者stat
```
GET /api/users/{user_id}/poster-stats
```

**响应**：
```json
{
  "posted_tasks_count": 10,
  "poster_rating": 4.9,
  "on_time_payment_rate": 100,
  "total_expense": 3200.00,
  "active_tasks_count": 3
}
```

---

## 💰 支付与抽成逻辑

### 支付流程

```
1. 发单者支付 ¥120
   ↓
2. 平台托管账户 +¥120
   ↓
3. 接单者完成任务并验收通过
   ↓
4. 平台抽成计算：
   - 平台抽成 = 120 × 10% = ¥12
   - 接单者实收 = 120 - 12 = ¥108
   ↓
5. 款项结算：
   - 平台收入账户 +¥12
   - 接单者钱包 +¥108
   ↓
6. 记录流水：
   - transactions表插入两条记录
```

### 数据库触发器（自动抽成）

```sql
CREATE OR REPLACE FUNCTION calculate_platform_fee()
RETURNS TRIGGER AS $$
BEGIN
    -- 自动计算平台抽成（10%）
    NEW.platform_fee := NEW.amount * 0.10;
    NEW.freelancer_income := NEW.amount - NEW.platform_fee;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trigger_calculate_fee
BEFORE INSERT OR UPDATE ON orders
FOR EACH ROW
EXECUTE FUNCTION calculate_platform_fee();
```

### 提现功能（后续实现）

```
POST /api/wallet/withdraw
```

**请求体**：
```json
{
  "amount": 100,
  "method": "wechat",  // 微信零钱
  "account": "wxid_123"
}
```

**限制**：
- 最低提现金额：¥10
- 提现手续费：0%（平台补贴）
- 到账时间：1-3个工作日

---

## 🤖 AI相关后端逻辑

### 1️⃣ AI生成任务卡片

**流程**：
```python
# 伪代码
def generate_task_from_conversation(conversation_history):
    # 1. 提取对话中的关键信息
    prompt = f"""
    根据以下对话，生成一个任务卡片：
    
    对话历史：
    用户: 我想找人做海报
    AI: 什么类型的海报？预算多少？
    用户: 活动宣传海报，预算100-150元，3天内完成
    AI: 需要什么风格？
    用户: 扁平化设计
    
    请生成JSON格式的任务卡片，包含：
    - title: 任务标题
    - description: 任务描述
    - budget_min, budget_max: 预算范围
    - deadline: 截止时间
    - skills_required: 所需技能列表
    """
    
    # 2. 调用GLM-4生成
    response = glm4_client.generate(prompt)
    
    # 3. 解析JSON
    task_draft = json.loads(response)
    
    # 4. 生成嵌入向量（用于匹配）
    embedding = generate_embedding(task_draft['description'])
    sparse_keywords = extract_keywords(task_draft['description'])
    
    # 5. 保存为草稿
    task = Task.create(
        poster_id=user_id,
        status='draft',
        **task_draft,
        embedding_vector=embedding,
        sparse_vector=sparse_keywords
    )
    
    return task
```

---

### 2️⃣ AI匹配算法（复用现有逻辑）

**接单者找任务**：
```python
def match_tasks_for_freelancer(freelancer_profile, query):
    # 1. 生成查询向量
    query_embedding = generate_embedding(query)
    
    # 2. 向量搜索（Dense + Sparse）
    matched_tasks = vector_db.hybrid_search(
        query_vector=query_embedding,
        dense_weight=0.6,
        sparse_weight=0.4,
        filters={
            'status': 'published',
            'location': freelancer_profile.location
        }
    )
    
    # 3. 二次排序（考虑发单者信誉）
    for task in matched_tasks:
        task['match_score'] = calculate_match_score(
            freelancer_skills=freelancer_profile.skills,
            task_skills=task.skills_required,
            budget_match=...,
            location_match=...
        )
    
    # 4. 生成AI理由
    for task in matched_tasks:
        task['why_match'] = generate_why_match_reason(
            freelancer_profile, task
        )
    
    return sorted(matched_tasks, key=lambda x: x['match_score'], reverse=True)
```

---

## 📈 Stat自动计算触发器

### 更新完成率
```sql
CREATE OR REPLACE FUNCTION update_completion_rate()
RETURNS TRIGGER AS $$
BEGIN
    -- 当订单完成时，更新接单者完成率
    IF NEW.status = 'completed' THEN
        UPDATE user_profiles
        SET 
            completed_tasks_count = completed_tasks_count + 1,
            completion_rate = (
                SELECT (COUNT(*) FILTER (WHERE status = 'completed') * 100.0 / COUNT(*))
                FROM orders
                WHERE freelancer_id = NEW.freelancer_id
            )
        WHERE user_id = NEW.freelancer_id;
    END IF;
    
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trigger_update_stats
AFTER UPDATE ON orders
FOR EACH ROW
WHEN (OLD.status IS DISTINCT FROM NEW.status)
EXECUTE FUNCTION update_completion_rate();
```

---

### 更新平均评分
```sql
CREATE OR REPLACE FUNCTION update_average_rating()
RETURNS TRIGGER AS $$
BEGIN
    UPDATE user_profiles
    SET average_rating = (
        SELECT AVG(overall_rating)
        FROM reviews
        WHERE reviewee_id = NEW.reviewee_id
    )
    WHERE user_id = NEW.reviewee_id;
    
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trigger_update_rating
AFTER INSERT ON reviews
FOR EACH ROW
EXECUTE FUNCTION update_average_rating();
```

---

## 🔒 权限与安全

### API权限控制

```python
# 示例：只有发单者能验收订单
@router.post("/orders/{order_id}/approve")
async def approve_order(
    order_id: int,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    order = db.query(Order).filter(Order.id == order_id).first()
    
    # 权限检查
    if order.poster_id != current_user.id:
        raise HTTPException(403, "只有发单者可以验收")
    
    # 状态检查
    if order.status != 'submitted':
        raise HTTPException(400, "订单未处于待验收状态")
    
    # 执行验收逻辑...
```

---

## ⚠️ 后端不确定点（已在PIVOT_UNCERTAINTIES.md中确认）

### ✅ 1. 支付SDK选择
- **已确认**：微信支付分账API
- **状态**：商户号待提供
- **实现**：10%平台抽成自动分账

---

### ✅ 2. 平台托管账户
- **已确认**：使用微信支付分账（选项A）
- **说明**：款项直接分给平台10% + 接单者90%

---

### ✅ 3. 争议处理流程
- **已确认**：使用原有Report按钮申诉
- **流程**：用户申诉 → 平台审核 → 平台判定结果
- **自动规则**：7天未验收自动确认完成

---

### ✅ 4. 提现功能规格
- **最低金额**：10元
- **手续费**：0%
- **到账时间**：1-3个工作日
- **支持方式**：微信零钱、支付宝、银行卡

---

### ✅ 5. 抽成比例策略
- **已确认**：固定10%
- **暂不支持**：阶梯抽成、活动免抽成

---

## 🆕 v2.0 新增功能

### 1️⃣ 任务浏览记录表

```sql
CREATE TABLE task_views (
    id BIGSERIAL PRIMARY KEY,
    task_id BIGINT NOT NULL REFERENCES tasks(id) ON DELETE CASCADE,
    user_id BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    viewed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    duration_seconds INT DEFAULT 0 COMMENT '浏览时长（秒）',
    
    INDEX idx_task_id (task_id),
    INDEX idx_user_id (user_id),
    INDEX idx_viewed_at (viewed_at)
);
```

**用途**：
- 记录用户浏览任务的行为
- 用于推荐算法优化
- 数据分析（热门任务、用户兴趣）

**API**：
```python
@router.post("/api/tasks/{task_id}/view")
async def record_task_view(
    task_id: int,
    duration_seconds: int = Body(0),
    current_user: User = Depends(get_current_user)
):
    view = TaskView(
        task_id=task_id,
        user_id=current_user.id,
        viewed_at=datetime.utcnow(),
        duration_seconds=duration_seconds
    )
    db.add(view)
    
    # 更新任务浏览数
    db.execute(
        "UPDATE tasks SET view_count = view_count + 1 WHERE id = :task_id",
        {"task_id": task_id}
    )
    db.commit()
    return {"success": True}
```

---

### 2️⃣ 响应时间自动计算

**触发器逻辑**（根据决策#7）：
```sql
CREATE OR REPLACE FUNCTION update_response_time()
RETURNS TRIGGER AS $$
DECLARE
    task_published_at TIMESTAMP;
    response_minutes INT;
    is_first_application BOOLEAN;
BEGIN
    -- 检查是否是该任务的第一个申请
    SELECT COUNT(*) = 0 INTO is_first_application
    FROM task_applications
    WHERE task_id = NEW.task_id AND id < NEW.id;
    
    IF is_first_application THEN
        -- 获取任务发布时间
        SELECT published_at INTO task_published_at
        FROM tasks
        WHERE id = NEW.task_id;
        
        -- 计算响应时间（分钟）
        response_minutes := EXTRACT(EPOCH FROM (NEW.applied_at - task_published_at)) / 60;
        
        -- 更新接单者的平均响应时间（加权平均）
        UPDATE user_profiles
        SET response_time_minutes = (
            (response_time_minutes * completed_tasks_count + response_minutes) / 
            NULLIF(completed_tasks_count + 1, 0)
        )
        WHERE user_id = NEW.freelancer_id;
    END IF;
    
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trigger_update_response_time
AFTER INSERT ON task_applications
FOR EACH ROW
EXECUTE FUNCTION update_response_time();
```

---

### 3️⃣ 定时任务

#### A. 7天自动确认订单
```python
# services/scheduled_tasks.py

@scheduler.scheduled_job('interval', hours=1)
async def auto_approve_submitted_orders():
    """
    每小时执行一次：
    检查submitted状态超过7天的订单，自动确认完成
    """
    seven_days_ago = datetime.utcnow() - timedelta(days=7)
    
    pending_orders = db.query(Order).filter(
        Order.status == 'submitted',
        Order.submitted_at < seven_days_ago
    ).all()
    
    for order in pending_orders:
        order.status = 'completed'
        order.completed_at = datetime.utcnow()
        
        # 结算款项
        await finance_service.settle_freelancer_income(order.id)
        
        # 发送通知
        await notification_service.send_notification(
            user_id=order.freelancer_id,
            type='order_auto_completed',
            title='订单已自动确认',
            content=f'任务"{order.task.title}"已超过7天未被拒绝，系统自动确认完成。'
        )
        
        logger.info(f"Order {order.id} auto-approved after 7 days")
    
    db.commit()
    return len(pending_orders)
```

#### B. 24小时截止提醒
```python
@scheduler.scheduled_job('interval', hours=1)
async def send_task_deadline_reminders():
    """
    每小时执行一次：
    检查24小时内即将截止的任务，发送提醒
    """
    now = datetime.utcnow()
    reminder_time = now + timedelta(hours=24)
    
    expiring_tasks = db.query(Order).join(Task).filter(
        Order.status == 'in_progress',
        Task.deadline.between(now, reminder_time)
    ).all()
    
    for order in expiring_tasks:
        task = order.task
        
        # 通知接单者
        await notification_service.send_notification(
            user_id=order.freelancer_id,
            type='task_deadline_reminder',
            title='任务即将截止',
            content=f'任务"{task.title}"将在24小时后截止，请及时提交交付物。'
        )
        
        # 通知发单者
        await notification_service.send_notification(
            user_id=order.poster_id,
            type='task_deadline_reminder',
            title='任务即将截止',
            content=f'任务"{task.title}"将在24小时后截止，请关注进度。'
        )
    
    return len(expiring_tasks)
```

---

### 4️⃣ 任务修改权限控制

**API修改**（根据决策#6）：
```python
@router.put("/api/tasks/{task_id}")
async def update_task(
    task_id: int,
    update_data: TaskUpdate,
    current_user: User = Depends(get_current_user)
):
    """
    修改任务（仅draft状态可修改）
    已发布的任务禁止修改，只能删除
    """
    task = db.query(Task).filter(Task.id == task_id).first()
    
    if not task:
        raise HTTPException(404, "任务不存在")
    
    if task.poster_id != current_user.id:
        raise HTTPException(403, "无权修改此任务")
    
    # 🔴 禁止修改已发布的任务
    if task.status != 'draft':
        raise HTTPException(
            403, 
            "任务已发布，无法修改。如需更改，请删除后重新发布。"
        )
    
    # 允许修改draft状态的任务
    for key, value in update_data.dict(exclude_unset=True).items():
        setattr(task, key, value)
    
    task.updated_at = datetime.utcnow()
    db.commit()
    
    return task
```

---

### 5️⃣ 微信支付分账代码

```python
# services/payment_service.py

from wechatpayv3 import WeChatPay, WeChatPayType

wxpay = WeChatPay(
    wechatpay_type=WeChatPayType.NATIVE,
    mchid='YOUR_MCHID',  # ⏳ 待提供
    private_key=open('apiclient_key.pem').read(),
    cert_serial_no='YOUR_CERT_SERIAL',
    apiv3_key='YOUR_APIV3_KEY',
    appid='YOUR_APPID',
)

async def create_payment_with_profit_sharing(order_id: int):
    """创建支付订单（带分账）"""
    order = db.query(Order).filter(Order.id == order_id).first()
    out_trade_no = f"ORDER_{order.id}_{int(time.time())}"
    
    code_url = wxpay.pay(
        description=f"任务: {order.task.title}",
        out_trade_no=out_trade_no,
        amount={'total': int(order.amount * 100), 'currency': 'CNY'},
        profit_sharing='Y'  # 开启分账
    )
    
    order.transaction_id = out_trade_no
    order.payment_method = 'wechat'
    db.commit()
    
    return {'code_url': code_url, 'out_trade_no': out_trade_no}

async def execute_profit_sharing(order_id: int):
    """执行分账：10%平台 + 90%接单者"""
    order = db.query(Order).filter(Order.id == order_id).first()
    
    result = wxpay.profit_sharing(
        transaction_id=order.transaction_id,
        out_order_no=f"SHARE_{order.id}_{int(time.time())}",
        receivers=[
            {
                'type': 'MERCHANT_ID',
                'account': 'PLATFORM_MCHID',
                'amount': int(order.platform_fee * 100),
                'description': '平台服务费'
            },
            {
                'type': 'PERSONAL_OPENID',
                'account': order.freelancer.wechat_openid,
                'amount': int(order.freelancer_income * 100),
                'description': '任务收入'
            }
        ]
    )
    
    return result
```

---

## 🧪 测试数据示例（高校线下任务场景）

### Mock任务数据
```sql
-- 插入测试任务（高校场景）
INSERT INTO tasks (poster_id, title, description, budget_min, budget_max, location, deadline, status, published_at) VALUES
(1, '帮忙早八课程签到（本周三次）', '微积分早八课，本周三、周五需要代签到两次。教室在理科楼A301，早上7:50前到即可。要求同校学生，可以提供学生证照片核实身份。', 30, 50, '清华大学理科楼A301', '2025-10-25 07:50:00', 'published', NOW()),
(2, '毕业论文数据标注（500条）', '需要标注500条文本数据用于毕业论文实验，内容是情感分析（正面/负面/中性）。提供详细标注指南，每条约50字，预计3小时完成。要求认真负责，准确率高。', 80, 120, '清华大学（线上完成）', '2025-10-26 23:59:00', 'published', NOW()),
(3, '导师科研项目临时助理（3天）', '协助导师完成科研项目的文献整理和数据录入工作。需要在实验室现场工作，每天2-3小时，连续3天。要求：熟悉Office软件，有科研经历优先，理工科背景。', 200, 300, '清华大学化学楼实验室', '2025-10-23 18:00:00', 'published', NOW()),
(4, '高数作业辅导（一对一）', '需要高数学霸帮忙讲解本周作业题（约15道题），主要是多元函数微积分。可以线下图书馆见面讲解，或线上视频辅导2小时。要求：高数成绩优秀，有耐心，讲解清晰。', 60, 100, '清华大学图书馆', '2025-10-25 20:00:00', 'published', NOW()),
(5, '社团活动现场帮手（周六下午）', '社团举办校园音乐节，需要3名现场帮手协助布置场地、引导观众、维持秩序。时间：本周六下午2点到6点，地点：大礼堂广场。提供工作餐和社团纪念T恤。', 80, 100, '清华大学大礼堂广场', '2025-10-27 14:00:00', 'published', NOW());

-- 插入任务技能标签
INSERT INTO task_skills (task_id, skill_name) VALUES
(1, '同校学生'), (1, '早起'), (1, '守时'),
(2, '数据标注'), (2, '细心认真'), (2, '中文阅读理解'),
(3, 'Office办公'), (3, '文献整理'), (3, '数据录入'), (3, '科研经历'),
(4, '高等数学'), (4, '一对一辅导'), (4, '讲解能力'),
(5, '活动组织'), (5, '沟通能力'), (5, '体力充沛');
```

### Mock用户数据（高校场景）
```sql
-- 插入测试用户（接单者）
INSERT INTO user_profiles (user_id, name, avatar, birthday, location, one_sentence_intro, bio, completion_rate, average_rating, completed_tasks_count) VALUES
(10, '李华', '📚', '2003-05-15', '清华大学', '数据分析经验丰富，帮助过多位同学完成毕业论文数据处理', '计算机大三学生，有两年数据分析经验，擅长Python和数据标注工作。完成过20+同学的数据处理任务，准确率高，交付及时。', 98.5, 4.9, 23),
(11, '王芳', '🎓', '2004-08-20', '清华大学', '数学竞赛一等奖，擅长用通俗易懂的方式讲解复杂概念', '数学大二学生，高等数学满分，多次获得数学竞赛奖项。有丰富的一对一辅导经验，能够用简单的语言解释复杂的数学概念。', 100.0, 5.0, 15),
(12, '张小明', '🎤', '2002-11-10', '清华大学', '学生会活动部部长，组织过多场大型校园活动', '传媒大四学生，学生会活动部部长，有丰富的活动组织和现场协调经验。擅长摄影和视频剪辑，参与过校内多场大型活动的策划和执行。', 95.0, 4.7, 30);

-- 插入用户技能
INSERT INTO user_skills (user_id, skill_name) VALUES
(10, 'Python'), (10, '数据分析'), (10, '数据标注'), (10, 'Pandas'), (10, 'Excel'),
(11, '高等数学'), (11, '线性代数'), (11, '概率论'), (11, '一对一辅导'), (11, '讲解能力'),
(12, '活动组织'), (12, '摄影'), (12, '视频剪辑'), (12, '主持'), (12, 'Premiere');
```

### API响应示例（高校场景）
```json
// GET /api/tasks/search?university=清华大学&category=课程辅导
{
  "tasks": [
    {
      "id": 4,
      "title": "高数作业辅导（一对一）",
      "description": "需要高数学霸帮忙讲解本周作业题...",
      "budget": "¥60-100",
      "deadline": "还剩3天",
      "location": "清华大学图书馆",
      "poster": {
        "name": "赵敏",
        "university": "清华大学",
        "verified": true,
        "poster_rating": 5.0,
        "on_time_payment_rate": 100
      },
      "skills_required": ["高等数学", "一对一辅导", "讲解能力"],
      "application_count": 10,
      "view_count": 25,
      "category": "课程辅导"
    }
  ]
}

// GET /api/freelancers/search?skills=数据标注&university=清华大学
{
  "freelancers": [
    {
      "id": 10,
      "name": "李华",
      "avatar": "📚",
      "university": "清华大学",
      "verified": true,
      "one_sentence_intro": "数据分析经验丰富，帮助过多位同学完成毕业论文数据处理",
      "skills": ["Python", "数据分析", "数据标注", "Pandas", "Excel"],
      "stats": {
        "completion_rate": 98.5,
        "average_rating": 4.9,
        "completed_tasks_count": 23,
        "response_time": "1小时内"
      }
    }
  ]
}
```

---

## 📋 后端实施优先级（更新v2.0）

### Phase 1: 数据库调整（3-4天）
- ✅ 修改user_profiles表（删除goals/demands/resources，新增stat字段）
- ✅ 创建8个新表（tasks, task_applications, orders, reviews等）
- ✅ 创建task_views表（浏览记录）
- ✅ 创建响应时间计算触发器
- ✅ 创建平台抽成计算触发器

### Phase 2: 核心API开发（5-7天）
- ✅ 任务发布API（AI生成 + 用户修改）
- ✅ 任务搜索API（删除matchScore/whyMatch返回值）
- ✅ 申请任务API
- ✅ 订单创建API
- ✅ 浏览记录API
- ✅ 任务修改权限控制（禁止修改已发布）
- ✅ 订单状态流转
- ✅ 评价系统
- ✅ Stat自动计算

### Phase 3: 支付集成（3-4天）
- ⏳ 配置微信支付商户号（待提供）
- ✅ 微信支付分账对接
- ✅ 支付回调处理
- ✅ 提现功能（10元起，0手续费）

### Phase 4: 定时任务与优化（2天）
- ✅ 7天自动确认订单
- ✅ 24小时截止提醒
- ✅ 消息通知（订单状态变更）

### Phase 5: 测试与部署（2-3天）
- ✅ 端到端测试
- ✅ 数据迁移
- ✅ 生产部署

---

**文档版本**：v2.0  
**最后更新**：2025-10-22  
**状态**：✅ 已根据PIVOT_UNCERTAINTIES.md确认决策更新  
**待提供**：微信支付商户号
