# Ques 快索



Ques is an AI-powered networking and matchmaking agent for university students, alumni, and faculty that connects you with the person you’re looking for. Ques finds users with two-way potential while chatting with you, and shows you their profile cards. If someone catches your interest, you can privately share your WeChat ID, allowing them to view your profile and decide whether to connect. Ques works for both professional networking and casual friendships, with a chat bot interface and swipeable profile cards designed for meaningful connections based on mutual benefit.



快索是一个AI驱动的社交匹配智能体。它面向高校学生、校友及教职员工，连接你想要找的人。快索会通过与你聊天对话精准搜寻具有双向连接潜力的用户，并向你展示他们的资料卡片。若遇到感兴趣的对象，你可以私密分享微信ID，对方将有机会查看资料并决定是否建立联系。快索适用于职业人脉拓展与休闲社交，采用聊天机器人交互与可滑动资料卡片设计，致力于在互利基础上促成有意义的连接。



CoFounders:


Rhys: CTO | Frontend + Design


Cody: CEO | Marketing + Product Management + Legality


Jimmy: Founding Engineer | Algorithms + Website +Materials


William: COO | Backend + Cameraman
