# Ques 平台 Pivot 前端设计方案
## 从"AI人才匹配平台" → "校园任务接单平台"（AI驱动版Upwork）

**核心定位**：AI时代下的校园版Upwork，支持线下工作（地理匹配），通过AI对话完成任务创建和匹配

**🎓 产品定位 - 高校线下任务场景**：

专注于**大学校园内的线下单次任务**，解决同学之间的互助需求。核心场景包括：

1. **课程学习辅助**
   - 课程辅导（高数、线代、物理等）
   - 作业答疑（一对一讲解）
   - 考前突击复习
   - 帮忙代签到（早八课、选修课）
   - 课堂代做笔记

2. **学术科研支持**
   - 导师科研项目临时助理
   - 毕业论文数据标注/整理
   - 文献查找和翻译
   - 问卷调查发放和回收
   - 实验数据录入

3. **校园活动帮手**
   - 社团活动现场人手（音乐节、运动会、展览）
   - 迎新志愿者
   - 活动摄影摄像
   - 场地布置和物资搬运
   - 主持/表演临时演员

4. **生活便利服务**
   - 代取快递/外卖
   - 帮忙占座位（图书馆、自习室）
   - 失物寻找
   - 宠物临时照看
   - 拼车/拼单

5. **技能外包任务**
   - PPT/Word文档排版美化
   - 海报设计（社团招新、活动宣传）
   - 短视频剪辑（作品集、Vlog）
   - 代码调试（Python作业、网页设计）
   - 英文润色和翻译

**特点**：
- ✅ **校内认证**：仅限同校学生，确保安全可靠
- ✅ **线下为主**：任务多需面对面完成（签到、辅导、搬运等）
- ✅ **小额高频**：单笔金额¥30-300，快速结算
- ✅ **技术含量适中**：大学生可完成的单次任务
- ✅ **时间灵活**：契合课余时间和周末安排

**最小改动原则**：复用100%现有UI组件，仅修改文案和数据字段映射

---

## 🎯 核心产品变化

### 原产品逻辑
- 用户填写档案（技能、目标、需求、资源）
- AI匹配"互相需要"的人
- Whisper匿名消息建立联系
- 揭示身份后深入交流

### 新产品逻辑
- **接单者**：填写档案（技能、作品集）→ 与AI聊天找任务 → 看到任务卡片 → 申请任务 → 沟通 → 确认合作并支付 → 完成任务 → 验收评价
- **发单者**：与AI聊天描述需求 → AI生成任务卡片供确认/修改 → 发布任务 → 看到接单者申请 → 选择合适的人 → 确认合作收到支付 → 验收 → 评价

### 关键改变
1. ✅ **双角色模式**：在搜索框旁加角色切换开关（接单者⇄发单者）
2. ✅ **AI对话驱动**：任务创建/查找都通过AI对话完成，不再是表单填写
3. ✅ **卡片内容分离**：接单者看任务卡片（任务详情），发单者看接单者卡片（人的档案）
4. ❌ **删除字段**：goals、demands、resources（AI对话中体现）
5. ❌ **删除Receives**：改用核心stat展示（完成率、评分等）
6. ❌ **取消匿名**：任务申请直接展示完整档案
7. ❌ **取消Pro会员**：改为平台抽成10%盈利模式

---

## 📊 现有设计系统分析

### ✅ UI组件库（Shadcn/UI - 完全复用）
- **基础组件**：Button, Input, Textarea, Select, Checkbox, Switch
- **反馈组件**：Dialog, Alert, Toast(Sonner), Badge, Progress
- **布局组件**：Card, Tabs, Separator, Accordion, Sheet
- **导航组件**：BottomNavigation, NavigationMenu, Breadcrumb
- **数据展示**：Table, Avatar, Skeleton, Chart
- **交互组件**：Slider, Calendar, Popover, HoverCard, Drawer

### ✅ 核心页面组件（复用策略）
1. `WelcomeScreen.tsx` - ✅ 完全保留，仅改文案
2. `ProfileSetupWizard.tsx` - ⚠️ 简化为5步（删除goals/demands/resources）
3. `ChatInterface.tsx` - 🔴 重要改动：添加角色切换 + AI对话生成任务
4. `ChatCards.tsx` - 🔴 重要改动：根据角色显示不同卡片内容
5. `ProfileView.tsx` - ⚠️ 简化字段，仅保留核心stat
6. `WhisperMessageDialog.tsx` - ⚠️ 取消匿名，改为直接沟通
7. `ContactHistory.tsx` - ✅ 复用为订单列表
8. `NotificationPanel.tsx` - ✅ 仅改通知文案
9. `SettingsScreen.tsx` - ⚠️ 删除Receives/Pro相关设置
10. `PhysicsTagContainer.tsx` - ✅ 完全保留
11. `ReceivesBar.tsx` - ❌ 删除组件

---

## 🔄 数据字段映射（Profile接口复用）

| 原字段 | 接单者视角 | 发单者视角（任务） | 是否保留 |
|--------|-----------|-----------------|---------|
| `id` | 接单者ID | 发单者ID | ✅ |
| `name` | 接单者昵称 | 发单者昵称 | ✅ |
| `avatar` | 接单者头像 | 发单者头像 | ✅ |
| `birthday` | 年龄 | - | ✅ |
| `gender` | 性别 | - | ✅ |
| `location` | 地点 | 任务地点 | ✅ |
| `oneSentenceIntro` | 个人简介 | - | ✅ |
| `bio` | 详细介绍 | **任务详细描述** | ✅ 复用 |
| `skills` | 我的技能 | **任务所需技能** | ✅ 复用 |
| `hobbies` | 爱好 | - | ✅ |
| `languages` | 语言能力 | - | ✅ |
| `projects` | **作品集** | **任务参考图/附件** | ✅ 复用 |
| `institutions` | 学校/公司 | 发单者学校 | ✅ |
| `university` | 大学 | 发单者大学 | ✅ |
| `goals` | - | - | ❌ 删除 |
| `demands` | - | - | ❌ 删除 |
| `resources` | - | - | ❌ 删除 |
| `matchScore` | 匹配度 | 匹配度 | ✅ |
| `whyMatch` | AI理由 | AI理由 | ✅ |
| `receivesLeft` | - | - | ❌ 删除 |
| **新增字段** | | | |
| `budget` | - | 任务预算（¥100-150） | ➕ 新增 |
| `deadline` | - | 截止时间（还剩2天） | ➕ 新增 |
| `completionRate` | 完成率（95%） | - | ➕ 新增 |
| `averageRating` | 平均评分（4.8★） | 发单者评分 | ➕ 新增 |
| `completedTasksCount` | 完成任务数（23单） | 历史发单数 | ➕ 新增 |
| `responseTime` | 响应速度（1h内） | - | ➕ 新增 |
| `onTimePaymentRate` | - | 按时付款率（100%） | ➕ 新增 |

---

## 📝 关键页面修改方案

### 1️⃣ **AI聊天主界面** (`ChatInterface.tsx`) - 🔴 核心改动

#### 新增：角色切换开关 + 文件上传按钮

**🎨 设计要求**：
- ✅ **使用开关插件**（Switch组件），不使用emoji+文字按钮
- ✅ **位置**：输入框上方（而非页面顶部），左侧对齐
- ✅ **标签文字**：接单 / 发单（无emoji）
- ✅ **文件上传按钮**：开关旁边，用于上传参考图、附件等

```tsx
// ChatInterface.tsx - 在输入框上方添加
<div className="px-4 py-2 bg-gray-50 border-t border-gray-200 flex items-center justify-between">
  {/* 左侧：角色切换开关 */}
  <div className="flex items-center gap-3">
    <Label className="text-sm text-gray-600">模式</Label>
    <div className="flex items-center gap-2">
      <span className={`text-xs ${currentRole === 'freelancer' ? 'font-medium text-blue-600' : 'text-gray-400'}`}>
        接单
      </span>
      <Switch
        checked={currentRole === 'poster'}
        onCheckedChange={(checked) => {
          setCurrentRole(checked ? 'poster' : 'freelancer')
          showToast({
            message: checked ? '已切换到发单模式' : '已切换到接单模式',
            icon: '✅'
          })
        }}
      />
      <span className={`text-xs ${currentRole === 'poster' ? 'font-medium text-blue-600' : 'text-gray-400'}`}>
        发单
      </span>
    </div>
    
    {/* 文件上传按钮 */}
    <Button
      variant="outline"
      size="sm"
      className="h-8 gap-1.5"
      onClick={() => fileInputRef.current?.click()}
    >
      <Paperclip size={14} />
      <span className="text-xs">上传文件</span>
    </Button>
    <input
      ref={fileInputRef}
      type="file"
      multiple
      accept="image/*,.pdf,.doc,.docx"
      className="hidden"
      onChange={handleFileUpload}
    />
    
    {/* 已上传文件列表 */}
    {uploadedFiles.length > 0 && (
      <div className="flex gap-1">
        {uploadedFiles.map((file, idx) => (
          <Badge key={idx} variant="secondary" className="text-xs px-2 py-0.5">
            📎 {file.name.slice(0, 10)}...
            <X 
              size={12} 
              className="ml-1 cursor-pointer" 
              onClick={() => removeFile(idx)}
            />
          </Badge>
        ))}
      </div>
    )}
  </div>
  
  {/* 右侧：可选的其他按钮（如清空对话等） */}
  <Button variant="ghost" size="sm">
    <Trash2 size={14} />
  </Button>
</div>

{/* Input Area - 紧接着上面的控件 */}
<div className="p-4 border-t border-gray-200 bg-white">
  <div className="flex items-center gap-2">
    <Input
      value={inputValue}
      onChange={(e) => setInputValue(e.target.value)}
      onKeyPress={handleKeyPress}
      placeholder={currentRole === 'freelancer' ? '找任务...' : '找人帮忙...'}
      className="flex-1 rounded-full"
    />
    <Button onClick={handleSend} size="sm" className="rounded-full">
      <Send size={14} />
    </Button>
  </div>
</div>
```

**文件上传逻辑**：

```typescript
const [uploadedFiles, setUploadedFiles] = useState<File[]>([])
const fileInputRef = useRef<HTMLInputElement>(null)

const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
  const files = Array.from(e.target.files || [])
  
  // 验证文件大小和类型
  const validFiles = files.filter(file => {
    if (file.size > 10 * 1024 * 1024) {  // 10MB限制
      showToast({ message: `${file.name} 超过10MB`, type: 'error' })
      return false
    }
    return true
  })
  
  setUploadedFiles(prev => [...prev, ...validFiles])
  
  // 发送给AI时附带文件信息
  if (validFiles.length > 0) {
    showToast({ 
      message: `已添加 ${validFiles.length} 个文件，发送消息时将一起上传`,
      icon: '📎'
    })
  }
}

const removeFile = (index: number) => {
  setUploadedFiles(prev => prev.filter((_, idx) => idx !== index))
}

// 发送消息时上传文件
const handleSendMessage = async () => {
  if (!inputValue.trim() && uploadedFiles.length === 0) return
  
  // 先上传文件获取URLs
  const fileUrls = await uploadFilesToCloud(uploadedFiles)
  
  // 发送消息+文件URLs给AI
  await sendMessage({
    content: inputValue,
    attachments: fileUrls.map(url => ({ type: 'file', url }))
  })
  
  setUploadedFiles([])  // 清空已上传列表
}
```

#### 修改：Bot欢迎语（根据角色不同）

```typescript
// 接单者模式
const freelancerWelcome = `你好！我是你的任务助手 🤖

我可以帮你：
• 搜索适合你的任务
• 了解任务详情
• 管理订单和收益

试试说"找个设计的活儿"或"有什么PS的单吗"`

// 发单者模式
const posterWelcome = `你好！我是你的任务助手 🤖

我可以帮你：
• 发布任务找人帮忙
• 完善任务需求
• 管理发布的任务

试试说"我想找人做海报"或"需要一个视频剪辑"`
```

#### 🔴 新增：AI生成任务卡片（发单者专用）

**触发时机**：AI检测到用户意图是"发布任务"（非搜索接单者）

**流程**：
1. 发单者与AI对话："我想找人做海报，预算100元，3天内完成"
2. AI理解意图，询问细节："需要什么风格的海报？有参考图吗？"
3. 发单者补充信息："扁平化设计，用于活动宣传，有参考图"
4. 发单者上传参考图（通过文件上传按钮）
5. AI调用后端 `POST /api/tasks/create-from-conversation` 生成任务草稿
6. 前端渲染任务预览卡片，供发单者确认/编辑
7. 发单者点击"发布任务"→ 调用 `POST /api/tasks/{task_id}/publish`

```tsx
// 🔴 新增：AI生成的任务预览卡片组件
<TaskPreviewCard
  mode="preview"  // 'preview' | 'draft' | 'published'
  task={{
    id: 123,
    title: "活动海报设计",
    budget: { min: 80, max: 120 },
    deadline: "2025-11-01",
    skills: ['平面设计', 'Photoshop', '扁平化'],
    description: "需要一张扁平化风格的活动宣传海报，尺寸1920x1080，用于社团招新...",
    attachments: [
      { type: 'reference', url: 'https://...' }
    ]
  }}
  onEdit={() => {
    // ⚠️ 不确定点13：是否允许手动编辑？
    // 如果允许，打开TaskEditDialog
    openTaskEditDialog(task.id)
  }}
  onPublish={async () => {
    await publishTask(task.id)
    showToast('任务已发布！等待接单者申请')
  }}
  onRegenerate={() => {
    // 返回对话界面，保留上下文重新生成
    continueConversation()
  }}
/>
```

**UI设计**：
- 复用现有 `ChatCards.tsx` 样式
- 顶部显示"📝 任务草稿预览"标签
- 右上角操作按钮："✏️ 编辑" "🔄 重新生成" "✅ 发布"
- 预览时禁用滑动操作（不可左右滑）

**数据流**：
```
用户对话 → GLM-4分析 → 后端生成draft → 前端渲染预览 → 用户确认 → 状态改为published
```

---

### 2️⃣ **卡片滑动页** (`ChatCards.tsx`) - 🔴 核心改动

#### 双模式卡片设计

**关键原则**：
- 接单者看到的是"任务卡片"（显示任务详情+发单者简介）
- 发单者看到的是"接单者卡片"（显示完整接单者档案）
- 卡片封面必须是真实用户头像（非图标背景）⚠️ 用户强制要求

**⚠️ 不确定点14**：如果用户未上传头像，显示什么？（见PIVOT_UNCERTAINTIES.md）

---

#### 🔴 接单者模式 - 任务卡片设计

**✅ 用户决策**：
- 删除字段：👤 发布者名字（展开前不显示）、👥 已有X人申请
- 新增字段：内容详情（任务具体描述）

**卡片折叠态**（未点击查看详情）：

```tsx
<Card className="task-card">
  {/* ✅ 顶部：发单者头像 + 名字 + 任务标题的组合布局 */}
  <div className="flex items-start gap-3 mb-3">
    {/* 发单者头像（作为卡片图片） */}
    <Avatar 
      src={task.poster.avatar}  // 发单者真实头像
      size="large"  // 较大尺寸，作为视觉焦点
      fallback={task.poster.name[0]}
      className="flex-shrink-0"
    />
    
    {/* 右侧：发单者名字 + 任务标题 */}
    <div className="flex-1 min-w-0">
      {/* ✅ 发单者名字 */}
      <p className="text-sm text-gray-500 mb-1">
        {task.poster.name}  // 例如："张三"
      </p>
      
      {/* ✅ 任务标题 */}
      <h3 className="text-lg font-semibold line-clamp-2">
        {task.title}  // 例如："设计校园活动海报"
      </h3>
    </div>
  </div>
  
  {/* ✅ 内容详情（简短描述） */}
  <p className="text-sm text-gray-600 line-clamp-2 mb-3">
    {task.description}  // 例如："需要一张扁平化风格的活动宣传海报..."
  </p>
  
  {/* 预算显示 */}
  <div className="flex items-center gap-2 mb-2">
    <span className="text-orange-500 font-bold text-xl">
      ¥{task.budgetMin}-{task.budgetMax}
    </span>
    <span className="text-sm text-gray-500">📍 {task.location || '线上'}</span>
  </div>
  
  {/* 所需技能标签 */}
  <div className="flex flex-wrap gap-2 mb-2">
    {task.skills.map(skill => (
      <Badge key={skill} variant="skill">{skill}</Badge>
    ))}
  </div>
  
  {/* 截止时间（红色提示） */}
  <div className="flex items-center text-red-500 text-sm">
    <Clock className="w-4 h-4 mr-1" />
    <span>还剩 {formatDeadline(task.deadline)}</span>  // 例如："2天15小时"
  </div>
</Card>
```

**卡片展开态**（点击"详情"按钮后）：

```tsx
<Card className="task-card-expanded">
  {/* 1. 任务详细描述 */}
  <section>
    <h4 className="text-base font-semibold mb-2">任务描述</h4>
    <p className="text-gray-700 leading-relaxed">
      {task.description}  // 对应数据库 tasks.description
    </p>
  </section>
  
  {/* 2. 交付要求（AI提取或发单者补充） */}
  <section>
    <h4 className="text-base font-semibold mb-2">交付要求</h4>
    <ul className="list-disc list-inside space-y-1">
      {task.deliverables.map(item => (
        <li key={item}>{item}</li>
      ))}
    </ul>
    {/* 示例：
    - 提供源文件（PSD格式）
    - 尺寸：1920x1080px
    - 提供3个设计方案供选择
    */}
  </section>
  
  {/* 3. 参考图片/附件 */}
  {task.attachments.length > 0 && (
    <section>
      <h4 className="text-base font-semibold mb-2">参考图片</h4>
      <div className="grid grid-cols-2 gap-2">
        {task.attachments.map(file => (
          <img 
            key={file.id}
            src={file.url} 
            alt="参考图"
            className="rounded cursor-pointer"
            onClick={() => openImagePreview(file.url)}
          />
        ))}
      </div>
    </section>
  )}
  
  {/* 4. 发单者信息（精简版） - 展开后才显示名字 */}
  <section className="bg-gray-50 p-3 rounded">
    <h4 className="text-base font-semibold mb-2">发单者信息</h4>
    <div className="flex items-center gap-3">
      <Avatar src={task.poster.avatar} size="medium" />
      <div className="flex-1">
        <p className="font-medium">{task.poster.name}</p>  {/* ✅ 这里才显示名字 */}
        <p className="text-sm text-gray-500">{task.poster.university.name}</p>
        
        {/* ✅ 用户决策：只保留最重要的stat（评分、发布任务数） */}
        <div className="flex gap-2 mt-2">
          <Badge variant="outline" size="sm">
            ★ {task.poster.posterRating.toFixed(1)}
          </Badge>
          <Badge variant="outline" size="sm">
            发布 {task.poster.postedTasksCount}个任务
          </Badge>
        </div>
      </div>
    </div>
  </section>
  
  {/* 操作按钮 */}
  <div className="flex gap-2 mt-4">
    <Button 
      variant="primary" 
      className="flex-1"
      onClick={() => applyForTask(task.id)}
    >
      立即申请
    </Button>
    <Button 
      variant="outline"
      onClick={() => contactPoster(task.poster.id)}
    >
      联系发单者
    </Button>
  </div>
</Card>
```

---

#### 🔴 发单者模式 - 接单者卡片设计

**✅ 用户决策**：
- 删除字段：⚡ 平均响应时间、95%完成率（暂不统计）
- 保留字段：保证Profile中填写的内容都在卡片展开页显示

**卡片折叠态**：

```tsx
<Card className="freelancer-card">
  {/* ✅ 顶部：接单者头像 + 名字的组合布局 */}
  <div className="flex items-start gap-3 mb-3">
    {/* 接单者头像（作为卡片图片） */}
    <Avatar 
      src={freelancer.avatar} 
      size="large"  // 较大尺寸，作为视觉焦点
      fallback={freelancer.name[0]}
      className="flex-shrink-0"
    />
    
    {/* 右侧：接单者名字 + 学校 */}
    <div className="flex-1 min-w-0">
      {/* ✅ 接单者名字 */}
      <h3 className="text-lg font-semibold mb-1">{freelancer.name}</h3>
      
      {/* 学校信息 */}
      <p className="text-sm text-gray-500">{freelancer.university.name}</p>
    </div>
  </div>
  
  {/* 技能标签 */}
  <div className="flex flex-wrap gap-2 mb-3">
    {freelancer.skills.map(skill => (
      <Badge key={skill} variant="skill">{skill}</Badge>
    ))}
  </div>
  
  {/* ✅ 简化stat（删除完成率和响应时间） - 只保留最核心的3个 */}
  <div className="flex justify-between text-sm">
    <div className="text-center">
      <p className="font-semibold text-orange-500">{freelancer.averageRating.toFixed(1)}</p>
      <p className="text-gray-500">评分</p>
    </div>
    <div className="text-center">
      <p className="font-semibold text-orange-500">{freelancer.completedTasksCount}</p>
      <p className="text-gray-500">完成任务</p>
    </div>
    <div className="text-center">
      <p className="font-semibold text-orange-500">{freelancer.age || '未知'}岁</p>
      <p className="text-gray-500">年龄</p>
    </div>
  </div>
</Card>
```

**卡片展开态**（显示完整接单者档案）：

```tsx
<Card className="freelancer-card-expanded">
  {/* 1. 个人简介 */}
  <section>
    <h4 className="text-base font-semibold mb-2">个人简介</h4>
    <p className="text-gray-700">{freelancer.bio || freelancer.oneSentenceIntro}</p>
  </section>
  
  {/* 2. 作品集 */}
  <section>
    <h4 className="text-base font-semibold mb-2">作品集</h4>
    <div className="grid grid-cols-2 gap-3">
      {freelancer.projects?.map(work => (
        <div key={work.id} className="cursor-pointer" onClick={() => openPortfolio(work)}>
          <img src={work.referenceLinks?.[0]} className="rounded w-full aspect-square object-cover" />
          <p className="text-sm mt-1">{work.title}</p>
        </div>
      ))}
    </div>
  </section>
  
  {/* ✅ 3. 显示Profile中的所有内容（hobbies, languages, skills, institutions等） */}
  <section className="space-y-3">
    {/* 爱好 */}
    {freelancer.hobbies?.length > 0 && (
      <div>
        <h4 className="text-sm font-semibold mb-1">爱好</h4>
        <div className="flex flex-wrap gap-2">
          {freelancer.hobbies.map(hobby => (
            <Badge key={hobby} variant="outline">{hobby}</Badge>
          ))}
        </div>
      </div>
    )}
    
    {/* 语言能力 */}
    {freelancer.languages?.length > 0 && (
      <div>
        <h4 className="text-sm font-semibold mb-1">语言能力</h4>
        <div className="flex flex-wrap gap-2">
          {freelancer.languages.map(lang => (
            <Badge key={lang} variant="outline">{lang}</Badge>
          ))}
        </div>
      </div>
    )}
    
    {/* 学校/机构 */}
    {freelancer.institutions?.length > 0 && (
      <div>
        <h4 className="text-sm font-semibold mb-1">教育/工作经历</h4>
        {freelancer.institutions.map(inst => (
          <div key={inst.name} className="flex items-center gap-2 text-sm">
            <School className="w-4 h-4" />
            <span>{inst.name} - {inst.role}</span>
            {inst.verified && <Badge variant="success" size="xs">✓</Badge>}
          </div>
        ))}
      </div>
    )}
  </section>
  
  {/* 4. 接单数据（删除完成率和响应时间） */}
  <section className="bg-gray-50 p-3 rounded">
    <h4 className="text-base font-semibold mb-2">接单数据</h4>
    <div className="grid grid-cols-2 gap-3 text-sm">
      <div>
        <span className="text-gray-600">平均评分：</span>
        <span className="font-semibold ml-1">{freelancer.averageRating?.toFixed(2) || '暂无'} ★</span>
      </div>
      <div>
        <span className="text-gray-600">已完成任务：</span>
        <span className="font-semibold ml-1">{freelancer.completedTasksCount || 0}个</span>
      </div>
    </div>
  </section>
  
  {/* 4. 评价列表（最近3条） */}
  <section>
    <h4 className="text-base font-semibold mb-2">最近评价</h4>
    {freelancer.recentReviews.slice(0, 3).map(review => (
      <div key={review.id} className="border-l-2 border-blue-400 pl-3 mb-3">
        <div className="flex items-center gap-2 mb-1">
          <span className="text-orange-500">★ {review.overallRating.toFixed(1)}</span>
          <span className="text-sm text-gray-500">{formatDate(review.createdAt)}</span>
        </div>
        <p className="text-sm text-gray-700">{review.comment}</p>
      </div>
    ))}
  </section>
  
  {/* 操作按钮 */}
  <div className="flex gap-2 mt-4">
    <Button 
      variant="primary" 
      className="flex-1"
      onClick={() => inviteFreelancer(freelancer.id)}
    >
      邀请接单
    </Button>
    <Button 
      variant="outline"
      onClick={() => viewFullProfile(freelancer.id)}
    >
      查看主页
    </Button>
  </div>
</Card>
```

---

#### 🔴 数据字段映射总结

| 原Profile字段 | 接单者卡片用途 | 任务卡片用途 |
|--------------|--------------|-------------|
| `avatar` | 接单者头像 | 发单者头像 |
| `name` | 接单者昵称 | 发单者昵称 |
| `bio` | 个人简介 | **任务描述** |
| `skills` | 擅长技能 | **所需技能** |
| `projects` | 作品集 | **参考图/附件** |
| `completionRate` | ✅ 显示 | ❌ 不显示 |
| `averageRating` | ✅ 显示 | 发单者评分（posterRating） |
| `completedTasksCount` | ✅ 已完成任务数 | 发单者发布数（postedTasksCount） |
| `responseTime` | ✅ 响应速度 | ❌ 不显示 |
| `onTimePaymentRate` | ❌ 不显示 | ✅ 按时付款率 |

---

#### 卡片滑动逻辑调整

**角色切换行为**（根据决策#13）：

```tsx
const handleRoleChange = (newRole: 'freelancer' | 'poster') => {
  setCurrentRole(newRole)
  
  // ✅ 清空当前卡片栈
  setProfiles([])
  setCurrentIndex(0)
  
  // ✅ 显示提示Toast
  showToast({
    message: newRole === 'freelancer' 
      ? '已切换到接单模式，开始搜索任务吧！' 
      : '已切换到发单模式，搜索优质接单者',
    duration: 2000
  })
  
  // ✅ 不自动刷新，等待用户手动搜索
}
  
  {/* 核心stat */}
  <section>
    <h4>工作数据</h4>
    <div className="grid grid-cols-2 gap-4">
      <StatCard label="完成率" value={`${profile.completionRate}%`} />
      <StatCard label="平均评分" value={`${profile.averageRating}★`} />
      <StatCard label="完成任务" value={`${profile.completedTasksCount}单`} />
      <StatCard label="响应速度" value={profile.responseTime} />
    </div>
  </section>
  
```

**关键差异总结**：
| 元素 | 接单者看任务卡片 | 发单者看接单者卡片 |
|------|----------------|------------------|
| 头像 | 发单者头像 | 接单者头像 |
| 标题 | 任务标题 + 发单者昵称 | 接单者昵称 + 学校 |
| 展开内容主体 | **任务详情**（描述、要求、参考图） | **接单者档案**（作品集、经历） |
| stat展示 | 发单者评分、发单数、付款率 | 接单者完成率、评分、任务数 |

---

### 3️⃣ **档案创建向导** (`ProfileSetupWizard.tsx`) - ⚠️ 简化

#### 保留的步骤
1. ✅ 基本信息（Demographics）
2. ✅ 技能（Skills）
3. ✅ 作品集（Past Projects → Portfolio）
4. ✅ 个人简介（Bio）
5. ✅ 大学验证（University）
6. ✅ 身份认证（Authentication）

**从9步减少为6步**

#### 文案修改

```typescript
profileSetup: {
  // Step 2: Skills
  whatAreSkills: '你有哪些技能？',
  addTagsSkills: '添加技能标签，让发单者快速找到你',
  skillPlaceholder: '例如：PS设计、视频剪辑、Python、PPT制作',
  
  // Step 3: Projects（改名Portfolio）
  stepName: '作品集', // 原：过往项目
  yourPortfolio: '展示你的作品',
  portfolioDescription: '上传你最满意的作品，提升接单成功率',
  addPortfolio: '添加作品',
  portfolioTitle: '作品标题',
  portfolioDescField: '作品描述',
  portfolioImages: '作品图片（最多5张）',
}
```

---

### 4️⃣ **个人中心** (`ProfileView.tsx`) - ⚠️ 简化stat

**🎨 重要设计原则**：
- ✅ **保留原版ProfileView.tsx的设计风格**（Card-based sections布局）
- ✅ **不重新设计UI**，只是合并功能：档案 + 设置 + 交易信息
- ✅ 保留原有的可编辑sections、AI建议、完成度显示等特色功能
- ✅ 在原sections基础上添加两个新section：钱包、设置

#### 删除的元素
- ❌ ReceivesBar组件（虚拟货币相关）
- ❌ Goals模块（已删除字段）
- ❌ Demands模块（已删除字段）
- ❌ Resources模块（已删除字段）
- ❌ Pro会员相关UI（已取消Pro会员）

#### 新增sections（在原profileSections数组中添加）

```tsx
// 在ProfileView.tsx的profileSections数组末尾添加

{
  id: 'wallet',
  title: '钱包',
  icon: Wallet,
  content: (
    <div className="space-y-3">
      <div className="grid grid-cols-2 gap-3">
        <div className="bg-gradient-to-br from-green-50 to-green-100 p-3 rounded-lg">
          <div className="text-xs text-green-600">余额</div>
          <div className="text-xl font-bold text-green-700">¥{wallet.balance}</div>
        </div>
        <div className="bg-gradient-to-br from-blue-50 to-blue-100 p-3 rounded-lg">
          <div className="text-xs text-blue-600">冻结金额</div>
          <div className="text-xl font-bold text-blue-700">¥{wallet.frozen}</div>
        </div>
      </div>
      {/* 最近交易记录 */}
      <div className="space-y-2">
        {wallet.recentTransactions.map(tx => (
          <div className="flex items-center justify-between p-2 bg-gray-50 rounded-lg">
            <div className="flex items-center gap-2">
              {tx.type === 'income' ? <ArrowDownLeft /> : <ArrowUpRight />}
              <div>
                <div className="text-sm">{tx.description}</div>
                <div className="text-xs text-gray-500">{tx.date}</div>
              </div>
            </div>
            <div className={tx.type === 'income' ? 'text-green-600' : 'text-red-600'}>
              {tx.type === 'income' ? '+' : '-'}¥{tx.amount}
            </div>
          </div>
        ))}
      </div>
    </div>
  )
},
{
  id: 'settings',
  title: '设置',
  icon: Settings,
  content: (
    <div className="space-y-2">
      <button className="w-full flex items-center justify-between p-3 bg-gray-50 hover:bg-gray-100 rounded-lg">
        <div className="flex items-center gap-3">
          <Bell size={18} />
          <span className="text-sm">通知设置</span>
        </div>
        <ArrowUpRight size={16} className="text-gray-400" />
      </button>
      <button className="w-full flex items-center justify-between p-3 bg-gray-50 hover:bg-gray-100 rounded-lg">
        <div className="flex items-center gap-3">
          <Shield size={18} />
          <span className="text-sm">隐私设置</span>
        </div>
        <ArrowUpRight size={16} className="text-gray-400" />
      </button>
      {/* 更多设置项... */}
    </div>
  )
}
```

#### 保留并修改的stat卡片（在原Profile Summary Card中）

```tsx
// 顶部统计卡片（仅保留核心stat，不区分发单/接单）
const profileStats = [
  { 
    label: '完成率', 
    value: `${profile.completionRate}%`,
    icon: CheckCircle,
    description: '作为接单者的任务完成率',
  },
  { 
    label: '平均评分', 
    value: `${profile.averageRating.toFixed(1)}★`,
    icon: Star,
    description: '接单时收到的评分',
  },
  { 
    label: '完成任务', 
    value: `${profile.completedTasksCount}单`,
    icon: Briefcase,
    description: '作为接单者完成的任务数',
  },
  { 
    label: '发布任务', 
    value: `${profile.postedTasksCount}单`,
    icon: Upload,
    description: '作为发单者发布的任务数',
  },
]

// ✅ 无需角色切换Tab（因为在ChatInterface已经有了）
// ✅ 个人中心同时显示接单者和发单者数据
```

---

### 5️⃣ **Whisper消息** → **任务申请对话** (`WhisperMessageDialog.tsx`)

#### 取消匿名机制

```tsx
// 原：匿名状态
<div className="blur-sm">张***</div>

// 🔴 新：直接显示真实信息
<div className="flex items-center gap-3">
  <Avatar src={partner.avatar} />
  <div>
    <p className="font-medium">{partner.name}</p>
    <p className="text-sm text-gray-500">{partner.university.name}</p>
  </div>
</div>
```

#### 修改按钮

```tsx
// 原："揭示身份"
<Button onClick={handleRevealIdentity}>揭示身份</Button>

// 🔴 新："确认合作"
<Button onClick={handleConfirmCooperation}>
  确认合作并支付
</Button>
```

#### AI生成开场白

```typescript
// 接单者申请任务时
const applicationMessage = `您好！看到您发布的任务"${task.title}"，我有${mySkills.join('、')}的技能，曾完成过${myBestProject.title}，预计${estimatedDays}天完成，期待与您合作！`

// 发单者邀请接单者时
const invitationMessage = `您好！看到您的作品${portfolioTitle}，很符合我的任务需求，想邀请您完成"${task.title}"，预算${task.budget}，期待您的回复！`
```

---

### 6️⃣ **订单管理页**（复用`ContactHistory.tsx`）

```tsx
// 完全复用ContactHistory的UI
// 仅修改数据源和卡片内容

<Card className="order-card">
  {/* 左侧：任务类型图标（可选，或用头像） */}
  <Avatar src={order.partnerAvatar} />
  
  {/* 中部 */}
  <div className="flex-1">
    <h4 className="font-medium">{order.taskTitle}</h4>
    <div className="flex items-center gap-2 text-sm text-gray-500">
      <Badge variant={getStatusVariant(order.status)}>
        {getStatusText(order.status)}
      </Badge>
      <span>{order.partnerName}</span>
    </div>
  </div>
  
  {/* 右侧 */}
  <div className="text-right">
    <p className="text-lg font-bold text-orange-500">¥{order.amount}</p>
    <Button size="sm" variant="ghost">查看详情</Button>
  </div>
</Card>
```

---

### 7️⃣ **底部导航栏** (`BottomNav.tsx`) - ⚠️ 修改为4个Tab

**✅ 用户决策：方案A**（保留AI聊天作为首页核心，增加消息入口）

根据用户确认的导航方案：

```tsx
const navItems = [
  {
    icon: Bot,  // 🤖
    label: 'AI助手',
    route: '/home',  // ChatInterface
    description: '与AI聊天，创建/管理任务'
  },
  {
    icon: Clipboard,  // 📋
    label: '任务/订单',
    route: '/orders',  // 原ContactHistory改为订单列表
    description: '我的任务/我的订单'
  },
  {
    icon: MessageCircle,  // 💬
    label: '消息',
    route: '/messages',  // 新增：用户间聊天列表
    description: '与用户沟通'
  },
  {
    icon: User,  // 👤
    label: '我的',
    route: '/profile',
    description: '档案+钱包+设置'
  },
]
```

---

### 8️⃣ **设置页** (`SettingsScreen.tsx`) - 删除支付相关

#### 删除的菜单项
- ❌ "充值Receives"（废弃虚拟货币）
- ❌ "Pro会员升级"（取消会员制）
- ❌ "Receives使用情况"

#### 保留的菜单项
- ✅ 语言设置
- ✅ 外观主题
- ✅ 通知设置
- ✅ 微信号设置
- ✅ 条款与隐私
- ✅ 账户管理

#### 新增菜单项
- ➕ "我的钱包"（查看余额和提现）
- ➕ "收益明细"（查看历史收入）
- ➕ "支出记录"（发单支付历史）

---

## 📊 前端数据流总结

### API请求变化

**删除的API**：
```typescript
// ❌ 删除
DELETE /api/payments/topup-receives
DELETE /api/payments/upgrade-pro
DELETE /api/whispers/*
DELETE /api/settings/receives
```

**新增的API**：
```typescript
// ✅ 新增
POST /api/tasks/create-from-conversation  // AI生成任务草稿
POST /api/tasks/{id}/publish               // 发布任务
GET  /api/tasks/search                      // 搜索任务（接单者视角）
GET  /api/freelancers/search                // 搜索接单者（发单者视角）
POST /api/tasks/{id}/apply                  // 申请任务
POST /api/orders/{id}/pay                   // 支付订单
POST /api/orders/{id}/submit                // 提交交付物
POST /api/orders/{id}/approve               // 验收通过
POST /api/reviews/create                    // 评价
GET  /api/wallet/balance                    // 钱包余额
POST /api/wallet/withdraw                   // 提现申请
```

**修改的API**：
```typescript
// ⚠️ 修改响应结构
GET /api/users/{id}/profile
// 新增字段：
{
  completionRate: number,
  averageRating: number,
  completedTasksCount: number,
  responseTimeMinutes: number,
  postedTasksCount: number,
  onTimePaymentRate: number,
  posterRating: number,
}
// 删除字段：goals, demands, resources, receivesLeft
```

---

## 🎨 UI组件变更汇总

| 组件 | 状态 | 改动内容 |
|------|------|---------|
| `ChatInterface.tsx` | ⚠️ 修改 | 添加角色切换器、修改欢迎语、AI任务生成 |
| `ChatCards.tsx` | ⚠️ 重大修改 | 双模式卡片、字段语义映射、删除matchScore |
| `ProfileSetupWizard.tsx` | ⚠️ 简化 | 删除Goals/Demands/Resources步骤 |
| `ProfileView.tsx` | ⚠️ 简化 | 删除Receives/Pro会员UI、调整stat卡片 |
| `BottomNav.tsx` | ✅ 不变 | 保持3个Tab |
| `SettingsScreen.tsx` | ⚠️ 修改 | 删除支付菜单、新增钱包菜单 |
| `WhisperMessageDialog.tsx` | ⚠️ 改名 | 改为TaskApplicationDialog，取消匿名 |
| `ContactHistory.tsx` | ⚠️ 复用 | 改为显示订单列表 |

---

## 🔄 数据Schema变化（前端TypeScript类型）

```typescript
// ✅ 新增类型
interface Task {
  id: number
  posterId: number
  poster: {
    id: number
    name: string
    avatar: string
    university: { name: string }
    posterRating: number
    postedTasksCount: number
    onTimePaymentRate: number
  }
  title: string
  description: string
  budgetMin: number
  budgetMax: number
  deadline: string  // ISO date
  location: string
  skills: string[]
  attachments: { id: number; url: string; type: string }[]
  status: 'draft' | 'published' | 'in_progress' | 'completed' | 'cancelled'
  applicationCount: number
  createdAt: string
}

interface TaskApplication {
  id: number
  taskId: number
  freelancerId: number
  freelancer: UserProfile
  message: string
  quotedPrice: number
  estimatedDays: number
  status: 'pending' | 'accepted' | 'rejected'
  appliedAt: string
}

interface Order {
  id: number
  taskId: number
  task: Task
  posterId: number
  freelancerId: number
  amount: number
  platformFee: number
  freelancerIncome: number
  status: 'pending_payment' | 'paid' | 'in_progress' | 'submitted' | 'completed' | 'refunded'
  createdAt: string
  paidAt?: string
  completedAt?: string
  deliverables: { id: number; fileUrl: string; description: string }[]
}

interface Review {
  id: number
  orderId: number
  reviewerId: number
  revieweeId: number
  role: 'freelancer' | 'poster'
  qualityRating: number
  speedRating: number
  communicationRating: number
  overallRating: number
  comment: string
  createdAt: string
}

// ⚠️ 修改现有类型
interface UserProfile {
  // ... 原有字段
  
  // 🔴 删除
  // goals?: string[]
  // demands?: string[]
  // resources?: string[]
  // receivesLeft?: number
  
  // ✅ 新增
  completionRate: number
  averageRating: number
  completedTasksCount: number
  responseTimeMinutes: number
  postedTasksCount: number
  onTimePaymentRate: number
  posterRating: number
}
```

---

## ✅ 前端实施优先级

### Phase 1: 核心功能调整（1-2周）
1. ✅ ChatInterface添加角色切换器
2. ✅ ChatCards双模式卡片实现
3. ✅ 删除Goals/Demands/Resources步骤
4. ✅ API客户端更新（新增Task/Order相关请求）

### Phase 2: 任务发布流程（1周）
5. ✅ AI任务生成对话流程
6. ✅ TaskPreviewCard组件
7. ✅ 任务编辑表单（在聊天区显示）

### Phase 3: 订单支付流程（1周）
8. ✅ 支付页面集成
9. ✅ 订单状态展示
10. ✅ 交付物上传组件

### Phase 4: 评价与钱包（1周）
11. ✅ 评价表单
12. ✅ 钱包页面
13. ✅ 提现功能

---

**文档版本**：v1.1  
**最后更新**：2025-10-22  
**状态**：✅ 已更新（删除matchScore/whyMatch）
```

#### B. 接单者档案卡片（发单者视角）

**保留95%原设计**，仅修改：

```tsx
// ProfileView.tsx 或 ChatCards.tsx 中的接单者卡片

// 原："寻找"模块
<div>
  <h3>寻找</h3>
  <ul>{profile.demands.map(...)}</ul>
</div>

// 🔴 新："服务定价"模块
<div>
  <h3>服务定价</h3>
  <ul>
    {profile.services.map(service => (
      <li>
        {service.name}: ¥{service.minPrice}-{service.maxPrice}
      </li>
    ))}
  </ul>
</div>

// 🔴 新增："信用分"显示（在顶部统计区）
<div className="stat-card">
  <div className="text-2xl font-bold text-blue-600">120</div>
  <div className="text-xs text-gray-500">信用分</div>
</div>

// 🔴 新增："完成率"统计
<div className="stat-card">
  <div className="text-2xl font-bold">95%</div>
  <div className="text-xs text-gray-500">完成率</div>
</div>
```

**影响文件**：
- `src/components/ChatCards.tsx` (卡片渲染逻辑)
- `src/components/ProfileView.tsx` (完整档案页)
- `src/types/api.ts` (Profile接口定义，添加新字段)

---

### 5️⃣ Whisper消息 → 任务申请消息 (`WhisperMessageDialog.tsx`)

#### 保留
- ✅ 整个对话框布局
- ✅ 匿名状态的UI
- ✅ 消息输入框

#### 修改按钮文案和提示语

```tsx
// WhisperMessageDialog.tsx

// 原：系统提示消息
"你们已匹配！开始聊天吧"

// 🔴 新
"你的申请已发送，等待对方回复"

// 原：AI生成的开场白
`你好！我看到你在寻找${对方需求}，我有${我的技能}...`

// 🔴 新
`您好！看到您发布的任务"${任务标题}"，我有${我的技能}，曾完成过${相关案例}，预计${交付时间}完成，期待合作！`

// 原："揭示身份"按钮
<Button>揭示身份</Button>

// 🔴 新："确认合作"按钮
<Button>确认合作并支付</Button>

// 🔴 新增：顶部提示条（复用Alert组件）
<Alert className="mb-4 bg-blue-50">
  <Info className="h-4 w-4" />
  <AlertDescription>
    双方协商满意后，点击"确认合作"进入交易流程
  </AlertDescription>
</Alert>
```

**影响文件**：
- `src/components/WhisperMessageDialog.tsx`
- `src/locales/zh.ts` (添加whisper相关新文案)

---

### 6️⃣ 个人中心/设置页 (`SettingsScreen.tsx`, `ProfileView.tsx`)

#### 修改个人中心顶部统计卡片

```tsx
// ProfileView.tsx 中的统计区域

// 原：统计项
const stats = [
  { label: '已匹配', value: profile.matchCount },
  { label: '项目', value: profile.projects.length },
  { label: '技能', value: profile.skills.length },
]

// 🔴 新：接单者模式统计
const statsAsFreelancer = [
  { 
    label: '本月收益', 
    value: `¥${profile.monthlyEarnings}`,
    className: 'text-orange-500 text-2xl font-bold' // 橙色强调
  },
  { label: '完成任务', value: `${profile.completedTasks}单` },
  { label: '好评率', value: `${profile.rating}%` },
]

// 🔴 新：发单者模式统计
const statsAsPoster = [
  { label: '进行中', value: `${profile.activeTasks}单` },
  { label: '已完成', value: `${profile.completedTasks}单` },
  { label: '总支出', value: `¥${profile.totalSpent}` },
]
```

#### 新增：角色切换Tab

```tsx
// ProfileView.tsx 顶部添加Tab

<Tabs defaultValue="freelancer" className="w-full">
  <TabsList className="grid w-full grid-cols-2">
    <TabsTrigger value="freelancer">接单者模式</TabsTrigger>
    <TabsTrigger value="poster">发单者模式</TabsTrigger>
  </TabsList>
  
  <TabsContent value="freelancer">
    {/* 接单者统计和菜单 */}
  </TabsContent>
  
  <TabsContent value="poster">
    {/* 发单者统计和菜单 */}
  </TabsContent>
</Tabs>
```

#### 修改设置菜单项文案

```typescript
// locales/zh.ts
settings: {
  // 原菜单项
  whispers: {
    title: '悄悄话',
    // ...
  },
  
  // 🔴 新菜单项
  whispers: {
    title: '任务申请设置', // 🔴
    description: '管理任务申请的默认消息模板',
    wechatTitle: '微信号（用于联系）',
    wechatDesc: '确认合作后会分享此微信号',
    usageTitle: '本月任务申请次数',
  },
  
  payment: {
    title: '收益与支付', // 🔴 改
    // 原: receivesLeft: '剩余接收次数：',
    creditScore: '信用分：', // 🔴 新
    // ...
  },
  
  // 🔴 新增菜单项
  orders: {
    title: '订单管理',
    description: '查看接单记录和收益明细',
  },
  earnings: {
    title: '提现',
    description: '将收益提现到微信或支付宝',
  },
}
```

**影响文件**：
- `src/components/SettingsScreen.tsx`
- `src/components/ProfileView.tsx`
- `src/locales/zh.ts`

---

### 7️⃣ 通知系统 (`NotificationPanel.tsx`)

#### 修改通知类型文案

```typescript
// locales/zh.ts 或 NotificationPanel.tsx

const notificationMessages = {
  // 原
  whisper_received: '${name} 向你发送了 Whisper',
  match_success: '你们匹配成功！',
  identity_revealed: '${name} 揭示了身份',
  
  // 🔴 新
  task_application: '${name} 申请了你的任务"${taskTitle}"', // 🔴
  application_accepted: '你的申请被接受！', // 🔴
  cooperation_confirmed: '对方已确认合作，请支付定金', // 🔴
  
  // 🔴 新增
  task_deadline_reminder: '任务"${taskTitle}"即将截止（还剩24小时）',
  payment_received: '你已收到 ¥${amount} 任务款项',
  task_completed: '任务"${taskTitle}"已完成，请验收',
}
```

**影响文件**：
- `src/components/NotificationPanel.tsx`
- `src/locales/zh.ts`

---

### 8️⃣ 底部导航 (`BottomNavigation.tsx`)

#### 修改导航项文案和图标

```tsx
// BottomNavigation.tsx

const navItems = [
  // 原
  { id: 'chat', icon: MessageSquare, label: '聊天' },
  { id: 'contacts', icon: Users, label: '联系人' },
  { id: 'profile', icon: User, label: '我的' },
  
  // 🔴 新（保持图标和位置，仅改label）
  { id: 'chat', icon: MessageSquare, label: '找任务' }, // 🔴
  { id: 'orders', icon: FileText, label: '订单' }, // 🔴 新增或替换contacts
  { id: 'profile', icon: User, label: '我的' },
]
```

或保持"联系人"tab不变，在个人中心增加"订单管理"入口。

**影响文件**：
- `src/components/BottomNavigation.tsx`

---

## 🆕 新增页面设计（基于现有组件）

### 9️⃣ 任务/订单管理页 (`OrderManagementView.tsx`) - ✅ 已实现

**位置**：BottomNavigation第2个Tab - "任务/订单"

**功能说明**：
- ✅ 双Tab切换：我接的单 / 我发的单
- ✅ 订单卡片列表（状态徽章、金额、截止时间）
- ✅ 快速操作：查看详情、联系对方、验收/评价
- ✅ 状态筛选：进行中、待验收、已完成
- ✅ 点击订单打开详情弹窗（`OrderDetailView`）
- ✅ 完成后打开评价弹窗（`ReviewDialog`）

**UI组件复用**：
```tsx
import { Card } from './ui/card';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { 
  ClipboardList, Clock, DollarSign, Star, 
  CheckCircle, AlertCircle, MessageCircle, ChevronRight 
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
```

**订单状态流转**：
```
pending (待接单) → in_progress (进行中) → submitted (待验收) 
→ completed (已完成) → [用户评价]
                    ↘ cancelled (已取消)
```

**订单卡片设计**（复用Card组件）：
```tsx
<Card className="p-4 hover:shadow-md">
  {/* 标题 + 状态Badge */}
  <div className="flex items-center gap-2 mb-1">
    <h3 className="font-semibold">{title}</h3>
    <Badge variant={statusVariant}>
      <StatusIcon className="w-3 h-3" />
      {statusLabel}
    </Badge>
  </div>
  
  {/* 描述 */}
  <p className="text-sm text-gray-600 line-clamp-2">{description}</p>
  
  {/* 对方信息 */}
  <div className="flex items-center gap-2">
    <Avatar>{partnerAvatar}</Avatar>
    <span>{partnerName}</span>
    <Star /><span>{rating}</span>
  </div>
  
  {/* 技能标签 */}
  <div className="flex gap-1">
    {skills.map(skill => <Badge variant="outline">{skill}</Badge>)}
  </div>
  
  {/* 金额 + 截止时间 */}
  <div className="flex gap-4">
    <div><DollarSign />¥{amount}</div>
    <div><Clock />截止: {deadline}</div>
  </div>
  
  {/* 操作按钮 */}
  <div className="flex gap-2">
    <Button onClick={viewDetail}>查看详情</Button>
    <Button onClick={contact}><MessageCircle /></Button>
    {status === 'submitted' && <Button onClick={accept}>验收</Button>}
    {status === 'completed' && <Button onClick={review}><Star /></Button>}
  </div>
</Card>
```

**关键功能实现**：
```typescript
// 接受订单（验收通过）
const handleAcceptOrder = (order: Order) => {
  // TODO: POST /api/orders/{id}/accept
  alert('订单验收通过！');
};

// 举报订单
const handleReportOrder = (order: Order) => {
  // TODO: POST /api/orders/{id}/report
  alert('举报已提交');
};

// 评价订单
const handleReviewOrder = (order: Order) => {
  setShowReviewDialog(true); // 打开5星评分弹窗
};

// 联系对方
const handleContactPartner = (partnerId: string) => {
  // TODO: Navigate to MessageListView conversation
  alert('跳转到消息界面');
};
```

**数据结构**：
```typescript
interface Order {
  id: string;
  title: string;
  description: string;
  status: 'pending' | 'in_progress' | 'submitted' | 'completed' | 'cancelled';
  amount: number;
  deadline: string;
  partner: { 
    id: string;
    name: string; 
    avatar: string;
    rating?: number;
  };
  createdAt: string;
  submittedAt?: string;
  completedAt?: string;
  skills: string[];
  attachments?: { name: string; url: string }[];
}
```

---

### 🔟 消息列表与对话页 (`MessageListView.tsx`) - ✅ 已实现

**位置**：BottomNavigation第3个Tab - "消息"

**功能说明**：
- ✅ 消息列表（对话预览、未读数badge）
- ✅ 点击进入对话详情（实时聊天界面）
- ✅ 对话界面：消息气泡、时间戳、输入框
- ✅ 返回按钮回到消息列表
- ✅ 附件上传按钮（预留）

**UI组件复用**：
```tsx
import { Card } from './ui/card';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { 
  MessageCircle, Clock, ArrowLeft, Send, 
  Paperclip, MoreVertical 
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
```

**消息列表项设计**：
```tsx
<button className="w-full bg-white hover:bg-gray-50 px-4 py-4">
  <div className="flex items-start gap-3">
    {/* 头像 + 未读badge */}
    <div className="relative">
      <Avatar>{partnerAvatar}</Avatar>
      {unread > 0 && (
        <div className="absolute -top-1 -right-1 bg-red-500 rounded-full text-white text-xs">
          {unread}
        </div>
      )}
    </div>
    
    {/* 内容 */}
    <div className="flex-1">
      <div className="flex justify-between">
        <div className="flex gap-2">
          <h3 className="font-semibold">{partnerName}</h3>
          {taskTitle && <Badge variant="outline">{taskTitle}</Badge>}
        </div>
        <span className="text-xs text-gray-500">
          <Clock />{formatTime(timestamp)}
        </span>
      </div>
      <p className={`text-sm truncate ${unread > 0 ? 'font-medium' : 'text-gray-600'}`}>
        {lastMessage}
      </p>
    </div>
  </div>
</button>
```

**对话界面设计**（切换到对话视图）：
```tsx
{/* 顶部Header */}
<div className="border-b px-4 py-3 flex items-center gap-3">
  <Button onClick={backToList}><ArrowLeft /></Button>
  <Avatar>{partnerAvatar}</Avatar>
  <div className="flex-1">
    <h2 className="font-semibold">{partnerName}</h2>
    {taskTitle && <p className="text-xs text-gray-500">{taskTitle}</p>}
  </div>
  <Button variant="ghost"><MoreVertical /></Button>
</div>

{/* 消息列表 */}
<div className="flex-1 overflow-y-auto p-4 space-y-4">
  {messages.map(msg => (
    <div className={`flex ${isMe ? 'justify-end' : 'justify-start'}`}>
      <div className={`max-w-[75%] rounded-2xl px-4 py-2 ${
        isMe ? 'bg-blue-500 text-white' : 'bg-gray-100'
      }`}>
        <p className="text-sm">{msg.content}</p>
      </div>
      <p className="text-xs text-gray-400 mt-1">{formatTime(msg.timestamp)}</p>
    </div>
  ))}
</div>

{/* 输入区 */}
<div className="border-t p-4 flex gap-2">
  <Button variant="ghost"><Paperclip /></Button>
  <Input 
    value={input} 
    onChange={setInput}
    onKeyPress={e => e.key === 'Enter' && sendMessage()}
    placeholder="输入消息..."
  />
  <Button onClick={sendMessage} disabled={!input.trim()}>
    <Send />
  </Button>
</div>
```

**时间格式化**：
```typescript
const formatTimestamp = (date: Date) => {
  const diff = Date.now() - date.getTime();
  const minutes = Math.floor(diff / 60000);
  const hours = Math.floor(diff / 3600000);
  const days = Math.floor(diff / 86400000);
  
  if (minutes < 60) return `${minutes}分钟前`;
  if (hours < 24) return `${hours}小时前`;
  if (days < 7) return `${days}天前`;
  return date.toLocaleDateString();
};

const formatMessageTime = (date: Date) => {
  return `${date.getHours()}:${date.getMinutes()}`;
};
```

**数据结构**：
```typescript
interface Message {
  id: string;
  partnerId: string;
  partnerName: string;
  partnerAvatar: string;
  lastMessage: string;
  timestamp: Date;
  unread: number;
  taskTitle?: string; // 关联的任务标题
}

interface ChatMessage {
  id: string;
  senderId: string;
  content: string;
  timestamp: Date;
  type: 'text' | 'image' | 'file';
}
```

**状态管理**：
```typescript
const [selectedConversation, setSelectedConversation] = useState<string | null>(null);
const [messageInput, setMessageInput] = useState('');

// 根据selectedConversation决定显示列表还是对话
if (selectedConversation && mockConversation) {
  return <ConversationView />; // 对话界面
}
return <MessageListView />; // 列表界面
```

---

### 1️⃣1️⃣ 订单管理页（新增）

**复用组件**：`ContactHistory.tsx`的布局

**设计方案**：
```tsx
// 新建：src/components/OrderList.tsx

import { ContactHistory } from './ContactHistory'; // 复用布局组件
import { Card } from './ui/card';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { Tabs, TabsList, TabsTrigger, TabsContent } from './ui/tabs';

interface Order {
  id: string;
  taskTitle: string;
  amount: number;
  status: 'pending' | 'in_progress' | 'completed' | 'cancelled';
  partnerName: string;
  partnerAvatar: string;
  deadline: string;
  createdAt: string;
}

export function OrderList() {
  // 🔴 复用ContactHistory的列表布局样式
  return (
    <div className="h-full flex flex-col bg-gray-50">
      {/* 顶部Tab */}
      <Tabs defaultValue="all" className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="all">全部</TabsTrigger>
          <TabsTrigger value="in_progress">进行中</TabsTrigger>
          <TabsTrigger value="completed">已完成</TabsTrigger>
          <TabsTrigger value="cancelled">已取消</TabsTrigger>
        </TabsList>
        
        <TabsContent value="all" className="p-4 space-y-3">
          {orders.map(order => (
            // 🔴 复用ContactHistory中的卡片样式
            <Card className="p-4 flex items-center gap-3">
              {/* 左侧：任务类型图标（复用Avatar组件） */}
              <Avatar className="h-12 w-12">
                <AvatarFallback>{getTaskIcon(order.type)}</AvatarFallback>
              </Avatar>
              
              {/* 中部：任务信息 */}
              <div className="flex-1 min-w-0">
                <div className="font-medium truncate">{order.taskTitle}</div>
                <div className="text-sm text-gray-500 flex items-center gap-2">
                  <Badge variant={getStatusVariant(order.status)}>
                    {getStatusText(order.status)}
                  </Badge>
                  <span>对方：{order.partnerName}</span>
                </div>
              </div>
              
              {/* 右侧：金额和操作 */}
              <div className="text-right">
                <div className="text-lg font-bold text-orange-500">
                  ¥{order.amount}
                </div>
                <Button size="sm" variant="ghost">
                  查看详情
                </Button>
              </div>
            </Card>
          ))}
        </TabsContent>
      </Tabs>
    </div>
  );
}
```

**完全复用的组件**：
- `Card` - 订单卡片容器
- `Avatar` - 任务类型图标
- `Badge` - 状态标签
- `Button` - 操作按钮
- `Tabs` - 订单状态切换

**无需新增任何样式或组件！**

---

### 🔟 确认合作页（新增）

**复用组件**：表单页面布局（参考`ProfileSetupWizard`的表单样式）

```tsx
// 新建：src/components/ConfirmCooperation.tsx

import { Card } from './ui/card';
import { Button } from './ui/button';
import { Checkbox } from './ui/checkbox';
import { RadioGroup, RadioGroupItem } from './ui/radio-group';
import { Separator } from './ui/separator';

export function ConfirmCooperation({ task, partner }) {
  return (
    <div className="h-full flex flex-col bg-gray-50">
      {/* 顶部导航（复用现有Header组件） */}
      <header className="bg-white border-b px-4 py-3">
        <h1 className="text-lg font-semibold">确认合作</h1>
      </header>
      
      <div className="flex-1 overflow-auto p-4 space-y-4">
        {/* 任务摘要卡片 - 🔴 复用ChatCards的缩略样式 */}
        <Card className="p-4">
          <div className="flex items-center gap-3">
            <Avatar src={partner.avatar} />
            <div className="flex-1">
              <div className="font-medium">{task.title}</div>
              <div className="text-sm text-gray-500">{partner.name}</div>
            </div>
            <div className="text-xl font-bold text-orange-500">
              ¥{task.amount}
            </div>
          </div>
        </Card>
        
        {/* 支付方式选择 - 🔴 复用RadioGroup组件 */}
        <Card className="p-4">
          <h3 className="font-medium mb-3">支付方式</h3>
          <RadioGroup defaultValue="wechat">
            <div className="flex items-center space-x-2 p-3 rounded border">
              <RadioGroupItem value="wechat" id="wechat" />
              <Label htmlFor="wechat" className="flex-1">微信支付</Label>
            </div>
            <div className="flex items-center space-x-2 p-3 rounded border">
              <RadioGroupItem value="alipay" id="alipay" />
              <Label htmlFor="alipay" className="flex-1">支付宝</Label>
            </div>
          </RadioGroup>
        </Card>
        
        {/* 协议勾选 - 🔴 复用Checkbox组件 */}
        <div className="flex items-start space-x-2">
          <Checkbox id="terms" />
          <Label htmlFor="terms" className="text-sm text-gray-600">
            我已阅读并同意《平台交易协议》和《任务验收规则》
          </Label>
        </div>
      </div>
      
      {/* 底部固定按钮 - 🔴 复用现有的底部按钮样式 */}
      <div className="bg-white border-t p-4">
        <Button className="w-full" size="lg">
          支付 ¥{task.amount}
        </Button>
      </div>
    </div>
  );
}
```

**完全复用的组件**：
- `Card`, `Button`, `Checkbox`, `RadioGroup`, `Avatar`, `Label`, `Separator`
- 所有现有样式和间距规范

---

### 1️⃣1️⃣ 验收评价页（弹窗）

**复用组件**：`Sheet` 或 `Dialog` 底部抽屉

```tsx
// 新建：src/components/TaskReviewDialog.tsx

import { Sheet, SheetContent, SheetHeader, SheetTitle } from './ui/sheet';
import { Button } from './ui/button';
import { Textarea } from './ui/textarea';
import { Star } from 'lucide-react';

export function TaskReviewDialog({ open, onClose, partner, onSubmit }) {
  const [ratings, setRatings] = useState({
    quality: 0,
    speed: 0,
    communication: 0,
  });
  const [comment, setComment] = useState('');
  
  return (
    // 🔴 复用Sheet组件（现有的底部弹窗）
    <Sheet open={open} onOpenChange={onClose}>
      <SheetContent side="bottom" className="h-[80vh]">
        <SheetHeader>
          <SheetTitle>评价任务</SheetTitle>
        </SheetHeader>
        
        <div className="py-6 space-y-6">
          {/* 对方信息 - 🔴 复用Avatar和文字样式 */}
          <div className="flex items-center gap-3">
            <Avatar src={partner.avatar} className="h-12 w-12" />
            <div>
              <div className="font-medium">{partner.name}</div>
              <div className="text-sm text-gray-500">
                {partner.university}
              </div>
            </div>
          </div>
          
          <Separator />
          
          {/* 评分滑块 - 🔴 使用Star图标 + 现有的按钮样式 */}
          {['quality', 'speed', 'communication'].map(category => (
            <div key={category}>
              <Label className="mb-2 block">
                {getCategoryLabel(category)}
              </Label>
              <div className="flex gap-2">
                {[1, 2, 3, 4, 5].map(star => (
                  <button
                    key={star}
                    onClick={() => setRatings(prev => ({
                      ...prev,
                      [category]: star
                    }))}
                    className="p-0 border-0 bg-transparent"
                  >
                    <Star
                      className={`h-8 w-8 ${
                        star <= ratings[category]
                          ? 'fill-yellow-400 text-yellow-400'
                          : 'text-gray-300'
                      }`}
                    />
                  </button>
                ))}
              </div>
            </div>
          ))}
          
          <Separator />
          
          {/* 评价内容 - 🔴 复用Textarea组件 */}
          <div>
            <Label>补充评价（选填）</Label>
            <Textarea
              placeholder="分享你的合作体验..."
              value={comment}
              onChange={(e) => setComment(e.target.value)}
              className="mt-2"
              rows={4}
            />
          </div>
        </div>
        
        {/* 底部按钮 - 🔴 复用Button组件 */}
        <div className="flex gap-3">
          <Button variant="outline" onClick={onClose} className="flex-1">
            取消
          </Button>
          <Button onClick={handleSubmit} className="flex-1">
            提交评价
          </Button>
        </div>
      </SheetContent>
    </Sheet>
  );
}
```

**完全复用的组件**：
- `Sheet` - 底部抽屉弹窗
- `Avatar`, `Separator`, `Label`, `Textarea`, `Button`
- `Star` 图标（Lucide-react已有）

---

## 🎨 视觉元素微调

### 头像显示（保持不变）

```tsx
// 在ChatCards.tsx中

// ✅ 保持显示用户头像（发单者的头像）
<Avatar src={profile.avatar} className="h-24 w-24" />

// 任务卡片显示发布任务的人的头像
// 接单者档案卡片显示接单者的头像
// 完全复用现有Avatar组件，无需任何修改
```

**优势**：
- ✅ 零代码改动
- ✅ 保持人性化社交感
- ✅ 用户可以看到对方的真实照片
- ✅ 完全符合最小改动原则

### 任务类型标识（可选，使用Badge）

如果需要快速识别任务类型，可在卡片上方添加类型徽章：

```tsx
// 可选：在头像上方或旁边添加任务类型Badge
<Badge variant="secondary" className="mb-2">
  <Palette className="w-3 h-3 mr-1" />
  平面设计
</Badge>
```

---

### 金额显示样式（橙色强调）

```tsx
// 在需要显示金额的地方统一使用

<span className="text-orange-500 font-bold text-lg">
  ¥{amount}
</span>

// 或使用现有的Badge组件
<Badge className="bg-orange-100 text-orange-700 border-orange-300">
  ¥100-150
</Badge>
```

**使用场景**：
- 任务卡片右上角预算
- 订单列表金额
- 个人中心收益统计
- 支付确认页面

**完全使用现有Tailwind配色，无需新增颜色变量！**

---

## 📋 完整文案替换清单（Checklist）

### `src/locales/zh.ts` 修改清单

```typescript
// ✅ 需要修改的section
welcome: {
  subtitle: ✅ 改
  autoRegister: ✅ 改
}

profileSetup: {
  // Skills步骤
  addTagsSkills: ✅ 改
  skillPlaceholder: ✅ 改
  
  // Resources步骤
  whatResources: ✅ 改
  shareResources: ✅ 改
  resourcePlaceholder: ✅ 改
  
  // Projects步骤
  yourPastProjects: ✅ 改
  showcaseExperience: ✅ 改
  
  // Goals步骤
  whatAreGoals: ✅ 改
  goalPlaceholder: ✅ 改
  
  // Demands步骤
  whatDoYouNeed: ✅ 改
  demandPlaceholder: ✅ 改
}

settings: {
  whispers: {
    title: ✅ 改为"任务申请设置"
    description: ✅ 改
    usageTitle: ✅ 改
  },
  
  payment: {
    title: ✅ 改为"收益与支付"
    receivesLeft: ✅ 删除或改为creditScore
  },
  
  // ✅ 新增
  orders: { ... },
  earnings: { ... },
}

// ✅ 新增section
chat: {
  botWelcome: '你好！我是你的任务助手...',
  searchPlaceholder: '找任务 / 找人帮忙',
},

whisper: {
  systemMessage: '你的申请已发送，等待对方回复',
  confirmButton: '确认合作并支付',
  negotiationTip: '双方协商满意后，点击"确认合作"进入交易流程',
},

notifications: {
  task_application: '...',
  application_accepted: '...',
  cooperation_confirmed: '...',
  task_deadline_reminder: '...',
  payment_received: '...',
},

orders: {
  title: '订单管理',
  all: '全部',
  in_progress: '进行中',
  completed: '已完成',
  cancelled: '已取消',
  viewDetails: '查看详情',
},

taskReview: {
  title: '评价任务',
  quality: '质量',
  speed: '速度',
  communication: '沟通',
  commentPlaceholder: '分享你的合作体验...',
  submit: '提交评价',
},
```

---

## 🚀 实施步骤（开发指南）

### Phase 1: 纯文案修改（1-2小时）
1. ✅ 修改 `src/locales/zh.ts` 和 `src/locales/en.ts`
2. ✅ 修改 `ChatInterface.tsx` 的Bot欢迎语
3. ✅ 测试所有页面文案是否正确显示

### Phase 2: 数据字段映射（2-3小时）
1. ✅ 修改 `src/types/api.ts` 的Profile接口
   - 添加新字段：`budget`, `deadline`, `posterRating`, `requiredSkills`, `taskDescription`
2. ✅ 修改 `ChatCards.tsx` 渲染逻辑
   - 右上角显示预算（原receivesLeft位置）
   - 添加截止时间显示
   - 封面改为任务类型图标+渐变背景
3. ✅ 修改 `ProfileView.tsx`
   - "寻找"模块改为"服务定价"
   - 添加信用分和完成率统计

### Phase 3: 新增页面（3-4小时）
1. ✅ 创建 `OrderList.tsx`（复用ContactHistory布局）
2. ✅ 创建 `ConfirmCooperation.tsx`（复用表单布局）
3. ✅ 创建 `TaskReviewDialog.tsx`（复用Sheet组件）
4. ✅ 在 `BottomNavigation.tsx` 添加"订单"入口（或在个人中心添加）

### Phase 4: 交互调整（1-2小时）
1. ✅ 修改 `WhisperMessageDialog.tsx` 的"揭示身份"按钮
   - 改为"确认合作"
   - 点击后跳转到支付页
2. ✅ 添加角色切换Tab（可选，在个人中心）

### Phase 5: 测试与微调（1-2小时）
1. ✅ 端到端流程测试
2. ✅ 文案一致性检查
3. ✅ UI间距和样式检查

**总预估工时：8-13小时**

---

## ✅ 验收标准

### 视觉一致性
- ✅ 所有新页面的配色、字体、圆角、阴影与原设计100%一致
- ✅ 无新增任何自定义CSS类（除了任务类型渐变背景）
- ✅ 所有组件均来自现有的ui/目录

### 功能完整性
- ✅ 原有的滑动、匹配、AI聊天逻辑完全保留
- ✅ 新增的订单管理、支付、评价功能可正常交互
- ✅ 角色切换（接单者/发单者）流畅无bug

### 文案准确性
- ✅ 所有"人才匹配"相关术语已替换为"任务接单"术语
- ✅ 中英文文案对应且翻译准确
- ✅ 无遗漏的旧文案

---

## 📊 改动量统计

| 类型 | 预计改动行数 | 文件数 | 复杂度 |
|------|------------|--------|--------|
| 文案修改 | ~200行 | 2个（zh.ts, en.ts） | ⭐ 低 |
| 组件逻辑修改 | ~150行 | 5个（ChatCards, ProfileView, WhisperDialog等） | ⭐⭐ 中 |
| 新增页面 | ~400行 | 3个（OrderList, ConfirmCooperation, TaskReview） | ⭐⭐ 中 |
| 类型定义 | ~50行 | 1个（api.ts） | ⭐ 低 |
| **总计** | **~800行** | **11个文件** | **⭐⭐ 中等** |

**对比完全重构的工作量**：节省 **70-80%** 开发时间！

---

## 🎯 关键优势总结

1. **零UI重构**：100%复用现有设计系统和组件库
2. **最小代码改动**：仅修改文案和数据字段映射，核心逻辑不变
3. **快速上线**：预计1-2周完成pivot，而非2-3个月重构
4. **低风险**：保留所有已验证的交互逻辑和用户体验
5. **易维护**：新功能基于现有组件组合，无技术债务

---

## 📌 附录：图标映射表

| 原图标含义 | 新图标含义 | Lucide-react图标 | 使用位置 |
|------------|------------|------------------|----------|
| Users（联系人） | FileText（订单） | `<FileText />` | 底部导航（可选） |
| Heart（匹配） | Heart（保留） | `<Heart />` | 滑动按钮 |
| MessageSquare（聊天） | MessageSquare（保留） | `<MessageSquare />` | 底部导航 |
| - | Clock（截止时间） | `<Clock />` | 任务卡片 |
| - | TrendingUp（收益） | `<TrendingUp />` | 个人中心统计 |
| Gift（赠送Receives） | Gift（可保留或删除） | `<Gift />` | - |
| - | Star（评分） | `<Star />` | 评价页面 |
| - | Palette（设计任务） | `<Palette />` | 任务类型图标 |
| - | Code（编程任务） | `<Code />` | 任务类型图标 |
| - | FileText（文案任务） | `<FileText />` | 任务类型图标 |
| - | Video（视频任务） | `<Video />` | 任务类型图标 |

**所有图标均来自Lucide-react现有库，无需自行设计！**

---

## 🔗 相关文件索引

### 需要修改的文件
1. `src/locales/zh.ts` - 中文文案
2. `src/locales/en.ts` - 英文文案
3. `src/components/ChatInterface.tsx` - Bot欢迎语
4. `src/components/ChatCards.tsx` - 卡片渲染逻辑
5. `src/components/ProfileView.tsx` - 档案页面
6. `src/components/WhisperMessageDialog.tsx` - 申请消息对话框
7. `src/components/SettingsScreen.tsx` - 设置页面
8. `src/components/NotificationPanel.tsx` - 通知面板
9. `src/types/api.ts` - 数据类型定义

### 需要新建的文件
1. `src/components/OrderList.tsx` - 订单列表页
2. `src/components/ConfirmCooperation.tsx` - 确认合作页
3. `src/components/TaskReviewDialog.tsx` - 评价弹窗

**总共修改/新建：12个文件**

---

**文档版本**：v2.0（根据用户决策更新）
**最后更新**：2025-10-22
**预计实施周期**：1-2周
**风险等级**：低（✅ 基于成熟组件库，改动可控）

---

## 🎨 用户确认的极简设计原则

### 钱包页面 - Minimalist设计（用户决策 4.1）

**✅ 用户要求**：尽量把每一个板块的内容存在可展开的按钮中使整体更干净

```tsx
// src/components/WalletView.tsx - 极简版钱包

export function WalletView() {
  const [expandedSection, setExpandedSection] = useState<string | null>(null);
  
  return (
    <div className="min-h-screen bg-gray-50 pb-safe">
      {/* 顶部余额卡片 - 大字体，极简 */}
      <Card className="m-4 p-6 bg-gradient-to-br from-blue-500 to-blue-600 text-white">
        <p className="text-sm opacity-80">可用余额</p>
        <h1 className="text-4xl font-bold mt-1">¥108.50</h1>
        
        {/* 快捷按钮 */}
        <div className="flex gap-3 mt-6">
          <Button variant="secondary" size="sm" className="flex-1">
            提现
          </Button>
          <Button variant="outline" size="sm" className="flex-1 text-white border-white">
            充值
          </Button>
        </div>
      </Card>
      
      {/* 可展开的数据板块 */}
      <div className="px-4 space-y-2">
        {/* 冻结金额 - 可展开 */}
        <Collapsible
          open={expandedSection === 'frozen'}
          onOpenChange={() => setExpandedSection(expandedSection === 'frozen' ? null : 'frozen')}
        >
          <Card className="overflow-hidden">
            <CollapsibleTrigger className="w-full p-4 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <Lock className="w-5 h-5 text-gray-400" />
                <div className="text-left">
                  <p className="font-medium">冻结金额</p>
                  <p className="text-sm text-gray-500">进行中的订单</p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <span className="font-bold">¥120.00</span>
                <ChevronDown className={cn("w-4 h-4 transition-transform", expandedSection === 'frozen' && "rotate-180")} />
              </div>
            </CollapsibleTrigger>
            
            <CollapsibleContent>
              <div className="px-4 pb-4 space-y-2">
                <div className="flex justify-between text-sm">
                  <span>订单 #789</span>
                  <span>¥120.00</span>
                </div>
              </div>
            </CollapsibleContent>
          </Card>
        </Collapsible>
        
        {/* 交易明细 - 可展开 */}
        <Collapsible
          open={expandedSection === 'transactions'}
          onOpenChange={() => setExpandedSection(expandedSection === 'transactions' ? null : 'transactions')}
        >
          <Card className="overflow-hidden">
            <CollapsibleTrigger className="w-full p-4 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <History className="w-5 h-5 text-gray-400" />
                <p className="font-medium">交易明细</p>
              </div>
              <ChevronDown className={cn("w-4 h-4 transition-transform", expandedSection === 'transactions' && "rotate-180")} />
            </CollapsibleTrigger>
            
            <CollapsibleContent>
              <div className="px-4 pb-4 space-y-3">
                {recentTransactions.map(tx => (
                  <div key={tx.id} className="flex justify-between text-sm">
                    <div>
                      <p className="font-medium">{tx.title}</p>
                      <p className="text-gray-500 text-xs">{tx.date}</p>
                    </div>
                    <span className={cn("font-semibold", tx.type === 'income' ? 'text-green-600' : 'text-red-600')}>
                      {tx.type === 'income' ? '+' : '-'}¥{tx.amount}
                    </span>
                  </div>
                ))}
              </div>
            </CollapsibleContent>
          </Card>
        </Collapsible>
      </div>
    </div>
  );
}
```

**关键设计点**：
- ✅ 使用 `Collapsible` 组件（Shadcn/UI自带）实现可展开
- ✅ 默认折叠状态，保持页面干净
- ✅ 大字体余额显示，一目了然
- ✅ 无冗余装饰，极简卡片设计

---

### 订单详情页 - Card板块设计（用户决策 3.2）

**✅ 用户要求**：不用这么详细，做成一个小的card板块吧重要信息或跳转作为可点开的按钮。参考原本的notification card和contact history card

```tsx
// src/components/OrderDetailView.tsx - 简化版

export function OrderDetailView({ orderId }: { orderId: string }) {
  const { order, loading } = useOrder(orderId);
  
  if (loading) return <Skeleton />;
  
  return (
    <div className="min-h-screen bg-gray-50 pb-safe">
      {/* 顶部状态横幅 */}
      <div className="bg-white px-4 py-3 border-b">
        <Badge variant={getStatusVariant(order.status)}>
          {getStatusText(order.status)}
        </Badge>
        <h1 className="text-lg font-semibold mt-1">{order.taskTitle}</h1>
      </div>
      
      <div className="p-4 space-y-3">
        {/* 任务信息卡片 - 可点击展开 */}
        <Card 
          className="p-4 cursor-pointer active:scale-95 transition-transform"
          onClick={() => navigate(`/tasks/${order.taskId}`)}
        >
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <FileText className="w-5 h-5 text-gray-400" />
              <div>
                <p className="font-medium">任务信息</p>
                <p className="text-sm text-gray-500">预算 ¥{order.amount}</p>
              </div>
            </div>
            <ChevronRight className="w-4 h-4 text-gray-400" />
          </div>
        </Card>
        
        {/* 对方信息卡片 - 可点击查看档案 */}
        <Card 
          className="p-4 cursor-pointer active:scale-95 transition-transform"
          onClick={() => navigate(`/profile/${order.partnerId}`)}
        >
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Avatar src={order.partnerAvatar} size="md" />
              <div>
                <p className="font-medium">{order.partnerName}</p>
                <p className="text-sm text-gray-500">⭐ {order.partnerRating.toFixed(1)}</p>
              </div>
            </div>
            <Button variant="ghost" size="sm">
              发送消息
            </Button>
          </div>
        </Card>
        
        {/* 交付物卡片 - 简化显示 */}
        {order.deliverables?.length > 0 && (
          <Card className="p-4">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <Upload className="w-5 h-5 text-gray-400" />
                <p className="font-medium">交付物</p>
              </div>
              <Badge>{order.deliverables.length}个文件</Badge>
            </div>
            
            {/* 文件列表 - 简化显示 */}
            <div className="space-y-2">
              {order.deliverables.map(file => (
                <div key={file.id} className="flex items-center justify-between p-2 bg-gray-50 rounded">
                  <span className="text-sm truncate">{file.fileName}</span>
                  <Button variant="ghost" size="sm">查看</Button>
                </div>
              ))}
            </div>
          </Card>
        )}
      </div>
      
      {/* 底部操作按钮 */}
      {order.status === 'submitted' && order.role === 'poster' && (
        <div className="fixed bottom-0 left-0 right-0 bg-white border-t p-4 pb-safe">
          <Button className="w-full" size="lg">
            验收通过
          </Button>
        </div>
      )}
    </div>
  );
}
```

**关键设计点**：
- ✅ 每个板块都是独立的Card，可点击跳转
- ✅ 参考NotificationPanel和ContactHistory的卡片设计
- ✅ 没有冗长的表单，只保留关键信息
- ✅ 使用ChevronRight图标暗示可点击

---

### 档案页面 - 极简stat设计（用户决策 2.4）

**✅ 用户要求**：不用Tab切换，跟现有布局大致一样，只保留最重要的stat（评分、发布任务数、完成任务数）

```tsx
// src/components/ProfileView.tsx - 简化版

export function ProfileView({ userId }: { userId: string }) {
  return (
    <div className="min-h-screen bg-gray-50">
      {/* 顶部用户信息 - 保持原有布局 */}
      <div className="bg-white p-4">
        <div className="flex items-center gap-4">
          <Avatar src={user.avatar} size="xl" />
          <div className="flex-1">
            <h1 className="text-xl font-bold">{user.name}</h1>
            <p className="text-gray-500">{user.university.name}</p>
            <p className="text-sm text-gray-600 mt-1">{user.bio}</p>
          </div>
        </div>
        
        {/* ✅ 简化的stat卡片 - 横向排列，不分Tab */}
        <div className="grid grid-cols-3 gap-3 mt-4">
          <div className="text-center p-3 bg-gray-50 rounded">
            <p className="text-2xl font-bold text-orange-500">
              {user.averageRating?.toFixed(1) || '0.0'}
            </p>
            <p className="text-xs text-gray-500 mt-1">评分</p>
          </div>
          
          <div className="text-center p-3 bg-gray-50 rounded">
            <p className="text-2xl font-bold text-blue-500">
              {user.completedTasksCount || 0}
            </p>
            <p className="text-xs text-gray-500 mt-1">完成任务</p>
          </div>
          
          <div className="text-center p-3 bg-gray-50 rounded">
            <p className="text-2xl font-bold text-green-500">
              {user.postedTasksCount || 0}
            </p>
            <p className="text-xs text-gray-500 mt-1">发布任务</p>
          </div>
        </div>
      </div>
      
      {/* 技能、作品集等其他内容保持原有布局 */}
      <div className="p-4 space-y-4">
        {/* ... */}
      </div>
    </div>
  );
}
```

---

### 简化的流程设计（用户决策）

#### 任务申请流程（用户决策 5.1）

**用户确认的流程**：
1. 跟AI说你想做的事或者单纯让他给你推荐几个
2. 看每个卡片的信息
3. **左划卡片跳过，右划卡片发送想做任务申请**
4. 等待对方接受并在聊天栏目回复

**实现方式**：
- ✅ 保持Tinder式滑动交互
- ✅ 右滑直接提交申请（无需填写表单）
- ✅ AI自动生成申请话术

#### 订单验收流程（用户决策 5.2）

**用户确认的极简流程**：
1. 发起方满意结束订单则完成方直接收到钱
2. 有意见走report

**实现方式**：
- ✅ 删除复杂的状态流转图
- ✅ 订单详情页只有两个按钮："验收通过" 和 "举报"
- ❌ 取消"申请修改"、"申请取消"等中间状态

#### 评价系统（用户决策 5.3）

**用户确认**：
- 发起方的任务完成后可选择5星里评分即可，不必要其他内容

**实现方式**：
```tsx
// 极简评价弹窗
<Dialog>
  <DialogContent>
    <h3>评价接单者</h3>
    <div className="flex justify-center gap-2 my-6">
      {[1, 2, 3, 4, 5].map(star => (
        <Star 
          key={star}
          className={cn("w-10 h-10 cursor-pointer", rating >= star && "fill-yellow-400 text-yellow-400")}
          onClick={() => setRating(star)}
        />
      ))}
    </div>
    <Button onClick={submitReview}>提交评价</Button>
  </DialogContent>
</Dialog>
```

- ✅ 仅5星评分，无文字评价
- ✅ 无分项评分（沟通、质量等）
- ✅ 一步完成

---

## 📦 最终精简的组件清单（用户决策 6.1）

**根据极致简化原则，删除不必要的组件**：

### ✅ 保留并重构的核心组件
1. `ChatInterface.tsx` - AI对话+角色切换
2. `ChatCards.tsx` - 双模式卡片
3. `ProfileView.tsx` - 极简档案页
4. `BottomNavigation.tsx` - 4个Tab导航
5. `WalletView.tsx` - Minimalist钱包

### ➕ 必须新建的组件（P0优先级）
1. `TaskCreationWizard.tsx` - AI创建任务（集成在ChatInterface中）
2. `OrderDetailView.tsx` - 订单详情卡片（简化版）
3. `MessageListView.tsx` - 聊天列表（新功能）
4. `ChatConversation.tsx` - 一对一聊天
5. `FileUploadZone.tsx` - 文件上传

### ❌ 删除的组件
- `OrderStatusTimeline.tsx` - 不需要复杂时间轴
- `TaskFilterPanel.tsx` - AI智能推荐，无需手动过滤
- `FreelancerSearchView.tsx` - 通过AI对话完成，无需独立页面
- `DisputeDialog.tsx` - 简化为举报按钮即可
- `WithdrawalForm.tsx` - 集成在钱包页面
- `ReviewForm.tsx` - 极简5星评分，无需独立组件

**最终组件数量**：从原计划的15个减少到 **10个**

---

## 🎓 高校线下任务场景示例（实际应用）

### 前端Mock数据示例（已实现）

#### ChatInterface 任务列表示例
```typescript
const MOCK_TASKS = [
  {
    title: '帮忙早八课程签到（本周三次）',
    description: '微积分早八课，本周三、周五需要代签到两次。教室在理科楼A301，早上7:50前到即可。要求同校学生，可以提供学生证照片核实身份。',
    budget: { min: 30, max: 50 },
    skills: ['同校学生', '早起', '守时'],
    category: '校园帮助'
  },
  {
    title: '毕业论文数据标注（500条）',
    description: '需要标注500条文本数据用于毕业论文实验，内容是情感分析（正面/负面/中性）。提供详细标注指南，每条约50字，预计3小时完成。',
    budget: { min: 80, max: 120 },
    skills: ['数据标注', '细心认真', '中文阅读理解'],
    category: '学术辅助'
  },
  {
    title: '导师科研项目临时助理（3天）',
    description: '协助导师完成科研项目的文献整理和数据录入工作。需要在实验室现场工作，每天2-3小时，连续3天。',
    budget: { min: 200, max: 300 },
    skills: ['Office办公', '文献整理', '数据录入', '科研经历'],
    category: '学术辅助'
  },
  {
    title: '高数作业辅导（一对一）',
    description: '需要高数学霸帮忙讲解本周作业题（约15道题），主要是多元函数微积分。可以线下图书馆见面讲解，或线上视频辅导2小时。',
    budget: { min: 60, max: 100 },
    skills: ['高等数学', '一对一辅导', '讲解能力'],
    category: '课程辅导'
  },
  {
    title: '社团活动现场帮手（周六下午）',
    description: '社团举办校园音乐节，需要3名现场帮手协助布置场地、引导观众、维持秩序。时间：本周六下午2点到6点。',
    budget: { min: 80, max: 100 },
    skills: ['活动组织', '沟通能力', '体力充沛'],
    category: '活动帮手'
  }
];
```

#### OrderManagementView 订单管理示例
```typescript
const mockOrders = [
  {
    title: '帮忙代签到（本周两次）',
    description: '微积分早八课，周三和周五需要帮忙签到。理科楼A301，7:50前到即可',
    status: 'in_progress',
    amount: 40,
    skills: ['同校学生', '早起', '守时']
  },
  {
    title: '论文数据标注（500条）',
    description: '毕业论文需要标注500条文本数据（情感分析），已提供详细指南',
    status: 'submitted',
    amount: 100,
    skills: ['数据标注', '细心认真', '中文阅读']
  },
  {
    title: '高数作业辅导（一对一）',
    description: '需要高数学霸讲解本周作业15道题，多元函数微积分部分',
    status: 'completed',
    amount: 80,
    skills: ['高等数学', '一对一辅导', '讲解能力']
  },
  {
    title: '活动现场帮手（周六下午）',
    description: '社团音乐节需要3名现场帮手，协助布置场地和引导观众',
    status: 'pending',
    amount: 90,
    skills: ['活动组织', '沟通能力', '体力充沛']
  }
];
```

#### MessageListView 对话示例
```typescript
const mockMessages = [
  {
    partnerName: '张小明',
    lastMessage: '好的，周三早上7:45我会准时到理科楼',
    taskTitle: '帮忙代签到',
    unread: 2
  },
  {
    partnerName: '李华',
    lastMessage: '标注结果已完成，请查收Excel文件',
    taskTitle: '论文数据标注',
    unread: 0
  },
  {
    partnerName: '王芳',
    lastMessage: '题目都讲完了，有问题随时问我',
    taskTitle: '高数作业辅导',
    unread: 0
  }
];

// 对话详情示例
const mockConversation = {
  messages: [
    { 
      sender: 'user1', 
      content: '你好，我想确认一下签到的具体时间和地点' 
    },
    { 
      sender: 'me', 
      content: '周三和周五早上7:50前，理科楼A301教室。你需要帮我在签到表上签名，我会发学生证照片给你核对' 
    },
    { 
      sender: 'user1', 
      content: '明白了，我就住在理科楼附近，早上7:45准时到' 
    }
  ]
};
```

### 技能标签词库（高校场景）

**课程学习类**：
- `高等数学`, `线性代数`, `概率论`, `物理`, `化学`
- `编程基础`, `数据结构`, `算法`, `数据库`
- `英语四六级`, `雅思`, `托福`, `GRE`

**学术科研类**：
- `文献查找`, `文献翻译`, `数据标注`, `数据整理`
- `问卷设计`, `SPSS`, `Python数据分析`, `R语言`
- `实验助理`, `科研经历`, `论文排版`

**校园活动类**：
- `活动组织`, `主持`, `摄影`, `摄像`, `剪辑`
- `海报设计`, `PPT制作`, `文案策划`
- `志愿者经验`, `沟通能力`, `体力充沛`

**技能外包类**：
- `Photoshop`, `Illustrator`, `Premiere`, `Final Cut Pro`
- `Word排版`, `Excel数据处理`, `PPT美化`
- `Python`, `Java`, `Web开发`, `小程序开发`
- `英文润色`, `中英翻译`, `文档翻译`

**生活服务类**：
- `同校学生`, `早起`, `守时`, `细心认真`
- `驾照`, `车辆`, `熟悉校园`, `路线熟悉`

### 用户画像示例

**接单者 - 技术型**
```
姓名：李华
年级：计算机大三
技能：Python, 数据分析, Pandas, 机器学习
简介：有两年数据分析经验，帮助过多位同学完成毕业论文数据处理
完成任务：23单 | 评分：4.9★ | 响应：1小时内
```

**接单者 - 学霸型**
```
姓名：王芳
年级：数学大二
技能：高等数学, 线性代数, 概率论, 一对一辅导
简介：数学竞赛一等奖，擅长用通俗易懂的方式讲解复杂概念
完成任务：15单 | 评分：5.0★ | 响应：30分钟内
```

**接单者 - 活动型**
```
姓名：张小明
年级：传媒大四
技能：活动组织, 摄影, 视频剪辑, 主持
简介：学生会活动部部长，组织过多场大型校园活动
完成任务：30单 | 评分：4.7★ | 响应：2小时内
```

---

**更新说明**：本次更新根据用户确认的极简设计原则，大幅简化了UI复杂度和组件数量，符合"保持极致的干净和简化"的要求。并明确了产品定位为高校线下任务场景，所有前端示例数据已更新为实际应用场景。

